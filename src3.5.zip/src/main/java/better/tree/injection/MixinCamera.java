package better.tree.injection;

import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import better.tree.core.manager.client.ModuleManager;
import better.tree.core.Managers;
import better.tree.core.rotation.Mode;
import better.tree.core.rotation.RenderRotationsService;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import static better.tree.features.modules.Module.mc;

@Mixin(Camera.class)
public abstract class MixinCamera {
    @Shadow
    protected abstract float clipToSpace(float desiredCameraDistance);

    @Shadow
    private boolean thirdPerson;

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;moveBy(FFF)V", ordinal = 0))
    private void modifyCameraDistance(Args args) {
        if (ModuleManager.noCameraClip.isEnabled()) {
            args.set(0, -clipToSpace(ModuleManager.noCameraClip.getDistance()));
        }
    }

    @Inject(method = "clipToSpace", at = @At("HEAD"), cancellable = true)
    private void onClipToSpace(float f, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.noCameraClip.isEnabled()) {
            cir.setReturnValue(ModuleManager.noCameraClip.getDistance());
        }
    }

    @Inject(method = "update", at = @At("TAIL"))
    private void updateHook(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.freeCam.isEnabled()) {
            this.thirdPerson = true;
        }
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void setRotationHook(Args args) {
        if(ModuleManager.freeCam.isEnabled())
            args.setAll(ModuleManager.freeCam.getFakeYaw(), ModuleManager.freeCam.getFakePitch());
        else {
            // Apply VisualRotation to camera if enabled
            if (Managers.ROTATION.getMode() != Mode.OFF) {
                RenderRotationsService.Flags flags = Managers.ROTATION.getFlags();
                boolean gui = mc != null && mc.currentScreen != null;
                boolean moving = mc != null && mc.player != null && mc.player.input != null && (Math.abs(mc.player.input.movementForward) + Math.abs(mc.player.input.movementSideways)) > 0;
                if (!(flags.disableInGUI && gui) && !(flags.onlyWhileMoving && !moving)) {
                    RenderRotationsService.Rotation vr = Managers.ROTATION.getVisualRotation();
                    args.setAll(vr.yaw, vr.pitch);
                }
            }
        }
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"))
    private void setPosHook(Args args) {
        if(ModuleManager.freeCam.isEnabled())
            args.setAll(ModuleManager.freeCam.getFakeX(), ModuleManager.freeCam.getFakeY(), ModuleManager.freeCam.getFakeZ());
    }
}