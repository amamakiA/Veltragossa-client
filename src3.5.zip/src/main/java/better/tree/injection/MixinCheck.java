package better.tree.injection;

public class MixinCheck {
}