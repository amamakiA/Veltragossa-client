package better.tree.injection;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import better.tree.core.manager.client.ModuleManager;

@Mixin(AbstractClientPlayerEntity.class)
public class MixinAbstractClientPlayerEntity {
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void modifySkinTextures(CallbackInfoReturnable<SkinTextures> cir) {
        AbstractClientPlayerEntity player = (AbstractClientPlayerEntity) (Object) this;

        Identifier customCape = null;
        Identifier customSkin = null;
        Identifier customElytra = null;

        if (ModuleManager.cape != null && ModuleManager.cape.isEnabled()) {
            customCape = ModuleManager.cape.getCapeTexture(player);
            if (ModuleManager.cape.elytraTexture.getValue()) {
                customElytra = customCape;
            }
        }

        if (ModuleManager.SkinChanger != null && ModuleManager.SkinChanger.isEnabled()) {
            customSkin = ModuleManager.SkinChanger.getSkinTexture(player);
        }

        if (customCape != null || customSkin != null) {
            SkinTextures original = cir.getReturnValue();
            SkinTextures modified = new SkinTextures(
                    customSkin != null ? customSkin : original.texture(),
                    original.textureUrl(),
                    customCape != null ? customCape : original.capeTexture(),
                    customElytra != null ? customElytra : original.elytraTexture(),
                    original.model(),
                    original.secure()
            );
            cir.setReturnValue(modified);
        }
    }
}