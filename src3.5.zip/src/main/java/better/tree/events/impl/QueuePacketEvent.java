package better.tree.events.impl;



import net.minecraft.network.packet.Packet;

import better.tree.events.Event;

import better.tree.utility.client.PacketQueueManager;





public class QueuePacketEvent extends Event {

    private final Packet<?> packet;

    private final Niggers origin;

    private PacketQueueManager.Action action = PacketQueueManager.Action.PASS;



    public QueuePacketEvent(Packet<?> packet, Niggers origin) {

        this.packet = packet;

        this.origin = origin;

    }



    public Packet<?> getPacket() {

        return packet;

    }



    public Niggers getOrigin() {

        return origin;

    }



    public PacketQueueManager.Action getAction() {

        return action;

    }



    public void setAction(PacketQueueManager.Action action) {

        this.action = action;

    }



    public enum Niggers {

        Fortnite,


    }

}