package better.tree.events.impl;

import better.tree.events.Event;

public class EventPostSync extends Event {
    public EventPostSync() {
    }
}