package better.tree.events.impl;

import better.tree.events.Event;

public class EventAfterRotate extends Event {
}