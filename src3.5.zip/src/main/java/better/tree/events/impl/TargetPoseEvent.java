package better.tree.events.impl;

import meteordevelopment.orbit.ICancellable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;

public class TargetPoseEvent implements ICancellable {
    private final Entity entity;
    private EntityPose pose;
    private boolean cancelled;

    public TargetPoseEvent(Entity entity, EntityPose pose) {
        this.entity = entity;
        this.pose = pose;
    }

    public Entity getEntity() {
        return entity;
    }

    public EntityPose getPose() {
        return pose;
    }

    public void setPose(EntityPose pose) {
        this.pose = pose;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
