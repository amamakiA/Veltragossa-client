package better.tree.gui.clickui;

import better.tree.core.Managers;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import better.tree.features.modules.Module;
import better.tree.utility.render.Render2DEngine;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import org.lwjgl.glfw.GLFW;
import java.awt.Color;
import java.util.*;

public class NewClickGUI extends Screen {
    private final List<ModulePanel> panels = new ArrayList<>();
    private ModulePanel selectedPanel;
    private float scrollOffset;
    private boolean isDragging;
    private double dragX, dragY;
    private String searchQuery = "";
    private boolean isTyping = false;

    private static final int PANEL_WIDTH = 120;
    private static final int PANEL_HEIGHT = 20;
    private static final int PANEL_SPACING = 5;

    public NewClickGUI() {
        super(Text.of("NewClickGUI"));
        initPanels();
    }

    private void initPanels() {
        int startX = 10;
        int startY = 10;

        for (Module.Category category : Module.Category.values()) {
            if (category == Module.Category.HUD) continue;
            ModulePanel panel = new ModulePanel(category, startX, startY, PANEL_WIDTH);
            panels.add(panel);
            startY += PANEL_HEIGHT + PANEL_SPACING;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);


        panels.forEach(panel -> panel.render(context, mouseX, mouseY, delta));


        Render2DEngine.drawRound(context.getMatrices(),
            width - 150, 5, 140, 20, 5,
            new Color(20, 20, 20, 200));


        String displayText = searchQuery.isEmpty() ? "Szukaj..." : searchQuery;
        Color textColor = searchQuery.isEmpty() ? new Color(128, 128, 128, 200) : new Color(255, 255, 255, 255);

        FontRenderers.sf_medium.drawString(
            context.getMatrices(),
            displayText,
            width - 145,
            10,
            textColor.getRGB()
        );

        if (isTyping && System.currentTimeMillis() % 1000 > 500) {
            FontRenderers.sf_medium.drawString(
                context.getMatrices(),
                "|",
                width - 145 + FontRenderers.sf_medium.getStringWidth(searchQuery),
                10,
                new Color(255, 255, 255, 255).getRGB()
            );
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (isTyping) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                isTyping = false;
                searchQuery = "";
                updateSearch();
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchQuery.isEmpty()) {
                    searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                    updateSearch();
                }
            } else if (keyCode == GLFW.GLFW_KEY_ENTER) {
                isTyping = false;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (isTyping) {
            if (Character.isLetterOrDigit(chr) || Character.isSpaceChar(chr)) {
                searchQuery += chr;
                updateSearch();
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void updateSearch() {
        panels.forEach(panel -> panel.filterModules(searchQuery));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {

        if (mouseX >= width - 150 && mouseX <= width - 10 &&
            mouseY >= 5 && mouseY <= 25) {
            isTyping = true;
            return true;
        } else {
            isTyping = false;
        }

        for (ModulePanel panel : panels) {
            if (panel.handleClick(mouseX, mouseY, button)) {
                return true;
            }
            if (panel.isHeaderHovered(mouseX, mouseY)) {
                if (button == 0) {
                    selectedPanel = panel;
                    isDragging = true;
                    dragX = mouseX - panel.x;
                    dragY = mouseY - panel.y;
                    return true;
                } else if (button == 1) {
                    panel.toggleExpanded();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        isDragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (isDragging && selectedPanel != null) {
            selectedPanel.x = (float) (mouseX - dragX);
            selectedPanel.y = (float) (mouseY - dragY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = (float) (verticalAmount * 10);
        panels.forEach(panel -> {
            if (panel.isHovered(mouseX, mouseY)) {
                panel.scroll(scrollOffset);
            }
        });
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class ModulePanel {
        private final Module.Category category;
        private float x, y;
        private final int width;
        private float moduleScroll;
        private boolean expanded;
        private final List<Module> allModules = new ArrayList<>();
        private final List<Module> displayedModules = new ArrayList<>();
        private float expandProgress;
        private Module selectedModule;

        public ModulePanel(Module.Category category, float x, float y, int width) {
            this.category = category;
            this.x = x;
            this.y = y;
            this.width = width;

            if (Managers.MODULE != null && Managers.MODULE.modules != null) {
                for (Module module : Managers.MODULE.modules) {
                    if (module != null && module.getCategory() == category) {
                        allModules.add(module);
                    }
                }
            }

            displayedModules.addAll(allModules);
            this.expanded = true;
            this.expandProgress = 1f;
        }

        public void toggleExpanded() {
            expanded = !expanded;
        }

        public boolean handleClick(double mouseX, double mouseY, int button) {
            if (!isHovered(mouseX, mouseY)) return false;

            float moduleY = y + PANEL_HEIGHT + 5;
            for (Module module : displayedModules) {
                if (moduleY + moduleScroll > y + PANEL_HEIGHT && moduleY + moduleScroll < y + getExpandedHeight()) {
                    if (isModuleHovered(mouseX, mouseY, moduleY + moduleScroll)) {
                        if (button == 0) {
                            module.toggle();
                            return true;
                        } else if (button == 1) {
                            selectedModule = selectedModule == module ? null : module;
                            return true;
                        }
                    }
                }
                moduleY += 22;
                if (selectedModule == module) {
                    for (Setting<?> setting : module.getSettings()) {
                        if (moduleY + moduleScroll > y + PANEL_HEIGHT && moduleY + moduleScroll < y + getExpandedHeight()) {
                            if (isSettingHovered(mouseX, mouseY, moduleY + moduleScroll)) {
                                handleSettingClick(setting, button, mouseX);
                                return true;
                            }
                        }
                        moduleY += 20;
                    }
                }
            }
            return false;
        }

        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            updateAnimation(delta);


            Render2DEngine.drawRound(context.getMatrices(),
                x, y, width, PANEL_HEIGHT + (getExpandedHeight()),
                5, new Color(25, 25, 25, 255));


            FontRenderers.sf_medium.drawString(
                context.getMatrices(),
                formatCategoryName(category) + (expanded ? " -" : " +"),
                x + 5,
                y + 6,
                new Color(255, 255, 255).getRGB()
            );

            if (expandProgress > 0) {
                float moduleY = y + PANEL_HEIGHT + 5;
                for (Module module : displayedModules) {
                    if (moduleY + moduleScroll > y + PANEL_HEIGHT && moduleY + moduleScroll < y + getExpandedHeight()) {
                        boolean isHovered = isModuleHovered(mouseX, mouseY, moduleY + moduleScroll);
                        boolean isSelected = module == selectedModule;

                        Color bgColor = isHovered ? new Color(45, 45, 45, 255) :
                                      isSelected ? new Color(35, 35, 35, 255) :
                                      new Color(30, 30, 30, 255);

                        Render2DEngine.drawRound(context.getMatrices(),
                            x + 2, moduleY + moduleScroll, width - 4, 20,
                            4, bgColor);

                        FontRenderers.sf_medium.drawString(
                            context.getMatrices(),
                            formatModuleName(module.getName()),
                            x + 6,
                            moduleY + moduleScroll + 6,
                            module.isEnabled() ? new Color(120, 255, 120).getRGB() : new Color(220, 220, 220).getRGB()
                        );
                    }
                    moduleY += 22;

                    if (module == selectedModule) {
                        for (Setting<?> setting : module.getSettings()) {
                            if (moduleY + moduleScroll > y + PANEL_HEIGHT && moduleY + moduleScroll < y + getExpandedHeight()) {
                                renderSetting(context, setting, x + 10, moduleY + moduleScroll);
                            }
                            moduleY += 20;
                        }
                    }
                }
            }
        }

        private String formatModuleName(String name) {
            if (name == null || name.isEmpty()) return "Unknown";


            if (name.contains(".")) {
                String[] parts = name.split("\\.");
                name = parts[parts.length - 1];
            }


            name = name.replace("module", "");


            if (name.contains("@")) {
                name = name.substring(0, name.indexOf('@'));
            }
            if (name.contains("$")) {
                name = name.substring(0, name.indexOf('$'));
            }

            return name;
        }

        private String formatCategoryName(Module.Category category) {
            if (category == null) return "Unknown";
            String name = category.toString();


            if (name.contains(".")) {
                String[] parts = name.split("\\.");
                name = parts[parts.length - 1];
            }


            name = name.split("[@$]")[0];

            return name;
        }

        private String formatSettingName(String name) {
            if (name == null || name.isEmpty()) return "Unknown";


            name = name.replaceAll("^(get|set|is)", "");
            if (name.contains(".")) {
                name = name.substring(name.lastIndexOf('.') + 1);
            }


            name = name.replace('_', ' ');


            if (name.length() > 1) {
                return name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
            }

            return name.toUpperCase();
        }

        private String formatSettingValue(Object value) {
            if (value == null) return "null";

            if (value instanceof Boolean) {
                return ((Boolean) value) ? "On" : "Off";
            }

            if (value instanceof Number) {
                if (value instanceof Float || value instanceof Double) {
                    double number = ((Number) value).doubleValue();
                    if (Math.abs(number) < 10) {
                        return String.format("%.2f", number);
                    } else {
                        return String.format("%.1f", number);
                    }
                }
                return value.toString();
            }

            if (value instanceof Enum<?>) {
                String name = value.toString();
                if (name.contains(".")) {
                    name = name.substring(name.lastIndexOf('.') + 1);
                }
                name = name.replace('_', ' ');
                if (name.length() > 1) {
                    return name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
                }
                return name;
            }

            return value.toString();
        }

        private void handleSettingClick(Setting<?> setting, int button, double mouseX) {
            if (setting.getValue() instanceof Boolean) {
                @SuppressWarnings("unchecked")
                Setting<Boolean> boolSetting = (Setting<Boolean>) setting;
                boolSetting.setValue(!boolSetting.getValue());
            } else if (setting.getValue() instanceof Number) {
                float relativeX = (float) (mouseX - (x + 12));
                float width = this.width - 48;
                float progress = Math.max(0, Math.min(1, relativeX / width));

                if (setting.getValue() instanceof Integer) {
                    @SuppressWarnings("unchecked")
                    Setting<Integer> intSetting = (Setting<Integer>) setting;
                    int min = intSetting.getMin() != null ? intSetting.getMin() : 0;
                    int max = intSetting.getMax() != null ? intSetting.getMax() : 100;
                    int value = (int) (min + (max - min) * progress);

                    if (max - min <= 10) {
                        value = Math.round((float)(min + (max - min) * progress));
                    }
                    intSetting.setValue(value);
                } else if (setting.getValue() instanceof Float) {
                    @SuppressWarnings("unchecked")
                    Setting<Float> floatSetting = (Setting<Float>) setting;
                    float min = floatSetting.getMin() != null ? floatSetting.getMin() : 0f;
                    float max = floatSetting.getMax() != null ? floatSetting.getMax() : 100f;
                    float value = min + (max - min) * progress;

                    if (max - min <= 10) {
                        value = Math.round(value * 10f) / 10f;
                    }
                    floatSetting.setValue(value);
                } else if (setting.getValue() instanceof Double) {
                    @SuppressWarnings("unchecked")
                    Setting<Double> doubleSetting = (Setting<Double>) setting;
                    double min = doubleSetting.getMin() != null ? doubleSetting.getMin() : 0.0;
                    double max = doubleSetting.getMax() != null ? doubleSetting.getMax() : 100.0;
                    double value = min + (max - min) * progress;

                    if (max - min <= 10) {
                        value = Math.round(value * 10.0) / 10.0;
                    }
                    doubleSetting.setValue(value);
                }
            } else if (setting.getValue() instanceof Enum<?>) {
                Enum<?>[] constants = ((Enum<?>) setting.getValue()).getDeclaringClass().getEnumConstants();
                int index = ((Enum<?>) setting.getValue()).ordinal();

                if (button == 0) {
                    index = (index + 1) % constants.length;
                } else {
                    index = (index - 1 + constants.length) % constants.length;
                }

                @SuppressWarnings("unchecked")
                Setting<Enum<?>> enumSetting = (Setting<Enum<?>>) setting;
                enumSetting.setValue(constants[index]);
            }
        }

        private void renderSetting(DrawContext context, Setting<?> setting, float x, float y) {

            Render2DEngine.drawRound(context.getMatrices(),
                x, y, width - 24, 16,
                3, new Color(20, 20, 20, 255));

            String formattedName = formatSettingName(setting.getName());
            String formattedValue = formatSettingValue(setting.getValue());

            if (setting.getValue() instanceof Boolean) {
                boolean value = (Boolean) setting.getValue();

                Render2DEngine.drawRound(context.getMatrices(),
                    x + width - 30, y + 2, 12, 12,
                    2, value ? new Color(0, 255, 0, 200) : new Color(255, 0, 0, 200));

                FontRenderers.sf_medium.drawString(
                    context.getMatrices(),
                    formattedName,
                    x + 4,
                    y + 4,
                    new Color(200, 200, 200).getRGB()
                );
            } else if (setting.getValue() instanceof Number) {
                float valueWidth = FontRenderers.sf_medium.getStringWidth(formattedValue);

                Object value = setting.getValue();
                float min = 0f;
                float max = 100f;

                if (value instanceof Number num) {
                    if (setting instanceof Setting<?> s) {
                        Object minVal = s.getMin();
                        Object maxVal = s.getMax();
                        min = minVal instanceof Number ? ((Number) minVal).floatValue() : 0f;
                        max = maxVal instanceof Number ? ((Number) maxVal).floatValue() : 100f;
                    }
                    float progress = (num.floatValue() - min) / (max - min);


                    FontRenderers.sf_medium.drawString(
                        context.getMatrices(),
                        formattedValue,
                        x + width - 34 - valueWidth,
                        y + 4,
                        new Color(200, 200, 200).getRGB()
                    );


                    float maxNameWidth = width - 70 - valueWidth;
                    String displayName = formattedName;
                    if (FontRenderers.sf_medium.getStringWidth(displayName) > maxNameWidth) {
                        displayName = displayName.substring(0, Math.min(displayName.length(), 10)) + "...";
                    }

                    FontRenderers.sf_medium.drawString(
                        context.getMatrices(),
                        displayName,
                        x + 4,
                        y + 4,
                        new Color(200, 200, 200).getRGB()
                    );


                    Render2DEngine.drawRound(context.getMatrices(),
                        x + 2, y + 14, width - 28, 1,
                        1, new Color(40, 40, 40, 255));

                    Render2DEngine.drawRound(context.getMatrices(),
                        x + 2, y + 14, (width - 28) * progress, 1,
                        1, new Color(0, 255, 0, 200));
                }
            } else if (setting.getValue() instanceof Enum<?>) {

                FontRenderers.sf_medium.drawString(
                    context.getMatrices(),
                    "◀ " + formattedValue + " ▶",
                    x + width - 60,
                    y + 4,
                    new Color(200, 200, 200).getRGB()
                );

                FontRenderers.sf_medium.drawString(
                    context.getMatrices(),
                    formattedName,
                    x + 4,
                    y + 4,
                    new Color(200, 200, 200).getRGB()
                );
            } else {
                FontRenderers.sf_medium.drawString(
                    context.getMatrices(),
                    formattedName + ": " + formattedValue,
                    x + 4,
                    y + 4,
                    new Color(200, 200, 200).getRGB()
                );
            }
        }


        private void updateAnimation(float delta) {
            if (expanded && expandProgress < 1f) {
                expandProgress = Math.min(1f, expandProgress + delta * 5f);
            } else if (!expanded && expandProgress > 0f) {
                expandProgress = Math.max(0f, expandProgress - delta * 5f);
            }
        }

        private float getExpandedHeight() {
            int totalHeight = 0;
            for (Module module : displayedModules) {
                totalHeight += 22;
                if (module == selectedModule) {
                    totalHeight += module.getSettings().size() * 20;
                }
            }
            return Math.min(300, totalHeight) * expandProgress;
        }

        public boolean isHovered(double mouseX, double mouseY) {
            float totalHeight = PANEL_HEIGHT + (expanded ? getExpandedHeight() : 0);
            return mouseX >= x && mouseX <= x + width &&
                   mouseY >= y && mouseY <= y + totalHeight;
        }

        private boolean isModuleHovered(double mouseX, double mouseY, float moduleY) {
            if (!expanded) return false;
            return mouseX >= x + 2 && mouseX <= x + width - 2 &&
                   mouseY >= moduleY && mouseY <= moduleY + 20;
        }

        private boolean isSettingHovered(double mouseX, double mouseY, float settingY) {
            return mouseX >= x + 10 && mouseX <= x + width - 14 &&
                   mouseY >= settingY && mouseY <= settingY + 16;
        }

        public boolean isHeaderHovered(double mouseX, double mouseY) {
            return mouseX >= x && mouseX <= x + width &&
                   mouseY >= y && mouseY <= y + PANEL_HEIGHT;
        }

        public void filterModules(String query) {
            displayedModules.clear();
            if (query.isEmpty()) {
                displayedModules.addAll(allModules);
            } else {
                String lowercaseQuery = query.toLowerCase();
                for (Module module : allModules) {
                    String moduleName = formatModuleName(module.getName()).toLowerCase();
                    String categoryName = formatCategoryName(module.getCategory()).toLowerCase();
                    if (moduleName.contains(lowercaseQuery) || categoryName.contains(lowercaseQuery)) {
                        displayedModules.add(module);
                    }
                }
            }
        }

        public void scroll(float amount) {
            int totalHeight = 0;
            for (Module module : displayedModules) {
                totalHeight += 22;
                if (module == selectedModule) {
                    totalHeight += module.getSettings().size() * 20;
                }
            }
            float maxScroll = -(totalHeight - getExpandedHeight());
            moduleScroll = Math.max(maxScroll, Math.min(0, moduleScroll + amount));
        }
    }
}
