package better.tree.gui.clickui;

import better.tree.gui.font.FontRenderers;
import better.tree.utility.render.Render2DEngine;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import java.awt.Color;

public class SearchField {
    private final int x, y, width, height;
    private String text;
    private boolean isFocused;
    private boolean typing;
    private final String placeholder;

    public SearchField(int x, int y, int width, int height, String placeholder) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.placeholder = placeholder;
        this.text = "";
        this.isFocused = false;
        this.typing = false;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MatrixStack matrices = context.getMatrices();
        Render2DEngine.drawRectWithOutline(matrices, x, y, width, height, new Color(17,11,22, 255), new Color(31,20,43, 255));
        Render2DEngine.drawRound(matrices, x, y, width, height, 5, new Color(17,11,22, 255));
        String cursor = typing && System.currentTimeMillis() % 1000 > 500 ? "_" : "";
        if (text.isEmpty() && !typing) {
            FontRenderers.sf_medium.drawString(matrices, placeholder, x + height / 3f, y + (height - 8) / 2f + 2, new Color(180,178,182).getRGB());
        } else {
            FontRenderers.sf_medium.drawString(matrices, text + cursor, x + height / 3f, y + (height - 8) / 2f + 2, new Color(255,255,255).getRGB());
        }
    }

    public boolean isEmpty() { return text == null || text.isEmpty(); }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public boolean isFocused() { return isFocused; }
    public void setFocused(boolean focused) { this.isFocused = focused; }
    public boolean isTyping() { return typing; }
    public void setTyping(boolean typing) { this.typing = typing; }
}
