package better.tree.gui.clickui.block;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import better.tree.setting.Setting;
import better.tree.setting.impl.ItemSelectSetting;

public class BlockSelectorButton extends ButtonWidget {
    private final Setting<ItemSelectSetting> setting;

    public BlockSelectorButton(int x, int y, int width, int height, Setting<ItemSelectSetting> setting) {
        super(x, y, width, height, Text.literal("Select Blocks"), button -> {
            MinecraftClient.getInstance().setScreen(new BlockListScreen(setting));
        }, ButtonWidget.DEFAULT_NARRATION_SUPPLIER);
        this.setting = setting;
    }
}
