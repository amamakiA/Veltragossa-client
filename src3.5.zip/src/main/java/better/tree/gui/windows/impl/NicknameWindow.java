package better.tree.gui.windows.impl;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import better.tree.features.cmd.impl.LoginCommand;
import better.tree.gui.clickui.impl.SliderElement;
import better.tree.gui.font.FontRenderers;
import net.minecraft.client.MinecraftClient;
import better.tree.gui.windows.WindowBase;
import better.tree.setting.Setting;
import better.tree.setting.impl.PositionSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class NicknameWindow extends WindowBase {
    private static NicknameWindow instance;


    private static final int MAX_VISIBLE_ENTRIES = 6;
    private static final float ENTRY_HEIGHT = 20;


    private static class NickEntry {
        String name;
        boolean loaded;

        NickEntry(String name) {
            this.name = name;
            this.loaded = false;
        }
    }

    private final List<NickEntry> nicknameHistory = new ArrayList<>();
    private String currentInput = "Nickname";
    private int listeningId = -1;
    private String currentNick = "";
    private final Random random = new Random();
    private static final String NICK_HISTORY_FILE = "Nick.json";

    private String tooltip = "";

    public NicknameWindow(float x, float y, float width, float height, Setting<PositionSetting> position) {
        super(x, y, width, height, "Nicknames", position, TextureStorage.playerIcon);
        loadNickHistory();
    }

    public static NicknameWindow get(float x, float y, Setting<PositionSetting> position) {
        if (instance == null)
            instance = new NicknameWindow(10 + 3 * 210, 50, 200, 180, position);
        return instance;
    }


    private void loadNickHistory() {
        File file = new File(NICK_HISTORY_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String nick = line.trim();
                if (!nick.isEmpty() && nicknameHistory.stream().noneMatch(e -> e.name.equals(nick))) {
                    nicknameHistory.add(new NickEntry(nick));
                }
            }
        } catch (IOException ignored) {}
    }


    private void removeNickFromFile(String nickToRemove) {
        File inputFile = new File(NICK_HISTORY_FILE);
        File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             PrintWriter writer = new PrintWriter(new FileWriter(tempFile))) {

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                if (!currentLine.trim().equals(nickToRemove.trim())) {
                    writer.println(currentLine);
                }
            }
        } catch (IOException ignored) {
            return;
        }

        if (inputFile.delete()) {
            tempFile.renameTo(inputFile);
        }
    }


    private String generateRandomNick() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder("Veltra");
        for (int i = 0; i < 5; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private void saveNickToFile(String nick) {
        try (FileWriter fw = new FileWriter(NICK_HISTORY_FILE, true)) {
            fw.write(nick + "\n");
        } catch (IOException ignored) {}
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY) {
        super.render(context, mouseX, mouseY);


        float totalContentHeight = nicknameHistory.size() * ENTRY_HEIGHT;
        setMaxElementsHeight(totalContentHeight);

        Color base = new Color(0xC5333333, true);
        Color outline = new Color(0xC55B5B5B, true);
        Color hovered = new Color(0xC5494949, true);
        int textColor = new Color(0xBDBDBD).getRGB();
        int activeColor = new Color(0xFFB300FF, true).getRGB();
        int buttonTextColor = new Color(0xFFFFFF).getRGB();

        String blink = (System.currentTimeMillis() / 240) % 2 == 0 ? "" : "l";


        float inputX = getX() + 11;
        float inputY = getY() + 19;
        float inputW = getWidth() - 70;
        float inputH = 16;
        boolean hoverInput = Render2DEngine.isHovered(mouseX, mouseY, inputX, inputY, inputW, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), inputX, inputY, inputW, inputH, hoverInput ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), currentInput + (listeningId == 1 ? blink : ""), inputX + 2, inputY + 4, textColor);


        float btnRandX = inputX + inputW + 4;
        boolean hoverRandom = Render2DEngine.isHovered(mouseX, mouseY, btnRandX, inputY, 16, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), btnRandX, inputY, 16, inputH, hoverRandom ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), "R", btnRandX + 5, inputY + 4, buttonTextColor);
        if (hoverRandom) tooltip = "Generate Random Nick";

        float btnAddX = btnRandX + 20;
        boolean hoverAdd = Render2DEngine.isHovered(mouseX, mouseY, btnAddX, inputY, 16, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), btnAddX, inputY, 16, inputH, hoverAdd ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), "+", btnAddX + 5, inputY + 4, buttonTextColor);
        if (hoverAdd) tooltip = "Add Nick and Login";


        FontRenderers.sf_medium.drawString(context.getMatrices(), "History:", inputX, inputY + inputH + 10, textColor);
        float historyY = inputY + inputH + 26;


        float historyAreaY = historyY - 2;
        float historyAreaH = MAX_VISIBLE_ENTRIES * ENTRY_HEIGHT;

        context.enableScissor(
                (int)(getX() + 10),
                (int)historyAreaY,
                (int)(getX() + getWidth() - 10),
                (int)(historyAreaY + historyAreaH)
        );


        int loggedColor = new Color(0x4CFF4C).getRGB();
        int notLoggedColor = new Color(0xFF4C4C).getRGB();

        int maxEntries = nicknameHistory.size();
        float animatedScrollY = getScrollOffset();


        for (int i = 0; i < maxEntries; i++) {
            int entryIndex = maxEntries - 1 - i;
            NickEntry entry = nicknameHistory.get(entryIndex);

            float entryX = inputX;

            float y = historyY + i * ENTRY_HEIGHT + animatedScrollY;

            boolean isActive = entry.name.equals(currentNick);
            int color = entry.loaded ? loggedColor : notLoggedColor;

            FontRenderers.sf_medium.drawString(context.getMatrices(), entry.name, entryX, y, color);


            float btnLoadX = entryX + inputW + 4;
            boolean hoverLoad = Render2DEngine.isHovered(mouseX, mouseY, btnLoadX, y, 16, inputH);
            Render2DEngine.drawRectWithOutline(context.getMatrices(), btnLoadX, y, 16, inputH, hoverLoad ? hovered : base, outline);
            FontRenderers.sf_medium.drawString(context.getMatrices(), "L", btnLoadX + 5, y + 4, buttonTextColor);
            if (hoverLoad) tooltip = "Login with this nickname";

            float btnDelX = btnLoadX + 20;
            boolean hoverDel = Render2DEngine.isHovered(mouseX, mouseY, btnDelX, y, 16, inputH);
            Render2DEngine.drawRectWithOutline(context.getMatrices(), btnDelX, y, 16, inputH, hoverDel ? hovered : base, outline);
            FontRenderers.sf_medium.drawString(context.getMatrices(), "X", btnDelX + 5, y + 4, buttonTextColor);
            if (hoverDel) tooltip = "Remove from history";

            if (isActive) FontRenderers.sf_medium.drawString(context.getMatrices(), "✓", btnDelX + 22, y + 4, activeColor);
        }


        context.disableScissor();



        if (!tooltip.isEmpty()) {
            FontRenderers.sf_medium.drawString(context.getMatrices(), tooltip, mouseX + 10, mouseY + 10, new Color(0xFFB300FF, true).getRGB());
            tooltip = "";
        }
    }


    @Override
    protected void mouseScrolled(int i) {

        super.mouseScrolled(i);
    }



    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);

        float inputX = getX() + 11;
        float inputY = getY() + 19;
        float inputW = getWidth() - 70;
        float inputH = 16;
        float btnRandX = inputX + inputW + 4;
        float btnAddX = btnRandX + 20;


        boolean hoverInput = Render2DEngine.isHovered(mouseX, mouseY, inputX, inputY, inputW, inputH);
        if (hoverInput) {
            listeningId = 1;
            if (currentInput.equals("Nickname")) {
                currentInput = "";
            }
            return;
        } else {

        }


        boolean hoverRandom = Render2DEngine.isHovered(mouseX, mouseY, btnRandX, inputY, 16, 16);
        if (hoverRandom) {
            currentInput = generateRandomNick();
            listeningId = 1;
            return;
        }



        boolean hoverAdd = Render2DEngine.isHovered(mouseX, mouseY, btnAddX, inputY, 16, 16);
        if (hoverAdd && !currentInput.isEmpty()) {

            if (currentInput.equalsIgnoreCase("Zelek5351") || currentInput.equalsIgnoreCase("Nickname")) {
                tooltip = "No NO!";
                return;
            }
            if (nicknameHistory.stream().noneMatch(e -> e.name.equals(currentInput))) {
                nicknameHistory.add(new NickEntry(currentInput));
                saveNickToFile(currentInput);
            }

            new LoginCommand().login(currentInput);
            currentNick = currentInput;
            for (NickEntry entry : nicknameHistory) entry.loaded = false;
            nicknameHistory.stream().filter(e -> e.name.equals(currentNick)).findFirst().ifPresent(e -> e.loaded = true);

            resetScroll();

            currentInput = "Nickname";
            listeningId = -1;
            return;
        }


        float historyY = getY() + 19 + 16 + 26;
        float historyAreaY = historyY - 2;
        float historyAreaH = MAX_VISIBLE_ENTRIES * ENTRY_HEIGHT;
        int maxEntries = nicknameHistory.size();
        float currentScroll = getScrollOffset();

        for (int i = 0; i < maxEntries; i++) {
            int entryIndex = maxEntries - 1 - i;
            NickEntry entry = nicknameHistory.get(entryIndex);

            float y = historyY + i * ENTRY_HEIGHT + currentScroll;


            if (y < historyAreaY || y > historyAreaY + historyAreaH - ENTRY_HEIGHT + 2) continue;

            float btnLoadX = inputX + inputW + 4;
            float btnDelX = btnLoadX + 20;

            boolean hoverLoad = Render2DEngine.isHovered(mouseX, mouseY, btnLoadX, y, 16, 16);
            boolean hoverDel = Render2DEngine.isHovered(mouseX, mouseY, btnDelX, y, 16, 16);

            if (hoverLoad) {
                new LoginCommand().login(entry.name);
                currentNick = entry.name;
                for (NickEntry e : nicknameHistory) e.loaded = false;
                entry.loaded = true;
                listeningId = -1;
                break;
            }
            if (hoverDel) {
                removeNickFromFile(entry.name);
                nicknameHistory.remove(entryIndex);

                resetScroll();
                setMaxElementsHeight(nicknameHistory.size() * ENTRY_HEIGHT);
                listeningId = -1; 
                break;
            }
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningId == 1) {
            boolean ctrlDown = (modifiers & GLFW.GLFW_MOD_CONTROL) != 0;

            if (ctrlDown) {
                if (keyCode == GLFW.GLFW_KEY_C) {
                    GLFW.glfwSetClipboardString(MinecraftClient.getInstance().getWindow().getHandle(), currentInput);
                    return;
                } else if (keyCode == GLFW.GLFW_KEY_V) {
                    String clipboard = GLFW.glfwGetClipboardString(MinecraftClient.getInstance().getWindow().getHandle());
                    if (clipboard != null && !clipboard.isEmpty()) {
                        currentInput += clipboard;
                    }
                    return;
                }
            }

            switch (keyCode) {
                case GLFW.GLFW_KEY_ENTER -> {
                    if (!currentInput.isEmpty()) {
                        if (currentInput.equalsIgnoreCase("Zelek5351") || currentInput.equalsIgnoreCase("Nickname")) {
                            tooltip = "Ten nick jest zablokowany!";
                            return;
                        }
                        if (nicknameHistory.stream().noneMatch(e -> e.name.equals(currentInput))) {
                            nicknameHistory.add(new NickEntry(currentInput));
                            saveNickToFile(currentInput);
                        }

                        new LoginCommand().login(currentInput);
                        currentNick = currentInput;
                        for (NickEntry entry : nicknameHistory) entry.loaded = false;
                        nicknameHistory.stream().filter(e -> e.name.equals(currentNick)).findFirst().ifPresent(e -> e.loaded = true);


                        resetScroll();

                        currentInput = "Nickname";
                        listeningId = -1;
                    }
                }
                case GLFW.GLFW_KEY_ESCAPE -> {
                    currentInput = "Nickname";
                    listeningId = -1;
                }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    currentInput = SliderElement.removeLastChar(currentInput);
                    if (Objects.equals(currentInput, "")) {
                        currentInput = "Nickname";
                        listeningId = -1;
                    }
                }
                case GLFW.GLFW_KEY_SPACE -> currentInput += " ";
            }
        }
    }


    @Override
    public void charTyped(char key, int keyCode) {
        if (listeningId == 1 && net.minecraft.util.StringHelper.isValidChar(key)) {
            currentInput += key;
        }
    }
}