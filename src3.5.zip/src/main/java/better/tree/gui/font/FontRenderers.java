package better.tree.gui.font;

import org.jetbrains.annotations.NotNull;
import better.tree.veltragossa;

import java.awt.*;
import java.io.IOException;
import java.util.Objects;

public class FontRenderers {
    public static FontRenderer settings;
    public static FontRenderer modules;
    public static FontRenderer categories;
    public static FontRenderer icons;
    public static FontRenderer mid_icons;
    public static FontRenderer big_icons;
    public static FontRenderer thglitch;
    public static FontRenderer thglitchBig;
    public static FontRenderer monsterrat;
    public static FontRenderer sf_bold;
    public static FontRenderer sf_bold_mini;
    public static FontRenderer sf_bold_micro;
    public static FontRenderer sf_medium;
    public static FontRenderer sf_medium_mini;
    public static FontRenderer sf_medium_modules;
    public static FontRenderer minecraft;
    public static FontRenderer profont;

    static {
        try {
            settings = create(36, "sf_bold");
            modules = create(20, "sf_medium");
            categories = create(24, "sf_bold");
            thglitch = create(20, "glitched");
            thglitchBig = create(30, "glitched");
            monsterrat = create(20, "monsterrat");
            sf_bold = create(36, "sf_bold");
            sf_bold_mini = create(28, "sf_bold");
            sf_bold_micro = create(20, "sf_bold");
            sf_medium = create(20, "sf_medium");
            sf_medium_mini = create(16, "sf_medium");
            sf_medium_modules = create(20, "sf_medium");
            minecraft = create(20, "minecraft");
            profont = create(20, "profont");
        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
        }
    }

    public static FontRenderer getModulesRenderer() {
        return modules;
    }

    public static @NotNull FontRenderer create(float size, String name) throws IOException, FontFormatException {
        return new FontRenderer(Font.createFont(Font.TRUETYPE_FONT, Objects.requireNonNull(veltragossa.class.getClassLoader().getResourceAsStream("assets/veltragossa/fonts/" + name + ".ttf"))).deriveFont(Font.PLAIN, size / 2f), size / 2f);
    }
}