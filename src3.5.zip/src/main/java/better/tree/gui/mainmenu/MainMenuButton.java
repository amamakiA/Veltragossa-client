package better.tree.gui.mainmenu;

import net.minecraft.client.gui.DrawContext;
import org.jetbrains.annotations.NotNull;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.Theme;
import better.tree.gui.font.FontRenderers;
import better.tree.utility.render.Render2DEngine;

import static better.tree.features.modules.Module.mc;

public class MainMenuButton {
    private float x, y, width, height;
    private final String name;
    private final Runnable action;

    public MainMenuButton(float y, @NotNull String name, Runnable action) {
        this.name = name;
        this.y = y;
        this.action = action;
        this.width = 140;
        this.height = 25;
    }

    public void onRender(DrawContext context, float mouseX, float mouseY) {
        float halfOfWidth = mc.getWindow().getScaledWidth() / 2f;
        float halfOfHeight = mc.getWindow().getScaledHeight() / 2f;
        this.x = halfOfWidth - width / 2f;

        boolean hovered = Render2DEngine.isHovered(mouseX, mouseY, x, halfOfHeight + y, width, height);

        if(hovered) {

            Render2DEngine.drawRound(context.getMatrices(), x - 0.5f, halfOfHeight + y - 0.5f, width + 1f, height + 1f, 5.5f, HudEditor.getColor(0));
        }

        Render2DEngine.drawRound(context.getMatrices(), x, halfOfHeight + y, width, height, 5, hovered ? Theme.BUTTON_HOVER_COLOR : Theme.BUTTON_COLOR);
        FontRenderers.sf_medium.drawCenteredString(context.getMatrices(), name, x + width / 2f, halfOfHeight + y + height / 2f - FontRenderers.sf_medium.getFontHeight(name) / 2f, Theme.FONT_COLOR.getRGB());
    }

    public void onClick(int mouseX, int mouseY) {
        float halfOfHeight = mc.getWindow().getScaledHeight() / 2f;
        boolean hovered = Render2DEngine.isHovered(mouseX, mouseY, x, halfOfHeight + y, width, height);
        if (hovered) action.run();
    }
}