package better.tree.gui.mainmenu;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.jetbrains.annotations.NotNull;
import better.tree.core.manager.client.ModuleManager;
import better.tree.gui.Theme;
import better.tree.gui.font.FontRenderers;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;
import better.tree.veltragossa;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static better.tree.features.modules.Module.mc;

public class MainMenuScreen extends Screen {
    private final List<MainMenuButton> buttons = new ArrayList<>();
    public boolean confirm = false;

    protected MainMenuScreen() {
        super(Text.of("THMainMenuScreen"));
        INSTANCE = this;

        buttons.add(new MainMenuButton(-60, I18n.translate("menu.singleplayer").toUpperCase(Locale.ROOT), () -> mc.setScreen(new SelectWorldScreen(this))));
        buttons.add(new MainMenuButton(-30, I18n.translate("menu.multiplayer").toUpperCase(Locale.ROOT), () -> mc.setScreen(new MultiplayerScreen(this))));
        buttons.add(new MainMenuButton(0, I18n.translate("menu.options").toUpperCase(Locale.ROOT).replace(".", ""), () -> mc.setScreen(new OptionsScreen(this, mc.options))));
        buttons.add(new MainMenuButton(30, "CLICKGUI", () -> ModuleManager.clickGui.setGui()));
        buttons.add(new MainMenuButton(60, I18n.translate("menu.quit").toUpperCase(Locale.ROOT), mc::scheduleStop));
    }

    private static MainMenuScreen INSTANCE = new MainMenuScreen();

    public static MainMenuScreen getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MainMenuScreen();
        }
        return INSTANCE;
    }

    public static boolean allowVanillaMenu = false;

    @Override
    public void render(@NotNull DrawContext context, int mouseX, int mouseY, float delta) {
        float halfOfWidth = mc.getWindow().getScaledWidth() / 2f;
        float halfOfHeight = mc.getWindow().getScaledHeight() / 2f;

        Render2DEngine.drawMainMenuShader(context.getMatrices(), 0, 0, halfOfWidth * 2f, halfOfHeight * 2);

        int padding = 5;
        String title = "Veltragossa " + veltragossa.VERSION;
        int x = padding;
        int y = padding;
        FontRenderers.sf_bold.drawString(context.getMatrices(), title, x, y, Theme.ACCENT_COLOR.getRGB());

        buttons.forEach(b -> b.onRender(context, mouseX, mouseY));
        renderSocials(context, mouseX, mouseY);
        boolean hovered = Render2DEngine.isHovered(mouseX, mouseY, halfOfWidth - 50, halfOfHeight + 100, 100, 10);
        FontRenderers.sf_medium.drawCenteredString(context.getMatrices(), "<-- Back to default menu", halfOfWidth, halfOfHeight + 100, hovered ? Theme.ACCENT_COLOR.getRGB() : Theme.SECONDARY_FONT_COLOR.getRGB());
    }
/*/ Online Users (nie działa): %s%s /*/
    private void renderSocials(DrawContext context, int mouseX, int mouseY) {
        float discordX = mc.getWindow().getScaledWidth() - 40;
        float discordY = mc.getWindow().getScaledHeight() - 40;
        boolean hoveredDiscord = Render2DEngine.isHovered(mouseX, mouseY, discordX, discordY, 30, 30);

        Render2DEngine.drawRound(context.getMatrices(), discordX, discordY, 30, 30, 5, hoveredDiscord ? Theme.BUTTON_HOVER_COLOR : Theme.BUTTON_COLOR);
        RenderSystem.setShaderColor(1f, 1f, 1f, hoveredDiscord ? 1f : 0.8f);
        context.drawTexture(TextureStorage.thTeam, (int) discordX, (int) discordY, 30, 30, 0, 0, 30, 30, 30, 30);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        float donateX = mc.getWindow().getScaledWidth() - 80;
        float donateY = mc.getWindow().getScaledHeight() - 40;
        boolean hoveredDonate = Render2DEngine.isHovered(mouseX, mouseY, donateX, donateY, 30, 30);

        Render2DEngine.drawRound(context.getMatrices(), donateX, donateY, 30, 30, 5, hoveredDonate ? Theme.BUTTON_HOVER_COLOR : Theme.BUTTON_COLOR);
        RenderSystem.setShaderColor(1f, 1f, 1f, hoveredDonate ? 1f : 0.8f);
        context.drawTexture(TextureStorage.donation, (int) donateX + 1, (int) donateY + 1, 28, 28, 0, 0, 30, 30, 30, 30);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        buttons.forEach(b -> b.onClick((int) mouseX, (int) mouseY));
        float halfOfWidth = mc.getWindow().getScaledWidth() / 2f;
        float halfOfHeight = mc.getWindow().getScaledHeight() / 2f;
        if (Render2DEngine.isHovered(mouseX, mouseY, halfOfWidth - 50, halfOfHeight + 100, 100, 10)) {
            confirm = true;
            allowVanillaMenu = true;
            mc.setScreen(new TitleScreen());
            return true;
        }
        if (Render2DEngine.isHovered(mouseX, mouseY, mc.getWindow().getScaledWidth() - 40, mc.getWindow().getScaledHeight() - 40, 30, 30))
            mc.setScreen(CreditsScreen.getInstance());
        if (Render2DEngine.isHovered(mouseX, mouseY, mc.getWindow().getScaledWidth() - 80, mc.getWindow().getScaledHeight() - 40, 30, 30))
            Util.getOperatingSystem().open(URI.create("dc.gg/veltragossa"));

        return super.mouseClicked(mouseX, mouseY, button);
    }
}