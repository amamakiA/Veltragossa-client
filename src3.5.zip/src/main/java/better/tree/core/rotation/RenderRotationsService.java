package better.tree.core.rotation;

public interface RenderRotationsService {
    void setMode(Mode m);
    void setOffsets(float yawOffsetDeg, float pitchOffsetDeg);
    void setSmoothing(boolean enabled, float factor, SmoothingType type);
    void setInterpolation(boolean enabled, float hz);
    void setFlags(Flags flags);
    void onInputRotation(float yaw, float pitch);
    Rotation getVisualRotation();
    Rotation getServerRotation();
    void forceSyncVRtoSR();
    void forceSyncSRtoVR();
    void tick(double deltaTimeSeconds);

    Flags getFlags();
    Mode getMode();
    float getYawOffset();
    float getPitchOffset();

    enum SmoothingType { LINEAR, EXP, CRITICALLY_DAMPED }

    final class Rotation {
        public float yaw;
        public float pitch;
        public Rotation() {}
        public Rotation(float yaw, float pitch) { this.yaw = yaw; this.pitch = pitch; }
        public Rotation set(float y, float p) { this.yaw = y; this.pitch = p; return this; }
        public Rotation copy() { return new Rotation(yaw, pitch); }
    }

    final class Flags {
        public boolean syncOnAttack;
        public boolean syncOnPlace;
        public boolean syncOnUse;
        public boolean onlyWhileMoving;
        public boolean disableInGUI;
        public boolean thirdPersonAffectsBody;
        public boolean clampYawRange;
        public float minYaw, maxYaw;
        public boolean clampPitchRange;
        public float minPitch, maxPitch;
        public boolean raycastUsesVR;
        public SyncStrategy syncStrategy = SyncStrategy.SRtoVR;

        public enum SyncStrategy { SRtoVR, VRtoSR }
    }
}
