package better.tree.core.rotation;

public enum Mode {
    OFF,
    VISUAL_ONLY,
    SERVER_SPOOF,
    DESYNC,
    STATIC
}
