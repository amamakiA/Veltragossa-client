package better.tree.core.rotation;

import better.tree.core.manager.client.ModuleManager;
import better.tree.core.manager.player.PlayerManager;
import better.tree.events.impl.*;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;

import static better.tree.features.modules.Module.mc;

public class RenderRotationsManager implements RenderRotationsService {
    private Mode mode = Mode.OFF;
    private final Rotation IR = new Rotation();
    private final Rotation VR = new Rotation();
    private final Rotation SR = new Rotation();
    private final Rotation targetVR = new Rotation();
    private final Rotation targetSR = new Rotation();

    private float yawOffset;
    private float pitchOffset;

    private boolean smoothingEnabled;
    private float smoothingFactor = 10f;
    private SmoothingType smoothingType = SmoothingType.EXP;

    private boolean interpolationEnabled;
    private float interpolationHz = 60f;

    private final Flags flags = new Flags();

    private long lastTickNanos = System.nanoTime();
    private boolean guiOpen;

    public RenderRotationsManager() {
        // defaults
    }

    @Override public void setMode(Mode m) { this.mode = m; }
    @Override public void setOffsets(float yawOffsetDeg, float pitchOffsetDeg) { this.yawOffset = yawOffsetDeg; this.pitchOffset = pitchOffsetDeg; }
    @Override public void setSmoothing(boolean enabled, float factor, SmoothingType type) { this.smoothingEnabled = enabled; this.smoothingFactor = factor; this.smoothingType = type; }
    @Override public void setInterpolation(boolean enabled, float hz) { this.interpolationEnabled = enabled; this.interpolationHz = hz; }
    @Override public void setFlags(Flags f) { if (f != null) { copyFlags(f, this.flags); } }
    @Override public void onInputRotation(float yaw, float pitch) { IR.set(yawNorm(yaw), clampPitch(pitch)); }
    @Override public Rotation getVisualRotation() { return VR.copy(); }
    @Override public Rotation getServerRotation() { return SR.copy(); }
    @Override public void forceSyncVRtoSR() { VR.set(SR.yaw, SR.pitch); }
    @Override public void forceSyncSRtoVR() { SR.set(VR.yaw, VR.pitch); }
    @Override public void tick(double dt) { computeTargets(); applySmoothingAndInterpolation((float) dt); }

    @Override public Flags getFlags() { return flags; }
    @Override public Mode getMode() { return mode; }
    @Override public float getYawOffset() { return yawOffset; }
    @Override public float getPitchOffset() { return pitchOffset; }

    // Events
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSync(EventSync e) {
        if (mc.player == null) return;
        // Treat current player yaw/pitch as IR for this tick
        onInputRotation(mc.player.getYaw(), mc.player.getPitch());

        // Update time and tick service
        long now = System.nanoTime();
        double dt = (now - lastTickNanos) / 1_000_000_000.0;
        lastTickNanos = now;
        // Fallback dt
        if (dt <= 0 || dt > 0.5) dt = 1.0 / 60.0;
        tick(dt);

        // Disable in GUI / onlyWhileMoving
        if ((flags.disableInGUI && guiOpen) || (flags.onlyWhileMoving && PlayerManager.mc.player != null && PlayerManager.mc.player.input != null && Math.abs(PlayerManager.mc.player.input.movementForward) + Math.abs(PlayerManager.mc.player.input.movementSideways) == 0)) {
            return; // do not alter SR
        }

        // In OFF/VISUAL_ONLY, SR should be IR
        if (mode == Mode.OFF || mode == Mode.VISUAL_ONLY) return;

        // For SERVER_SPOOF/DESYNC/STATIC: override the yaw/pitch used for sending packets by setting player rotations now,
        // and schedule a restore via postAction.
        final float origYaw = mc.player.getYaw();
        final float origPitch = mc.player.getPitch();
        mc.player.setYaw(SR.yaw);
        mc.player.setPitch(SR.pitch);
        e.addPostAction(() -> {
            // Restore after packets were sent
            mc.player.setYaw(origYaw);
            mc.player.setPitch(origPitch);
        });
    }

    @EventHandler
    public void onScreen(EventScreen e) {
        guiOpen = e.getScreen() != null;
    }

    @EventHandler
    public void onAttack(EventAttack e) {
        if (flags.syncOnAttack) doSync();
    }

    @EventHandler
    public void onPlace(EventPlaceBlock e) {
        if (flags.syncOnPlace) doSync();
    }

    private void doSync() {
        if (flags.syncStrategy == RenderRotationsService.Flags.SyncStrategy.SRtoVR) forceSyncVRtoSR();
        else forceSyncSRtoVR();
    }

    // Core logic
    private void computeTargets() {
        switch (mode) {
            case OFF -> {
                targetVR.set(IR.yaw, IR.pitch);
                targetSR.set(IR.yaw, IR.pitch);
            }
            case VISUAL_ONLY -> {
                setFrom(IR, targetVR, yawOffset, pitchOffset);
                clampRotation(targetVR);
                targetSR.set(IR.yaw, IR.pitch);
            }
            case SERVER_SPOOF -> {
                targetVR.set(IR.yaw, IR.pitch);
                setFrom(IR, targetSR, yawOffset, pitchOffset);
                clampRotation(targetSR);
            }
            case DESYNC -> {
                setFrom(IR, targetVR, yawOffset, pitchOffset);
                clampRotation(targetVR);
                // SR could be smoothed IR without offsets as default
                targetSR.set(IR.yaw, IR.pitch);
            }
            case STATIC -> {
                // In absence of a separate static config, use offsets relative to 0
                targetVR.set(yawNorm(yawOffset), clampPitch(pitchOffset));
                // SR follows IR by default here
                targetSR.set(IR.yaw, IR.pitch);
            }
        }
    }

    private void applySmoothingAndInterpolation(float dt) {
        if (smoothingEnabled) {
            smoothTowards(VR, targetVR, dt);
            smoothTowards(SR, targetSR, dt);
        } else {
            VR.set(targetVR.yaw, targetVR.pitch);
            SR.set(targetSR.yaw, targetSR.pitch);
        }
    }

    private void smoothTowards(Rotation curr, Rotation tgt, float dt) {
        float dy = yawDelta(curr.yaw, tgt.yaw);
        float dp = tgt.pitch - curr.pitch;
        switch (smoothingType) {
            case LINEAR -> {
                float maxDelta = smoothingFactor * dt * 360f;
                float ay = clampAbs(dy, maxDelta);
                float ap = clampAbs(dp, maxDelta);
                curr.yaw = yawNorm(curr.yaw + ay);
                curr.pitch = curr.pitch + ap;
            }
            case EXP -> {
                float k = 1f - (float) Math.exp(-smoothingFactor * dt);
                curr.yaw = yawNorm(curr.yaw + dy * k);
                curr.pitch = curr.pitch + dp * k;
            }
            case CRITICALLY_DAMPED -> {
                // Simplified overdamped approach
                float kcd = smoothingFactor;
                float a = 1f - (float) Math.exp(-kcd * dt) * (1f + kcd * dt);
                curr.yaw = yawNorm(curr.yaw + dy * a);
                curr.pitch = curr.pitch + dp * a;
            }
        }
        curr.pitch = clampPitch(curr.pitch);
    }

    // Helpers
    private void setFrom(Rotation base, Rotation out, float yOff, float pOff) {
        out.set(yawNorm(base.yaw + yOff), clampPitch(base.pitch + pOff));
    }

    private void clampRotation(Rotation r) {
        r.pitch = clampPitch(r.pitch);
        r.yaw = yawNorm(r.yaw);
        if (flags.clampYawRange) r.yaw = Math.max(flags.minYaw, Math.min(flags.maxYaw, r.yaw));
        if (flags.clampPitchRange) r.pitch = Math.max(flags.minPitch, Math.min(flags.maxPitch, r.pitch));
    }

    private float clampPitch(float p) {
        // Minecraft pitch is [-90, 90]
        return Math.max(-90f, Math.min(90f, p));
    }

    private float yawNorm(float y) {
        y = (y + 180f) % 360f;
        if (y < 0) y += 360f;
        return y - 180f;
    }

    private float yawDelta(float from, float to) {
        float d = yawNorm(to - from);
        return d;
    }

    private float clampAbs(float v, float max) {
        if (v > max) return max;
        if (v < -max) return -max;
        return v;
    }

    private static void copyFlags(Flags src, Flags dst) {
        dst.syncOnAttack = src.syncOnAttack;
        dst.syncOnPlace = src.syncOnPlace;
        dst.syncOnUse = src.syncOnUse;
        dst.onlyWhileMoving = src.onlyWhileMoving;
        dst.disableInGUI = src.disableInGUI;
        dst.thirdPersonAffectsBody = src.thirdPersonAffectsBody;
        dst.clampYawRange = src.clampYawRange;
        dst.minYaw = src.minYaw;
        dst.maxYaw = src.maxYaw;
        dst.clampPitchRange = src.clampPitchRange;
        dst.minPitch = src.minPitch;
        dst.maxPitch = src.maxPitch;
        dst.raycastUsesVR = src.raycastUsesVR;
        dst.syncStrategy = src.syncStrategy;
    }
}
