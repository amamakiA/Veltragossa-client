package better.tree.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import better.tree.features.cmd.Command;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static better.tree.features.modules.client.ClientSettings.isRu;

public class GetNbtCommand extends Command {
    public GetNbtCommand() {
        super("nbt", "getnbt");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            sendMessage(mc.player.getMainHandStack().getComponents() != null ? (Formatting.GREEN + mc.player.getMainHandStack().getComponents().toString()) : (Formatting.RED + (isRu() ? "У этого предмета нет nbt тегов!" : "This item don't contains nbt tags!")));
            return SINGLE_SUCCESS;
        });
    }
}