package better.tree.features.cmd.impl;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.time.LocalDate;
import java.util.prefs.Preferences;

import static better.tree.veltragossa.VERSION;

public class DailyMessage {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Preferences prefs = Preferences.userRoot().node("veltragossa_client");

    private static boolean sentToday = false;
    private static boolean joinedWorld = false;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (mc.player != null && mc.world != null && !joinedWorld) {
                joinedWorld = true;
                sendDailyMessage();
            }
        });
    }

    private static void sendDailyMessage() {
        if (sentToday) return;

        LocalDate lastDate = LocalDate.MIN;
        String lastDateStr = prefs.get("lastMessageDate", "");
        if (!lastDateStr.isEmpty()) {
            try {
                lastDate = LocalDate.parse(lastDateStr);
            } catch (Exception ignored) { }
        }

        LocalDate today = LocalDate.now();

        if (!today.equals(lastDate) && mc.player != null) {
            String nick = mc.player.getName().getString();
            mc.player.sendMessage(Text.literal("")
                            .append(Text.literal(nick + " ").formatted(Formatting.DARK_PURPLE))
                            .append(Text.literal("Siema, dzięki że korzystasz z ").formatted(Formatting.AQUA))
                            .append(Text.literal("Veltragossa Client " + VERSION + ". ").formatted(Formatting.LIGHT_PURPLE))
                            .append(Text.literal("Mam nadzieję, że wspierasz Mevinga i należysz do grupy <3. ").formatted(Formatting.YELLOW))
                            .append(Text.literal("Jeśli nie, tu masz link: dc.gg/veltragossai").formatted(Formatting.DARK_RED))
                    , false);

            prefs.put("lastMessageDate", today.toString());
            sentToday = true;
        }
    }
}