package better.tree.features.modules.client;

import better.tree.gui.Theme;
import better.tree.gui.hud.HudEditorGui;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;
import java.util.Arrays;
import java.util.List;

import java.awt.*;

public final class HudEditor extends Module {
    public static final Setting<HudStyle> hudStyle = new Setting<>("HudStyle", HudStyle.Glowing);

    public static final Setting<Boolean> sticky = new Setting<>("Sticky", true);
    public static final Setting<ArrowsStyle> arrowsStyle = new Setting<>("ArrowsStyle", ArrowsStyle.New);
    public static final Setting<ColorMode> colorMode = new Setting<ColorMode>("Theme", ColorMode.Lavender);
    public static final Setting<Integer> colorSpeed = new Setting<>("ColorSpeed", 18, 2, 54);
    public static final Setting<Boolean> glow = new Setting<>("Light", true);


    public static final Setting<ColorSetting> hcolor1 = new Setting<>("Color", new ColorSetting(-6974059));
    public static final Setting<ColorSetting> acolor = new Setting<>("Color2", new ColorSetting(-8365735));
    public static final Setting<ColorSetting> plateColor = new Setting<>("PlateColor", new ColorSetting(new Color(0xE7000000, true).getRGB()));
    public static final Setting<ColorSetting> textColor = new Setting<>("TextColor", new ColorSetting(new Color(0xFFFFFFFF, true).getRGB()));
    public static final Setting<ColorSetting> textColor2 = new Setting<>("TextColor2", new ColorSetting(new Color(0xFFFFFFFF, true).getRGB()));
    /*/public static final Setting<ColorSetting> blurColor = new Setting<>("BlurColor", new ColorSetting(new Color(0xFF000E25, true).getRGB()));/*/
    public static final Setting<Float> hudRound = new Setting<>("HudRound", 4f, 1f, 7f);
    public static final Setting<Float> alpha = new Setting<>("Alpha", 0.66f, 0f, 1f);
    public static final Setting<Float> blend = new Setting<>("Blend", 10f, 1f, 15f);
    public static final Setting<Float> outline = new Setting<>("Outline", 0.5f, 0f, 2.5f);
    public static final Setting<Float> glow1 = new Setting<>("Glow", 0.5f, 0f, 1f);
    public static final Setting<Float> blurOpacity = new Setting<>("BlurOpacity", 0.55f, 0f, 1f);
    public static final Setting<Float> blurStrength = new Setting<>("BlurStrength", 20f, 5f, 50f);
    public static final List<Theme> THEMES = Arrays.asList(new Theme("Violet Blue", new Color(5518335), new Color(65535)), new Theme("Aciomek", new Color(0xFFC0CB), new Color(0xFF69B4)), new Theme("Candy", new Color(0xFC00FF), new Color(56286)), new Theme("Lilac", new Color(13148872), new Color(12139407)), new Theme("Raspberry Mint", new Color(471946), new Color(30975)), new Theme("Superman", new Color(39415), new Color(15800082)), new Theme("Ruby", new Color(14684511), new Color(10162462)), new Theme("Cosmos", new Color(12793700), new Color(1910385)), new Theme("Amethyst Yellow", new Color(9323501), new Color(15781515)), new Theme("Peach", new Color(16763812), new Color(16022628)), new Theme("Lavender", new Color(11894492), new Color(8343744)), new Theme("Moonlight", new Color(5518335), new Color(10878667)), new Theme("Purple Sea", new Color(8609987), new Color(3063697)), new Theme("Sunset", new Color(16729344), new Color(16753920)), new Theme("Orange Pink", new Color(16737095), new Color(16738740)), new Theme("Blueberry", new Color(2697533), new Color(0x5A5A7A)), new Theme("Eucalyptus", new Color(4511656), new Color(25666)), new Theme("Mint Chocolate", new Color(10025880), new Color(25600)), new Theme("Raspberry Smoothie", new Color(16758465), new Color(16716947)), new Theme("Frostbite", new Color(65535), new Color(13107)), new Theme("Cold berry", new Color(14011626), new Color(4792186)), new Theme("Stormy Sea", new Color(4282576), new Color(0x151515)), new Theme("Sunset Glow", new Color(16729344), new Color(0x1E0E00)), new Theme("Crimson Dawn", new Color(11730971), new Color(17762319)), new Theme("Raspberry Beach", new Color(9175066), new Color(16734003)), new Theme("Moss", new Color(1265246), new Color(7451264)), new Theme("Coral", new Color(16744272), new Color(16729344)), new Theme("Golden Night", new Color(16765184), new Color(0x202020)));


    public HudEditor() {
        super("HudEditor", Module.Category.CLIENT);
    }

    public static Color getColor(int count) {
        switch (colorMode.getValue().ordinal()) {
            case 0: {
                return HudEditor.getThemeDoubleColor(0, count);
            }
            case 1: {
                return HudEditor.getThemeDoubleColor(1, count);
            }
            case 2: {
                return HudEditor.getThemeDoubleColor(2, count);
            }
            case 3: {
                return HudEditor.getThemeDoubleColor(3, count);
            }
            case 4: {
                return HudEditor.getThemeDoubleColor(4, count);
            }
            case 5: {
                return HudEditor.getThemeDoubleColor(5, count);
            }
            case 6: {
                return HudEditor.getThemeDoubleColor(6, count);
            }
            case 7: {
                return HudEditor.getThemeDoubleColor(7, count);
            }
            case 8: {
                return HudEditor.getThemeDoubleColor(8, count);
            }
            case 9: {
                return HudEditor.getThemeDoubleColor(9, count);
            }
            case 10: {
                return HudEditor.getThemeDoubleColor(10, count);
            }
            case 11: {
                return HudEditor.getThemeDoubleColor(11, count);
            }
            case 12: {
                return HudEditor.getThemeDoubleColor(12, count);
            }
            case 13: {
                return HudEditor.getThemeDoubleColor(13, count);
            }
            case 14: {
                return HudEditor.getThemeDoubleColor(14, count);
            }
            case 15: {
                return HudEditor.getThemeDoubleColor(15, count);
            }
            case 16: {
                return HudEditor.getThemeDoubleColor(16, count);
            }
            case 17: {
                return HudEditor.getThemeDoubleColor(17, count);
            }
            case 18: {
                return HudEditor.getThemeDoubleColor(18, count);
            }
            case 19: {
                return HudEditor.getThemeDoubleColor(19, count);
            }
            case 20: {
                return HudEditor.getThemeDoubleColor(20, count);
            }
            case 21: {
                return HudEditor.getThemeDoubleColor(21, count);
            }
            case 22: {
                return HudEditor.getThemeDoubleColor(22, count);
            }
            case 23: {
                return HudEditor.getThemeDoubleColor(23, count);
            }
            case 24: {
                return HudEditor.getThemeDoubleColor(24, count);
            }
            case 25: {
                return HudEditor.getThemeDoubleColor(25, count);
            }
            case 26: {
                return HudEditor.getThemeDoubleColor(26, count);
            }
        }
        return Color.WHITE;
    }
    public static Color getBlurColor() {
        Theme theme = THEMES.get(colorMode.getValue().ordinal());
        Color base = theme.color1;
        return new Color(base.getRed(), base.getGreen(), base.getBlue(), (int)(blurOpacity.getValue() * 255));
    }

    private static Color getThemeDoubleColor(int themeIdx, int count) {
        if (themeIdx < 0 || themeIdx >= THEMES.size()) {
            themeIdx = 0;
        }
        Theme theme = THEMES.get(themeIdx);
        return Render2DEngine.TwoColoreffect(theme.color1, theme.color2, colorSpeed.getValue().intValue(), count);
    }

    public static HudStyle getHudStyle() {
        return HudStyle.Glowing;
    }

    @Override
    public void onEnable() {
        mc.setScreen(HudEditorGui.getHudGui());
        disable();
    }

    public enum ArrowsStyle {
        Default, New
    }
    public static enum ColorMode {
        VioletBlue,
        Candy,
        Aciomek,
        Lilac,
        RaspberryMint,
        Superman,
        Ruby,
        Cosmos,
        AmethystYellow,
        Peach,
        Lavender,
        Moonlight,
        PurpleSea,
        Sunset,
        OrangePink,
        Blueberry,
        Eucalyptus,
        MintChocolate,
        RaspberrySmoothie,
        Frostbite,
        Coldberry,
        StormySea,
        SunsetGlow,
        CrimsonDawn,
        RaspberryBeach,
        Moss,
        Coral,
        GoldenNight;

    }

    public static class Theme {
        public final String name;
        public final Color color1;
        public final Color color2;

        public Theme(String name, Color color1, Color color2) {
            this.name = name;
            this.color1 = color1;
            this.color2 = color2;
        }
    }
    public enum HudStyle {
        Blurry, Glowing
    }
}