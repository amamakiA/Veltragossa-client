package better.tree.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.features.modules.Module.Category;
import better.tree.setting.Setting;

public class VehicleBoost extends Module {

    public VehicleBoost() {
        super("VehicleBoost", Category.MOVEMENT);
    }

    private final Setting<Float> horizontalSpeed = new Setting<>("HorizontalSpeed", 0.1f, 0.1f, 10.0f);
    private final Setting<Float> verticalSpeed = new Setting<>("VerticalSpeed", 1.5f, 0.1f, 5.0f);
    private boolean wasInVehicle = false;

    @Override
    public void onEnable() {
        wasInVehicle = mc.player != null && mc.player.hasVehicle();
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (mc.player == null || mc.world == null) return;
        boolean isInVehicle = mc.player.hasVehicle();
        if (wasInVehicle && !isInVehicle) {
            double angle = Math.toRadians(mc.player.getYaw());
            double sinAngle = Math.sin(angle);
            double cosAngle = Math.cos(angle);
            mc.player.setVelocity(-sinAngle * horizontalSpeed.getValue(), verticalSpeed.getValue(), cosAngle * horizontalSpeed.getValue());
        }
        wasInVehicle = isInVehicle;
    }

    @Override
    public void onDisable() {
        wasInVehicle = false;
    }
}