package better.tree.features.modules.player;

import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public class NoInteract extends Module {
    public NoInteract() {
        super("NoInteract", Category.PLAYER);
    }

    public static Setting<Boolean> onlyAura = new Setting<>("OnlyAura", true);
}