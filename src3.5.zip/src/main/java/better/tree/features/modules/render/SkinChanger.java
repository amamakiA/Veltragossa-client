package better.tree.features.modules.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public final class SkinChanger extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final Setting<SkinType> skinType = new Setting<>("Skin", SkinType.MEVINGGS);
    public final Setting<Boolean> onlySelf = new Setting<>("OnlySelf", true);
    public final Setting<Boolean> friends = new Setting<>("Friends", true, v -> onlySelf.getValue());

    public SkinChanger() {
        super("SkinChanger", Category.RENDER);
    }

    public enum SkinType {

        PAPAJ("papiesz.png"),
        VIDA("vida.png"),
        VIDAV2("vidav2.png"),
        MEVINGGS("mevinggs.png"),

        DIRCIOPA("dirciopa.png"),
        Njhh_ ("njhh.png"),
        HITLER("hitl3r.png"),
        GWUID("gwuid.png"),
        _M4G1K("m4agik.png"),

        HEXERN_PL("jakisnn.png"),

        OFF("none");

        private final String fileName;

        SkinType(String fileName) {
            this.fileName = fileName;
        }

        public String getFileName() {
            return fileName;
        }
    }

    public Identifier getSkinTexture(AbstractClientPlayerEntity player) {
        if (!isEnabled() || skinType.getValue() == SkinType.OFF) return null;

        boolean isSelf = player == mc.player;
        boolean isFriend = Managers.FRIEND.isFriend(player);

        if (onlySelf.getValue() && !isSelf) {
            if (!friends.getValue() || !isFriend) return null;
        }

        return Identifier.of("veltragossa", "textures/skins/" + skinType.getValue().getFileName());
    }
}