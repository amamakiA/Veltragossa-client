package better.tree.features.modules.movement;

import better.tree.features.modules.Module;

public class EntityControl extends Module {
    public EntityControl() {
        super("EntityControl", Category.MOVEMENT);
    }
}