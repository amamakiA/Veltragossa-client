/*/package better.tree.features.modules.movement;


















GOWNO KOD BY AMNEZJA (chujowy kod nic nie robi xdddxxxddd)




import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.interfaces.IEntityLiving;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ServDealyer extends Module {
    private final Setting<Boolean> playerESPPosition = new Setting<>("PlayerESPPosition", false);
    private final Map<UUID, Vec3d> pinned = new HashMap<>();

    public ServDealyer() {
        super("ServDealyer", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck()) return;
        pinned.clear();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            pinned.put(p.getUuid(), p.getPos());
        }
    }

    @Override
    public void onDisable() {
        pinned.clear();
    }

    @EventHandler
    private void onTick(EventTick e) {
        if (fullNullCheck()) return;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            pinned.computeIfAbsent(p.getUuid(), id -> p.getPos());
            Vec3d pos = pinned.get(p.getUuid());
            p.setPosition(pos.x, pos.y, pos.z);
        }
    }

    @Override
    public void onRender3D(@NotNull MatrixStack stack) {
        if (fullNullCheck() || !playerESPPosition.getValue()) return;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;

            IEntityLiving il = (IEntityLiving) p;
            double sx = il.getPrevServerX();
            double sy = il.getPrevServerY();
            double sz = il.getPrevServerZ();

            if (sx == 0 && sy == 0 && sz == 0) continue;

            Box bb = p.getBoundingBox();
            double wX = bb.maxX - bb.minX;
            double wZ = bb.maxZ - bb.minZ;
            double h = bb.maxY - bb.minY;

            Box sBox = new Box(
                    sx - wX / 2.0, sy, sz - wZ / 2.0,
                    sx + wX / 2.0, sy + h, sz + wZ / 2.0
            );

            Render3DEngine.drawBoxOutline(sBox, new Color(0, 200, 255, 180), 2.0f);
        }
    }
} /*/