package better.tree.features.modules.misc;

import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class AntiCheatDetector extends Module {

    private final List<Short> actionNumbers = new ArrayList<>();
    private boolean checking = false;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public AntiCheatDetector() {
        super("ACDetector", Category.MISC);
    }

    @Override
    public void onEnable() {
        checking = true;
        actionNumbers.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        reset();
        super.onDisable();
    }


    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        if (!checking) return;

        if (e.getPacket() instanceof GameJoinS2CPacket) {
            reset();
            checking = true;
            return;
        }

        Packet<?> packet = e.getPacket();


        if (packet.getClass().getSimpleName().contains("ConfirmScreenHandlerAction") ||
                packet.getClass().getSimpleName().contains("Transaction")) {

            try {

                Field actionIdField = null;


                try {
                    actionIdField = packet.getClass().getDeclaredField("actionId");
                } catch (NoSuchFieldException ignored) {

                }

                if (actionIdField != null) {
                    actionIdField.setAccessible(true);


                    if (actionIdField.getType() == short.class) {
                        short actionId = actionIdField.getShort(packet);
                        handleTransaction(actionId);
                    }
                }

            } catch (Exception ex) {

            }
        }
    }



    private void reset() {
        actionNumbers.clear();
        checking = false;
    }

    private void handleTransaction(short action) {
        actionNumbers.add(action);
        if (actionNumbers.size() >= 5) {
            analyzeActionNumbers();
        }
    }



    private void analyzeActionNumbers() {
        if (actionNumbers.size() < 5) return;


        List<Short> diffs = new ArrayList<>();
        for (int i = 0; i < actionNumbers.size() - 1; i++) {
            short diff = (short) (actionNumbers.get(i + 1) - actionNumbers.get(i));
            diffs.add(diff);
        }

        short firstAction = actionNumbers.get(0);
        String detectedAC = null;


        boolean allDiffsEqual = diffs.stream().allMatch(d -> d.equals(diffs.get(0)));
        if (allDiffsEqual) {
            short diff = diffs.get(0);

            if (diff == 1) {
                if (firstAction >= -23772 && firstAction <= -23762) detectedAC = "Vulcan";
                else if ((firstAction >= 95 && firstAction <= 105) || (firstAction >= -20005 && firstAction <= -19995)) detectedAC = "Matrix";
                else if (firstAction >= -32773 && firstAction <= -32762) detectedAC = "Grizzly";
                else detectedAC = "Verus";
            } else if (diff == -1) {
                if (firstAction >= -8287 && firstAction <= -8280) detectedAC = "Errata";
                else if (firstAction < -3000) detectedAC = "Intave";
                else if (firstAction >= -5 && firstAction <= 0) detectedAC = "Grim";
                else if (firstAction >= -3000 && firstAction <= -2995) detectedAC = "Karhu";
                else detectedAC = "not found";
            }
        }


        if (detectedAC == null && actionNumbers.size() >= 4) {
            boolean verusPattern = actionNumbers.get(0).equals(actionNumbers.get(1));
            if (verusPattern && diffs.size() > 2) {
                boolean restIncreaseByOne = diffs.subList(2, diffs.size()).stream().allMatch(d -> d == 1);
                if (restIncreaseByOne) detectedAC = "Verus";
            }
        }


        if (detectedAC == null && diffs.size() >= 4) {
            if (diffs.get(0) >= 100 && diffs.get(1) == -1) {
                boolean restDecreaseByOne = diffs.subList(2, diffs.size()).stream().allMatch(d -> d == -1);
                if (restDecreaseByOne) detectedAC = "Grim / Polar";
            }
        }


        if (detectedAC == null) {
            if (firstAction < -3000 && actionNumbers.contains((short) 0)) detectedAC = "Intave";
        }


        if (detectedAC == null && actionNumbers.size() >= 5) {
            if (actionNumbers.get(0) == -30767 && actionNumbers.get(1) == -30766 && actionNumbers.get(2) == -25767) {
                boolean restIncreaseByOne = diffs.subList(3, diffs.size()).stream().allMatch(d -> d == 1);
                if (restIncreaseByOne) detectedAC = "Old Vulcan";
            }
        }

        if (detectedAC != null) {
            notifyAC(detectedAC);
        }

        reset();
    }



    private void notifyAC(String acName) {
        if (!checking || mc.player == null) return;

        String message = "§7[ACDetector] §aDetected AntiCheat: §f" + acName + "§a. Toggling off.";
        mc.player.sendMessage(Text.literal(message), false);


        toggle();
    }
}