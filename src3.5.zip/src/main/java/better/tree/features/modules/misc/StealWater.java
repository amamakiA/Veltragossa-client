package better.tree.features.modules.misc;

import java.awt.Color;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.item.Item;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import better.tree.events.impl.EventSync;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.Timer;
import better.tree.utility.player.InteractionUtility;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.player.SearchInvResult;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

@Environment(EnvType.CLIENT)
public class StealWater extends Module {
    private final Setting<Integer> range = new Setting<>("Range", 5, 1, 7);
    private final Setting<InteractionUtility.Rotate> rotate = new Setting<>("Rotate", InteractionUtility.Rotate.None);
    private final Setting<RenderMode> renderMode = new Setting<>("Render Mode", RenderMode.Fade);
    private final Setting<ColorSetting> renderFillColor = new Setting<>("Render Fill Color", new ColorSetting(0x55FFFFFF));
    private final Setting<ColorSetting> renderLineColor = new Setting<>("Render Line Color", new ColorSetting(0x00000000), v -> false);
    private final Setting<Integer> renderLineWidth = new Setting<>("Render Line Width", 0, 1, 5, v -> false);
    private final Setting<Integer> effectDurationMs = new Setting<>("Effect Duration (MS)", 500, 0, 10000);

    private boolean retrieveFlag;
    private final Map<BlockPos, Long> renderPoses = new ConcurrentHashMap<>();
    public static Timer inactivityTimer = new Timer();

    public StealWater() {
        super("StealWater", Category.MISC);
    }

    @EventHandler
    public void onSync(EventSync event) {
        if (fullNullCheck()) return;

        BlockPos playerPos = mc.player.getBlockPos();

        for (BlockPos pos : BlockPos.iterateOutwards(
                playerPos.down(2),
                range.getValue(),
                2,
                range.getValue()
        )) {
            BlockState blockState = mc.world.getBlockState(pos);

            if (blockState.getBlock() != Blocks.WATER || !blockState.getFluidState().isStill()) continue;

            if (!isWaterAccessible(pos) || !collectWater(pos)) continue;

            renderPoses.put(pos, System.currentTimeMillis());
            break;
        }

        if (retrieveFlag) {
            retrieveWater();
            retrieveFlag = false;
        }
    }

    private boolean isWaterAccessible(BlockPos waterPos) {
        Vec3d playerEyePos = mc.player.getCameraPosVec(1.0f);
        Vec3d targetVec = new Vec3d(
                waterPos.getX() + 0.5,
                waterPos.getY() + 0.5,
                waterPos.getZ() + 0.5
        );

        BlockHitResult result = mc.world.raycast(new RaycastContext(
                playerEyePos,
                targetVec,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.ANY,
                mc.player
        ));

        return result.getType() == HitResult.Type.MISS || result.getBlockPos().equals(waterPos);
    }

    private boolean collectWater(BlockPos pos) {
        SearchInvResult bucketResult = InventoryUtility.findItemInHotBar(new Item[]{Items.BUCKET});
        if (!bucketResult.found()) return false;
        double deltaX = pos.getX() + 0.5 - mc.player.getX();
        double deltaY = pos.getY() + 0.5 - (mc.player.getY() + mc.player.getStandingEyeHeight());
        double deltaZ = pos.getZ() + 0.5 - mc.player.getZ();
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);

        float yaw = (float)(Math.atan2(deltaZ, deltaX) * 57.29577951308232) - 90.0f;
        float pitch = (float)(-(Math.atan2(deltaY, distance) * 57.29577951308232));

        if (rotate.getValue() != InteractionUtility.Rotate.None) {
            mc.player.setYaw(yaw);
            mc.player.setPitch(pitch);
        }

        BlockHitResult hitResult = new BlockHitResult(
                new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5),
                Direction.UP,
                pos,
                false
        );

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
        mc.player.swingHand(Hand.MAIN_HAND);

        retrieveFlag = true;
        inactivityTimer.reset();
        return true;
    }

    private void retrieveWater() {
        InventoryUtility.saveSlot();
        SearchInvResult bucketResult = InventoryUtility.findItemInHotBar(new Item[]{Items.BUCKET});
        if (bucketResult.found()) {
            bucketResult.switchTo();
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.swingHand(Hand.MAIN_HAND);
            InventoryUtility.returnSlot();
        }
    }

    public void onRender3D(MatrixStack stack) {
        renderPoses.forEach((pos, time) -> {
            if (System.currentTimeMillis() - time > effectDurationMs.getValue()) {
                renderPoses.remove(pos);
            } else {
                switch (renderMode.getValue()) {
                    case Fade -> {
                                                float alpha = 1.0f - (float)(System.currentTimeMillis() - time) / effectDurationMs.getValue();
                        Color fill = Render2DEngine.injectAlpha(renderFillColor.getValue().getColorObject(), (int)(100 * alpha));
                        Color line = Render2DEngine.injectAlpha(renderLineColor.getValue().getColorObject(), (int)(100 * alpha));
                        Render3DEngine.drawFilledBox(stack, new Box(pos), fill);
                        Render3DEngine.drawBoxOutline(new Box(pos), line, renderLineWidth.getValue());
                        
                    }
                }
            }
        });
    }

    @Environment(EnvType.CLIENT)
    public enum RenderMode {
        Fade
    }
}