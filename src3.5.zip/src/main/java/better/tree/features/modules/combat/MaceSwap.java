package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.item.Item;
import net.minecraft.item.SwordItem;
import net.minecraft.item.AxeItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import better.tree.core.manager.client.ModuleManager;
import better.tree.events.impl.EventAttack;
import better.tree.events.impl.EventPostSync;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.player.SearchInvResult;

public class MaceSwap extends Module {
    private final Setting<Boolean> enableWindBurst = new Setting<>("WindBurst", true);
    private final Setting<Boolean> enableBreach = new Setting<>("Breach", true);
    private final Setting<Boolean> onlySword = new Setting<>("OnlySword", false);
    private final Setting<Boolean> onlyAxe = new Setting<>("OnlyAxe", false);
    private final Setting<Boolean> switchBack = new Setting<>("SwitchBack", true);
    private final Setting<Integer> switchBackDelay = new Setting<>("SwitchBackDelay", 200, 0, 1000);

    private int originalSlot = -1;
    private long switchTime = 0L;
    private boolean switched = false;

    public MaceSwap() {
        super("MaceSwap", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        resetState();
        super.onDisable();
    }

    @EventHandler
    protected void onAttack(EventAttack event) {
        handleMaceSwap();
    }

    @EventHandler
    public void onPostSync(EventPostSync event) {
        if (ModuleManager.aura != null && ModuleManager.aura.isEnabled() && Aura.target != null) {
            handleMaceSwap();
        }
        handleSwitchBack();
    }

    private void handleMaceSwap() {
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null) return;

        if (!isValidWeapon(player.getMainHandStack().getItem())) return;

        if (originalSlot == -1) {
            originalSlot = player.getInventory().selectedSlot;
        }


        SearchInvResult maceResult;
        if ((enableWindBurst.getValue() && enableBreach.getValue()) || (!enableWindBurst.getValue() && !enableBreach.getValue())) {
            maceResult = InventoryUtility.findInHotBar(stack -> stack.getItem() == Items.MACE);
        } else if (enableWindBurst.getValue()) {
            maceResult = InventoryUtility.findInHotBar(stack -> stack.getItem() == Items.MACE && stack.hasEnchantments() && stack.getEnchantments().toString().contains("wind_burst"));
        } else {
            maceResult = InventoryUtility.findInHotBar(stack -> stack.getItem() == Items.MACE && stack.hasEnchantments() && stack.getEnchantments().toString().contains("breach"));
        }

        if (!maceResult.found()) return;

        sendPacket(new UpdateSelectedSlotC2SPacket(maceResult.slot()));
        player.getInventory().selectedSlot = maceResult.slot();

        switched = true;
        switchTime = System.currentTimeMillis();
    }

    private void handleSwitchBack() {
        if (!switchBack.getValue()) return;
        if (!switched) return;
        if (originalSlot == -1) return;

        if (System.currentTimeMillis() - switchTime >= switchBackDelay.getValue()) {
            mc.player.getInventory().selectedSlot = originalSlot;
            sendPacket(new UpdateSelectedSlotC2SPacket(originalSlot));
            resetState();
        }
    }

    private boolean isValidWeapon(Item item) {
        if (onlySword.getValue() && onlyAxe.getValue()) {
            return item instanceof SwordItem || item instanceof AxeItem;
        }
        return (!onlySword.getValue() || item instanceof SwordItem) &&
                (!onlyAxe.getValue() || item instanceof AxeItem);
    }

    private void resetState() {
        originalSlot = -1;
        switchTime = 0L;
        switched = false;
    }

    @Override
    protected void sendPacket(Packet<?> packet) {
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(packet);
        }
    }
}
