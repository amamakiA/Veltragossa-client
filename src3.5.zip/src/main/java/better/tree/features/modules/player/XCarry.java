package better.tree.features.modules.player;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public class XCarry extends Module {
    private final Setting<Boolean> onlyInv = new Setting<>("OnlyInventory", false);
    private final Setting<Boolean> autoClose = new Setting<>("AutoClose", true);

    public XCarry() {
        super("XCarry", Category.PLAYER);
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send e) {
        if (e.getPacket() instanceof CloseHandledScreenC2SPacket) {
            if (onlyInv.getValue() && mc.currentScreen == null) {
                e.cancel();
            } else if (!onlyInv.getValue()) {
                e.cancel();
            }
        }
    }

    @Override
    public void onDisable() {
        if (autoClose.getValue() && mc.player != null && mc.player.currentScreenHandler != null) {
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
        }
    }
}