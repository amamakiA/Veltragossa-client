package better.tree.features.modules.client;

import better.tree.core.manager.client.ModuleManager;
import better.tree.features.modules.misc.NameProtect;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.AddServerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import better.tree.veltragossa;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.Timer;
import better.tree.utility.discord.DiscordEventHandlers;
import better.tree.utility.discord.DiscordRPC;
import better.tree.utility.discord.DiscordRichPresence;

import java.io.*;
import java.util.Objects;

import static better.tree.features.modules.client.ClientSettings.isRu;

public final class RPC extends Module {
    private static final DiscordRPC rpc = DiscordRPC.INSTANCE;
    public static Setting<Mode> mode = new Setting<>("Picture", Mode.Veltragossa);
    public static Setting<Boolean> showIP = new Setting<>("ShowIP", true);
    public static Setting<sMode> smode = new Setting<>("StateMode", sMode.Stats);
    public static Setting<String> state = new Setting<>("State", "3.6??????");
    public static Setting<Boolean> nickname = new Setting<>("Nickname", true);
    public static DiscordRichPresence presence = new DiscordRichPresence();
    public static boolean started;
    static String String1 = "none";
    private final Timer timer_delay = new Timer();
    private static Thread thread;
    String slov;
    String[] rpc_perebor_en = {"Parkour", "Reporting cheaters", "Touching grass", "Asks how to bind","Asks mevinggs how to put configuration", "Reporting bugs", "Watching Tuff Niggers in aMamaki"};
    String[] rpc_perebor_ru = {"Паркурит", "Репортит читеров", "Трогает траву", "Спрашивает как забиндить", "Репортит баги", "Смотрит Флюгера"};
    int randomInt;

    public RPC() {
        super("DiscordRPC", Category.CLIENT);
    }



    @Override
    public void onDisable() {
        started = false;
        if (thread != null && !thread.isInterrupted()) {
            thread.interrupt();
        }
        rpc.Discord_Shutdown();
    }

    @Override
    public void onUpdate() {
        startRpc();
    }

    public void startRpc() {
        if (isDisabled()) return;
        if (!started) {
            started = true;
            DiscordEventHandlers handlers = new DiscordEventHandlers();
            rpc.Discord_Initialize("1434530697414181005", handlers, true, "");
            presence.startTimestamp = (System.currentTimeMillis() / 1000L);
            presence.largeImageText = " " + veltragossa.VERSION + " [" + veltragossa.GITHUB_HASH + "]";
            rpc.Discord_UpdatePresence(presence);

            thread = new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    rpc.Discord_RunCallbacks();
                    presence.details = getDetails();

                    switch (smode.getValue()) {
                        case Stats ->
                                presence.state = "Modules: " + Managers.MODULE.getEnabledModules().size() + " / " + Managers.MODULE.modules.size();
                        case Custom -> presence.state = state.getValue();
                        case Version -> presence.state = " " + veltragossa.VERSION +" for mc 1.21";
                    }

                    if (nickname.getValue()) {

                        if (ModuleManager.nameProtect.isEnabled()) {

                            presence.smallImageText = "Protected";
                            presence.smallImageKey = "";
                        } else {

                            presence.smallImageText = "logged as - " + mc.getSession().getUsername();
                            presence.smallImageKey = "https://minotar.net/helm/" + mc.getSession().getUsername() + "/100.png";
                        }
                    } else {
                        presence.smallImageText = "";
                        presence.smallImageKey = "";
                    }

                    presence.button_label_1 = "Download";
                    presence.button_url_1 = "https://github.com/Mevinggs/Veltragossa-client";

                    switch (mode.getValue()) {
                        case Veltragossa -> presence.largeImageKey = "https://i.imgur.com/20Ct68M.gif";
                        case Cute ->
                                presence.largeImageKey = "https://i.imgur.com/gDvkHnK.gif";
                        case Cute2 ->
                                    presence.largeImageKey = "https://i.imgur.com/YWlUFj6.png";
                        case Rat ->
                                  presence.largeImageKey = "https://i.imgur.com/eT063Tx.gif";

                        case CumShot ->
                                     presence.largeImageKey = "https://i.imgur.com/12x2Hvi.png";
                    }
                    rpc.Discord_UpdatePresence(presence);
                    try {
                        Thread.sleep(2000L);
                    } catch (InterruptedException ignored) {
                    }
                }
            }, "TH-RPC-Handler");
            thread.start();
        }
    }

    private String getDetails() {
        String result = "";

        if (mc.currentScreen instanceof MultiplayerScreen || mc.currentScreen instanceof AddServerScreen || mc.currentScreen instanceof TitleScreen) {
            if(timer_delay.passedMs(60 * 1000)){
                randomInt = (int)(Math.random() * (5 - 0 + 1) + 0);
                slov = isRu() ? rpc_perebor_ru[randomInt] : rpc_perebor_en[randomInt];
                timer_delay.reset();
            }
            result = slov;
        } else if (mc.getCurrentServerEntry() != null) {
            result = isRu() ? (showIP.getValue() ? "Играет на " + mc.getCurrentServerEntry().address : "Играет на сервере") : (showIP.getValue() ? "Playing on " + mc.getCurrentServerEntry().address : "Playing on server");
        } else if (mc.isInSingleplayer()) {
            result = isRu() ? "Читерит в одиночке" : "Play SinglePlayer <3";
        }
        return result;
    }

    public enum Mode {Veltragossa,CumShot,Rat,Cute,Cute2 }

    public enum sMode {Custom, Stats, Version}
}