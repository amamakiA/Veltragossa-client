package better.tree.features.modules.client;

import better.tree.features.modules.Module;

public class AntiPacketException extends Module {
    public AntiPacketException() {
        super("NoPacketException", Category.CLIENT);
    }
}