package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import better.tree.core.Managers;
import better.tree.events.impl.PlayerUpdateEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import net.minecraft.util.math.BlockPos;
import better.tree.core.manager.player.PlayerManager;
import better.tree.features.modules.combat.Aura;


public final class TriggerBot extends Module {


    public static Entity target = null;

    public final Setting<Boolean> pauseEating = new Setting<>("Pause If Eating", true);
    public final Setting<Boolean> onlyCriticals = new Setting<>("Only Criticals", true);
    public final Setting<Boolean> spaceOnly = new Setting<>("Space Only", false, value -> onlyCriticals.getValue());



    private int delay = 0;
    private final PlayerManager playerManager = Managers.PLAYER;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @EventHandler
    public void onUpdate(PlayerUpdateEvent e) {
        if (mc.player == null || mc.world == null) return;

        target = null;

        if (mc.player.isUsingItem() && pauseEating.getValue()) return;
        if (delay > 0) { delay--; return; }
        if (!autoCrit()) return;

        Entity ent = mc.targetedEntity;
        if (!(ent instanceof LivingEntity living) || !living.isAlive()) return;
        if (Managers.FRIEND.isFriend(living.getName().getString())) return;


        target = ent;

        boolean isBeforeSprint = mc.player.isSprinting();
        if (onlyCriticals.getValue()) {
            mc.player.setSprinting(false);
        }
        mc.interactionManager.attackEntity(mc.player, ent);
        mc.player.swingHand(Hand.MAIN_HAND);
        delay = 10;
        if (onlyCriticals.getValue() && isBeforeSprint) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    public void onDisable() {
        target = null;
        delay = 0;
        super.onDisable();
    }

    private boolean autoCrit() {
        boolean reasonForSkipCrit = !onlyCriticals.getValue()
                || mc.player.getAbilities().flying
                || mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                || mc.player.isFallFlying()
                || mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || playerManager.isInWeb()
                || mc.world.getBlockState(BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ())).isOf(Blocks.LADDER);
        if (getAttackStrengthScale() < (mc.player.isOnGround() ? 1f : 0.9f))
            return false;
        if (!mc.options.jumpKey.isPressed() && spaceOnly.getValue())
            return true;
        if (mc.player.isInLava())
            return true;
        if (!mc.options.jumpKey.isPressed() && isAboveWater())
            return true;
        if (!reasonForSkipCrit)
            return !mc.player.isOnGround() && mc.player.fallDistance > 0.0f;
        return true;
    }

    private float getAttackStrengthScale() {
        return mc.player.getAttackCooldownProgress(0);
    }

    private boolean isAboveWater() {
        return mc.player.isSubmergedInWater() || mc.world.getBlockState(BlockPos.ofFloored(mc.player.getPos().add(0, -0.4, 0))).getBlock() == Blocks.WATER;
    }
}