package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.Timer;

import java.util.LinkedList;
import java.util.Queue;

public class AutoChatCMD extends Module {

    private final Setting<String> command = new Setting<>("Cmd", "warp");
    private final Setting<Integer> interval = new Setting<>("CooldownTime", 20, 0, 600);
    private final Setting<Boolean> repeat = new Setting<>("Repeat", false);

    private final Setting<Boolean> enableAirstuck = new Setting<>("EnableAirstuck", false);
    private final Setting<Integer> airstuckTime = new Setting<>("AirstuckTime (s)", 5, 1, 60, v -> enableAirstuck.getValue());
    private final Setting<Boolean> freezeRotation = new Setting<>("FreezeRotation", true, v -> enableAirstuck.getValue());

    private final Timer timer = new Timer();
    private final Timer airstuckTimer = new Timer();
    private final Queue<Packet<?>> storedPackets = new LinkedList<>();

    private double freezeX, freezeY, freezeZ;
    private float freezeYaw, freezePitch;

    private static final int MAX_STORED_PACKETS = 500;
    private static final int PACKETS_PER_TICK = 10;

    private boolean releasingPackets = false;

    public AutoChatCMD() {
        super("AutoChatCMD", Category.MISC);
    }

    @Override
    public void onEnable() {
        if (mc.player == null || mc.world == null) {
            disable();
            return;
        }

        mc.player.networkHandler.sendCommand(command.getValue());

        if (enableAirstuck.getValue()) {
            freezeX = mc.player.getX();
            freezeY = mc.player.getY();
            freezeZ = mc.player.getZ();
            freezeYaw = mc.player.getYaw();
            freezePitch = mc.player.getPitch();
            storedPackets.clear();
            releasingPackets = false;
            airstuckTimer.reset();
        } else if (!repeat.getValue()) {
            disable();
        }

        timer.reset();
    }

    @Override
    public void onUpdate() {
        if (enableAirstuck.getValue()) {
            long target = airstuckTime.getValue() * 995L;

            if (!releasingPackets) {

                mc.player.setPosition(freezeX, freezeY, freezeZ);
                if (freezeRotation.getValue()) {
                    mc.player.setYaw(freezeYaw);
                    mc.player.setPitch(freezePitch);
                }

                if (airstuckTimer.passedMs(target)) {
                    releasingPackets = true;
                }
            } else {

                int i = 0;
                while (!storedPackets.isEmpty() && i < PACKETS_PER_TICK) {
                    sendPacket(storedPackets.poll());
                    i++;
                }

                if (storedPackets.isEmpty()) {
                    disable();
                }
            }
            return;
        }

        if (repeat.getValue() && timer.passedMs(interval.getValue() * 995L)) {
            mc.player.networkHandler.sendCommand(command.getValue());
            timer.reset();
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send event) {
        if (!enableAirstuck.getValue() || mc.player == null) return;

        Packet<?> packet = event.getPacket();

        if (!releasingPackets && packet instanceof PlayerMoveC2SPacket) {
            event.cancel();

            if (storedPackets.size() < MAX_STORED_PACKETS) {
                storedPackets.add(packet);
            }
        }
    }
}