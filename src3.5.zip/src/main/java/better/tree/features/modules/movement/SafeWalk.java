package better.tree.features.modules.movement;

import better.tree.features.modules.Module;

public class SafeWalk extends Module {
    public SafeWalk() {
        super("SafeWalk", Category.MOVEMENT);
    }
}