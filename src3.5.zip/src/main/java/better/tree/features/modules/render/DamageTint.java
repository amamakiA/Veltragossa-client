package better.tree.features.modules.render;

import net.minecraft.client.gui.DrawContext;
import better.tree.features.modules.Module;
import better.tree.setting.impl.ColorSetting;
import better.tree.setting.Setting;
import better.tree.utility.math.MathUtility;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;

public class DamageTint extends Module {
    private final Setting<ColorSetting> tintColor = new Setting<>("TintColor", new ColorSetting(new Color(255, 0, 0, 255)));
    private final Setting<Boolean> smoothFade = new Setting<>("SmoothFade", true);

    private float lastFactor = 0f;

    public DamageTint() {
        super("DamageTint", Category.RENDER);
    }

    public void onRender2D(DrawContext context) {
        if (mc.player == null) return;

        float health = mc.player.getHealth();
        float maxHealth = mc.player.getMaxHealth();
        float factor = 1f - MathUtility.clamp(health / maxHealth, 0f, 1f);

        if (smoothFade.getValue()) {
            factor = MathUtility.lerp(lastFactor, factor, 0.1f);
        }
        lastFactor = factor;

        if (factor > 0f) {
            int alpha = (int) (factor * 170f);
            Color tint = Render2DEngine.injectAlpha(tintColor.getValue().getColorObject(), alpha);

            Render2DEngine.draw2DGradientRect(context.getMatrices(), 0, 0,
                    mc.getWindow().getScaledWidth(),
                    mc.getWindow().getScaledHeight(),
                    tint, tint, tint, tint
            );
        }
    }
}