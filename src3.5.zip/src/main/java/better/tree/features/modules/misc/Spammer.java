package better.tree.features.modules.misc;

import better.tree.features.modules.Module;
import better.tree.utility.Timer;

public class Spammer extends Module {

    private static final String SPAM_MESSAGE = "Top Free Client Veltragossa dc.gg/veltragossa";

    private static final long SPAM_DELAY_MS = 11000;

    private final Timer timer_delay = new Timer();

    public Spammer() {
        super("Spammer", Category.MISC);
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null)
            return;
        if (timer_delay.passedMs(SPAM_DELAY_MS)) {
            mc.player.networkHandler.sendChatMessage(SPAM_MESSAGE);
            timer_delay.reset();
        }
    }
}