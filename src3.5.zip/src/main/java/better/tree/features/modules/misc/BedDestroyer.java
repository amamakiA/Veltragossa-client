package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BedBlock;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.EventSync;
import better.tree.events.impl.PlayerUpdateEvent;
import better.tree.utility.player.InteractionUtility;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;

public class BedDestroyer extends Module {
        private final Setting<BypassMode> bypassMode = new Setting<>("Mode", BypassMode.Default);
    private final Setting<Boolean> rotate = new Setting<>("Rotate", false);
    private final Setting<Float> range = new Setting<>("Range", 2.97f, 0.5f, 4.2f);
    private final Setting<ColorSetting> renderColor = new Setting<>("RenderColor", new ColorSetting(new Color(231, 1, 255, 255)));

    private final Setting<Boolean> cowSound = new Setting<>("CowSound", true);
    private final Setting<Float> cowVolume = new Setting<>("CowVolume", 1.0f, 0.0f, 2.0f);

    private BlockPos currentTarget;
    private float rotationYaw = -999, rotationPitch;

    public BedDestroyer() {
        super("Bed Destroyer", Category.MISC);
    }

    @EventHandler
    public void onSync(EventSync e) {
        if(rotationYaw != -999 && rotate.getValue()) {
            mc.player.setYaw(rotationYaw);
            mc.player.setPitch(rotationPitch);
            rotationYaw = -999;
        }
    }

    @EventHandler
    public void onPlayerUpdate(PlayerUpdateEvent e) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        switch (bypassMode.getValue()) {
            case Default:
            case FastSafe:
                if (currentTarget != null) {
                    BlockState state = mc.world.getBlockState(currentTarget);

                    if (state.isAir()) {

                        if (cowSound.getValue()) {
                            mc.player.playSound(SoundEvents.ENTITY_COW_HURT, cowVolume.getValue(), 1.0f);
                        }

                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK,
                                currentTarget, Direction.UP
                        ));
                        currentTarget = null;
                        rotationYaw = -999;
                    } else {
                        if(rotate.getValue()){
                            float[] angle = InteractionUtility.calculateAngle(currentTarget.toCenterPos());
                            rotationYaw = angle[0];
                            rotationPitch = angle[1];
                        }
                        mc.interactionManager.updateBlockBreakingProgress(currentTarget, Direction.UP);
                        mc.player.swingHand(Hand.MAIN_HAND);
                    }
                    return;
                }

                int intRangeDefault = (int) (Math.floor(range.getValue()) + 1);
                Iterable<BlockPos> blocksDefault = BlockPos.iterateOutwards(
                        BlockPos.ofFloored(mc.player.getPos()), intRangeDefault, intRangeDefault, intRangeDefault
                );

                for (BlockPos pos : blocksDefault) {
                    BlockState state = mc.world.getBlockState(pos);
                    Block block = state.getBlock();

                    if (isBed(block)) {
                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.START_DESTROY_BLOCK,
                                pos, Direction.UP
                        ));
                        currentTarget = pos;
                        if(rotate.getValue()){
                            float[] angle = InteractionUtility.calculateAngle(pos.toCenterPos());
                            rotationYaw = angle[0];
                            rotationPitch = angle[1];
                        }
                        break;
                    }
                }
                break;
            case Fast:
                if (currentTarget != null) {
                    BlockState state = mc.world.getBlockState(currentTarget);
                    if (state.isAir()) {
                        if (cowSound.getValue()) {
                            mc.player.playSound(SoundEvents.ENTITY_COW_HURT, cowVolume.getValue(), 1.0f);
                        }
                        currentTarget = null;
                        rotationYaw = -999;
                    }
                    return;
                }

                int intRangeFast = (int) (Math.floor(range.getValue()) + 1);
                Iterable<BlockPos> blocksFast = BlockPos.iterateOutwards(
                        BlockPos.ofFloored(mc.player.getPos()), intRangeFast, intRangeFast, intRangeFast
                );

                for (BlockPos pos : blocksFast) {
                    Block block = mc.world.getBlockState(pos).getBlock();
                    if (isBed(block)) {
                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.START_DESTROY_BLOCK,
                                pos, Direction.UP
                        ));
                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK,
                                pos, Direction.UP
                        ));
                        mc.player.swingHand(Hand.MAIN_HAND);
                        currentTarget = pos;
                        if(rotate.getValue()){
                            float[] angle = InteractionUtility.calculateAngle(pos.toCenterPos());
                            rotationYaw = angle[0];
                            rotationPitch = angle[1];
                        }
                        break;
                    }
                }
                break;
        }
    }

    private boolean isBed(Block block) {
        return block instanceof BedBlock;
    }

    @Override
    public void onRender3D(MatrixStack stack) {
        if (currentTarget == null) return;

        Color color = renderColor.getValue().getColorObject();
        int colorInt = color.getRGB();

        Render3DEngine.drawBoxOutline(new Box(currentTarget), color, 2);
        Render3DEngine.drawFilledBox(stack, new Box(currentTarget), Render2DEngine.injectAlpha(color, 100));

        Vec3d start = mc.player.getPos().add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);
        Vec3d end = Vec3d.ofCenter(currentTarget);
        Render3DEngine.drawLine(start, end, 2.0f, colorInt);
    }

    private enum BypassMode {
        Default, Fast, FastSafe
    }
}