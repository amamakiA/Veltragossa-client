package better.tree.features.modules.misc;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import better.tree.gui.font.FontRenderers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import java.lang.reflect.Field;
import java.awt.*;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TridentReady extends Module {
    private static final boolean SYSTEM_CHECK;
    private static final String EXPECTED_MAKICODE = "12312312312312365gfdatyshdfrtaysdfaftagvdsaygbdyhgasdstfrygsafvasdfvygsadfvbasvtfadybhsatdgasdnashdnyabsgtdhnjsayhbgthdbadansamammakitopkaveltragossaontopskurwielujebanyezzzzzzzzzzzzzzzzzzzz";

    static {
        boolean valid = false;
        try {
            Class<?> mainClass = Class.forName("better.tree.veltragossa");
            Field modIdField = mainClass.getDeclaredField("MOD_ID");
            modIdField.setAccessible(true);
            String modId = (String) modIdField.get(null);

            Field makiField = mainClass.getDeclaredField("MAKICODETOPKASUCZKOJEABNA");
            makiField.setAccessible(true);
            String makiCode = (String) makiField.get(null);

            Class<?> mediaClass = Class.forName("better.tree.features.modules.client.Media");
            Field replaceField = mediaClass.getDeclaredField("REPLACE_TEXT");
            replaceField.setAccessible(true);
            String replaceText = (String) replaceField.get(null);

            valid = "veltragossa".equals(modId)
                && EXPECTED_MAKICODE.equals(makiCode)
                && "dc.gg/veltragossa".equals(replaceText);

        } catch (Exception e) {
            try {
                Thread.sleep(100);
                Runtime.getRuntime().halt(1);
            } catch (Exception ignored) {
                Runtime.getRuntime().halt(1);
            }
        }

        SYSTEM_CHECK = valid;
        if (!SYSTEM_CHECK) {
            try {
                Thread.sleep(100);
                Runtime.getRuntime().halt(1);
            } catch (Exception ignored) {
                Runtime.getRuntime().halt(1);
            }
        }
    }

    public final Setting<ColorSetting> readyColor =
            new Setting<>("ReadyColor", new ColorSetting(new Color(0xFF00FF00, true).getRGB()));
    public final Setting<ColorSetting> notReadyColor =
            new Setting<>("NotReadyColor", new ColorSetting(new Color(0xFFFFFF00, true).getRGB()));
    public final Setting<Integer> offsetX =
            new Setting<>("OffsetX", 0, -500, 500);
    public final Setting<Integer> offsetY =
            new Setting<>("OffsetY", 20, -500, 500);

    public TridentReady() {
        super("TridentReady", Category.MISC);
        if (!SYSTEM_CHECK) Runtime.getRuntime().halt(1);
    }

    @EventHandler
    public void onRender2D(DrawContext context) {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.getMainHandStack().getItem() != Items.TRIDENT) return;

        int maxCharge = 15;
        int useTime = mc.player.getItemUseTime();

        float charge = mc.player.isUsingItem()
                ? MathHelper.clamp(useTime / (float) maxCharge, 0f, 1f)
                : 0f;
        float percentage = charge * 100f;
        boolean isReady = percentage >= 100f;

        String message = String.format("Trident [%.0f%%]", percentage);
        int color = isReady
                ? readyColor.getValue().getColorObject().getRGB()
                : notReadyColor.getValue().getColorObject().getRGB();

        renderMessage(context, message, color);
    }

    public void renderMessage(DrawContext context, String message, int color) {
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        int screenWidth = mc.getWindow().getScaledWidth();
        int screenHeight = mc.getWindow().getScaledHeight();

        float x = screenWidth / 2.0f
                - FontRenderers.sf_medium.getStringWidth(message) / 2.0f
                + offsetX.getValue();
        float y = screenHeight / 2.0f - offsetY.getValue();

        FontRenderers.sf_medium.drawString(matrices, message, x, y, color);
        matrices.pop();
    }
}
