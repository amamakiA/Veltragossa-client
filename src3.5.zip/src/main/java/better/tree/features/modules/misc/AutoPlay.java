package better.tree.features.modules.misc;

import better.tree.core.Managers;
import better.tree.core.manager.client.ModuleManager;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.Vec3d;
 

public class AutoPlay extends Module {

    private final Setting<Boolean> enableAura = new Setting<>("EnableAura", true);
    private final Setting<Boolean> enableFakeLag = new Setting<>("EnableFakeLag", true);
    private final Setting<Integer> openRightClickMs = new Setting<>("RightClickMs", 400, 50, 600);
    private final Setting<Integer> minRunMs = new Setting<>("MinRunMs", 5000, 200, 10000);

    private enum State { IDLE, SELECTING, WAITING_TELEPORT, MOVING }

    private State state = State.IDLE;
    private long clickCooldownUntil = 0L;
    private long rightClickUntil = 0L;
    private boolean inArenaPhase = false;
    private long arenaStartAt = 0L;
    private long selectionUnlockAt = 0L;
    private boolean pendingTeleportCheck = false;
    private Vec3d posBeforePacket = null;
 

    public AutoPlay() {
        super("AutoPlay", Category.MISC);
    }

    @Override
    public void onEnable() {
        state = State.SELECTING;
        clickCooldownUntil = 0L;
        rightClickUntil = 0L;
        inArenaPhase = false;
        arenaStartAt = 0L;
        selectionUnlockAt = 0L;
        pendingTeleportCheck = false;
        posBeforePacket = null;
    }

    @Override
    public void onDisable() {
        stopMovementKeys();
        state = State.IDLE;
        inArenaPhase = false;
        releaseUseKey();
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive e) {
        if (!isEnabled()) return;
        Packet<?> p = e.getPacket();
        if (p instanceof PlayerPositionLookS2CPacket) {
            try {
                if (mc.player != null) {
                    posBeforePacket = mc.player.getPos();
                    pendingTeleportCheck = true;
                }
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public void onUpdate() {
        if (!isEnabled() || mc.player == null) return;

        if (pendingTeleportCheck) {
            try {
                if (posBeforePacket != null) {
                    double distSq = mc.player.squaredDistanceTo(posBeforePacket);
                    if (distSq >= (400.0 * 400.0)) {
                        onTeleport();
                    }
                }
            } catch (Throwable ignored) {}
            pendingTeleportCheck = false;
            posBeforePacket = null;
        }

        if (state == State.SELECTING) {
            if (selectionUnlockAt > 0 && System.currentTimeMillis() < selectionUnlockAt) return;

            selectHotbarSlot0();

            if (!(mc.currentScreen instanceof HandledScreen<?>)) {
                long now = System.currentTimeMillis();
                if (rightClickUntil == 0L || now > rightClickUntil) {
                    pressUseKey(openRightClickMs.getValue());
                }
            } else {
                long now = System.currentTimeMillis();
                if (now >= clickCooldownUntil) {
                    if (Managers.SERVER.getPing() >= 100) return;
                    try {
                        mc.interactionManager.clickSlot(
                                mc.player.currentScreenHandler.syncId,
                                0,
                                1,
                                SlotActionType.PICKUP,
                                mc.player
                        );
                        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
                    } catch (Throwable ignored) {}
                    clickCooldownUntil = now + 600L;
                    state = State.WAITING_TELEPORT;
                }
            }
        }

        if (state == State.MOVING) {
            holdMovementKeys();
        }
    }

    private void onTeleport() {
        if (!isEnabled() || mc.player == null) return;
        long now = System.currentTimeMillis();
        if (!inArenaPhase) {

            if (state == State.WAITING_TELEPORT) {
                if (enableAura.getValue() && !ModuleManager.aura.isEnabled()) ModuleManager.aura.enable();
                if (enableFakeLag.getValue()) {
                    try { if (!Managers.MODULE.FakeLag.isEnabled()) Managers.MODULE.FakeLag.enable(); } catch (Throwable ignored) {}
                }
                state = State.MOVING;
                inArenaPhase = true;
                arenaStartAt = now;
            }

        } else {

            if (state == State.MOVING && (now - arenaStartAt) >= minRunMs.getValue()) {
                stopMovementKeys();
                if (enableAura.getValue() && ModuleManager.aura.isEnabled()) ModuleManager.aura.disable();
                if (enableFakeLag.getValue()) {
                    try { if (Managers.MODULE.FakeLag.isEnabled()) Managers.MODULE.FakeLag.disable(); } catch (Throwable ignored) {}
                }
                inArenaPhase = false;
                state = State.SELECTING;
                arenaStartAt = 0L;

                clickCooldownUntil = 0L;
                rightClickUntil = 0L;

                selectionUnlockAt = System.currentTimeMillis() + 6000L;
            }
        }
    }

    private void selectHotbarSlot0() {
        mc.player.getInventory().selectedSlot = 0;
        Managers.PLAYER.serverSideSlot = 0;
    }

    private void holdMovementKeys() {
        try {
            mc.options.forwardKey.setPressed(true);
            mc.options.jumpKey.setPressed(true);
        } catch (Throwable ignored) {}
    }

    private void stopMovementKeys() {
        try {
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
        } catch (Throwable ignored) {}
    }

    private void pressUseKey(int durationMs) {
        try {
            mc.options.useKey.setPressed(true);
            rightClickUntil = System.currentTimeMillis() + durationMs;
            Managers.ASYNC.run(this::releaseUseKey, durationMs);
        } catch (Throwable ignored) {}
    }

    private void releaseUseKey() {
        try {
            mc.options.useKey.setPressed(false);
        } catch (Throwable ignored) {}
    }

    public boolean isControllingMovement() {
        return state == State.MOVING;
    }
}
