package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.util.Random;

public class PingSpoof extends Module {


    public final Setting<Float> minPing = new Setting<>("Min Ping", 100f, 0f, 1500f);
    public final Setting<Float> maxPing = new Setting<>("Max Ping", 600f, 0f, 1500f);


    private int currentDelay;
    private final Random random = new Random();

    public PingSpoof() {
        super("PingSpoof", Category.MISC);
    }


    private int getRandomDelay() {
        float min = minPing.getValue();
        float max = maxPing.getValue();

        if (min > max) {
            min = maxPing.getValue();
            max = minPing.getValue();
        }


        return (int) (min + (max - min) * random.nextFloat());
    }

    @Override
    public void onEnable() {

        currentDelay = getRandomDelay();
        super.onEnable();
    }


    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {

        if (event.getPacket() instanceof KeepAliveS2CPacket packet) {


            event.cancel();


            final long keepAliveId = packet.getId();
            final int delay = currentDelay;

            new Thread(() -> {
                try {

                    Thread.sleep(delay);


                    if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
                        mc.getNetworkHandler().getConnection().send(new KeepAliveC2SPacket(keepAliveId));
                    }


                    currentDelay = getRandomDelay();

                } catch (InterruptedException ignored) {

                }
            }).start();
        }
    }



    @Override
    public void onDisable() {

        super.onDisable();
    }
}