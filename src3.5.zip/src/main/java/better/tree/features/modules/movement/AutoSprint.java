package better.tree.features.modules.movement;

import better.tree.core.manager.client.ModuleManager;
import better.tree.features.modules.Module;
import better.tree.features.modules.combat.Aura;
import better.tree.setting.Setting;

public class AutoSprint extends Module {
    public AutoSprint() {
        super("AutoSprint", Category.MOVEMENT);
    }

    public static final Setting<Boolean> sprint = new Setting<>("KeepSprint", true);
    public static final Setting<Float> motion = new Setting<>("Motion", 1f, 0f, 1f, v -> sprint.getValue());
    private final Setting<Boolean> stopWhileUsing = new Setting<>("StopWhileUsing", false);
    private final Setting<Boolean> pauseWhileAura = new Setting<>("PauseWhileAura", false);
    private final Setting<Boolean> allowSwimSprint = new Setting<>("SwimSprint", true);

    @Override
    public void onUpdate() {
        boolean canSprint = mc.player.getHungerManager().getFoodLevel() > 6
                && !mc.player.horizontalCollision
                && mc.player.input.movementForward > 0
                && (!mc.player.isSneaking() || (ModuleManager.noSlow.isEnabled() && ModuleManager.noSlow.sneak.getValue()))
                && (!mc.player.isUsingItem() || !stopWhileUsing.getValue())
                && (!ModuleManager.aura.isEnabled() || Aura.target == null || !pauseWhileAura.getValue());

        if (allowSwimSprint.getValue()) {
            if (mc.player.isTouchingWater() || mc.player.isInLava()) {
                if (algorytm()) {
                    canSprint = true;
                } else {
                    canSprint = false;
                }
            }
        }

        mc.player.setSprinting(canSprint);
    }

    private boolean algorytm() {
        return mc.player.input.movementForward != 0
                || mc.player.input.movementSideways != 0;
    }
}