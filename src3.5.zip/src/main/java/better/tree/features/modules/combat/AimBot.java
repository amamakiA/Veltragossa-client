package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;
import better.tree.core.Managers;
import better.tree.core.manager.client.ModuleManager;
import better.tree.events.impl.EventSync;
import better.tree.events.impl.PlayerUpdateEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.Timer;
import better.tree.utility.math.PredictUtility;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import static net.minecraft.util.hit.HitResult.Type.ENTITY;
import static net.minecraft.util.math.MathHelper.wrapDegrees;

public final class AimBot extends Module {
    private final Setting<Mode> mode = new Setting<>("Mode", Mode.BowAim);
    private final Setting<Rotation> rotation = new Setting<>("Rotation", Rotation.Silent, v -> mode.getValue() != Mode.AimAssist);
    private final Setting<Float> aimRange = new Setting<>("Range", 4.77f, 0.1f, 30f, v -> mode.getValue() != Mode.AimAssist);
    private final Setting<Integer> aimStrength = new Setting<>("AimStrength", 30, 1, 100, v -> mode.getValue() == Mode.AimAssist);
    private final Setting<Integer> aimSmooth = new Setting<>("AimSmooth", 45, 1, 180, v -> mode.getValue() == Mode.AimAssist);
    private final Setting<Integer> aimtime = new Setting<>("AimTime", 2, 1, 10, v -> mode.getValue() == Mode.AimAssist);
    private final Setting<Boolean> ignoreWalls = new Setting<>("IgnoreWalls", true, v -> mode.is(Mode.AimAssist));
    private final Setting<Boolean> ignoreTeam = new Setting<>("IgnoreTeam", true, v -> mode.is(Mode.AimAssist));
    private final Setting<Integer> reactionTime = new Setting<>("ReactionTime", 80, 1, 500, v -> mode.getValue() == Mode.AimAssist && !ignoreWalls.getValue());
    private final Setting<Boolean> ignoreInvisible = new Setting<>("IgnoreInvis", false, v -> mode.is(Mode.AimAssist));
    private final Setting<Integer> predictTicks = new Setting<>("PredictTicks", 0, 0, 20, v -> false);

    private final Setting<Boolean> noWall = new Setting<>("GhostBullet", false, v -> false);



    private final Setting<Boolean> render3D = new Setting<>("Render3d", false, v -> false);
    private final Setting<Float> aimOffset = new Setting<>("AimOffset", 0.0f, -10.0f, 10.0f, v -> mode.getValue() == Mode.BowAim);

    private float rotationYaw, rotationPitch, assistAcceleration;
    private int aimTicks = 0;
    private Timer visibleTime = new Timer();

    public AimBot() {
        super("AimBot", Category.COMBAT);
    }

    @EventHandler
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mode.getValue() == Mode.BowAim) {

            if (!(mc.player.getActiveItem().getItem() instanceof BowItem
                    || mc.player.getActiveItem().getItem() instanceof CrossbowItem
                    || mc.player.getActiveItem().getItem() instanceof TridentItem)) {
                return;
            }

            PlayerEntity nearestTarget;
            if(noWall.getValue()){
                nearestTarget = findTargetThroughWalls(128);
            } else {
                nearestTarget = Managers.COMBAT.getTargetByFOV(128);
            }

            if (nearestTarget == null) return;


            float currentDuration = (float) (mc.player.getActiveItem().getMaxUseTime(mc.player) - mc.player.getItemUseTime()) / 20.0f;

            currentDuration = (currentDuration * currentDuration + currentDuration * 2.0f) / 3.0f;
            if (currentDuration >= 1.0f) currentDuration = 1.0f;

            float velocity = currentDuration * 3.0f;

            float pitch = (float) (-Math.toDegrees(calculateArc(nearestTarget, velocity))) + aimOffset.getValue();

            if (Float.isNaN(pitch)) return;

            PlayerEntity predictedEntity = PredictUtility.predictPlayer(nearestTarget, predictTicks.getValue());
            double iX = predictedEntity.getX() - predictedEntity.prevX;
            double iZ = predictedEntity.getZ() - predictedEntity.prevZ;
            double distance = mc.player.distanceTo(predictedEntity);
            distance -= distance % 2.0;
            iX = distance / 2.0 * iX * (mc.player.isSprinting() ? 1.3 : 1.1);
            iZ = distance / 2.0 * iZ * (mc.player.isSprinting() ? 1.3 : 1.1);
            rotationYaw = (float) Math.toDegrees(Math.atan2(predictedEntity.getZ() + iZ - mc.player.getZ(), predictedEntity.getX() + iX - mc.player.getX())) - 90.0f;
            rotationPitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        } else {
            if (mc.crosshairTarget.getType() == ENTITY)
                aimTicks++;
            else
                aimTicks = 0;

            if (aimTicks >= aimtime.getValue()) {
                assistAcceleration = 0;
                return;
            }

            PlayerEntity nearestTarget = Managers.COMBAT.getNearestTarget(5);
            assistAcceleration += aimStrength.getValue() / 10000f;

            if (nearestTarget != null) {
                if (!mc.player.canSee(nearestTarget)) {
                    if (!ignoreWalls.getValue())
                        visibleTime.reset();
                }

                if (!visibleTime.passedMs(reactionTime.getValue())) {
                    rotationYaw = Float.NaN;
                    return;
                }

                if (Float.isNaN(rotationYaw))
                    rotationYaw = mc.player.getYaw();

                float delta_yaw = wrapDegrees((float) wrapDegrees(Math.toDegrees(Math.atan2(nearestTarget.getEyePos().z - mc.player.getZ(), (nearestTarget.getEyePos().x - mc.player.getX()))) - 90) - rotationYaw);
                if (delta_yaw > 180)
                    delta_yaw = delta_yaw - 180;
                float deltaYaw = MathHelper.clamp(MathHelper.abs(delta_yaw), -aimSmooth.getValue(), aimSmooth.getValue());
                float newYaw = rotationYaw + (delta_yaw > 0 ? deltaYaw : -deltaYaw);
                double gcdFix = (Math.pow(mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2, 3.0)) * 1.2;
                rotationYaw = (float) (newYaw - (newYaw - rotationYaw) % gcdFix);
            } else rotationYaw = Float.NaN;
        }

        if (!Float.isNaN(rotationYaw))
            ModuleManager.rotations.fixRotation = rotationYaw;
    }

    @EventHandler
    public void onSync(EventSync event) {
        if (mode.is(Mode.AimAssist))
            return;

        if (mode.getValue() == Mode.BowAim && mc.player.getActiveItem().getItem() instanceof BowItem) {
            if (rotation.getValue() == Rotation.Silent) {
                mc.player.setYaw(rotationYaw);
                mc.player.setPitch(rotationPitch);
            }
        }
    }

    @Override
    public void onEnable() {
        rotationYaw = mc.player.getYaw();
        rotationPitch = mc.player.getPitch();
    }

    @Override
    public void onRender3D(MatrixStack stack) {
        if (mode.getValue() == Mode.AimAssist) {
            if (Float.isNaN(rotationYaw)) return;
            mc.player.setYaw((float) Render2DEngine.interpolate(mc.player.getYaw(), rotationYaw, assistAcceleration));
            return;
        }

        if (render3D.getValue() && mode.getValue() == Mode.BowAim && mc.player.getActiveItem().getItem() instanceof BowItem) {
            PlayerEntity nearestTarget = noWall.getValue() ? findTargetThroughWalls(128) : Managers.COMBAT.getTargetByFOV(128);
            if (nearestTarget == null) return;

            float currentDuration = (float) (mc.player.getActiveItem().getMaxUseTime(mc.player) - mc.player.getItemUseTime()) / 20.0f;
            currentDuration = (currentDuration * currentDuration + currentDuration * 2.0f) / 3.0f;
            if (currentDuration >= 1.0f) currentDuration = 1.0f;
            float velocity = currentDuration * 3.0f;

            float pitch = (float) (-Math.toDegrees(calculateArc(nearestTarget, velocity))) + aimOffset.getValue();
            if (Float.isNaN(pitch)) return;

            PlayerEntity predictedEntity = PredictUtility.predictPlayer(nearestTarget, predictTicks.getValue());
            double iX = predictedEntity.getX() - predictedEntity.prevX;
            double iZ = predictedEntity.getZ() - predictedEntity.prevZ;
            double distance = mc.player.distanceTo(predictedEntity);
            distance -= distance % 2.0;
            iX = distance / 2.0 * iX * (mc.player.isSprinting() ? 1.3 : 1.1);
            iZ = distance / 2.0 * iZ * (mc.player.isSprinting() ? 1.3 : 1.1);
            float yaw = (float) Math.toDegrees(Math.atan2(predictedEntity.getZ() + iZ - mc.player.getZ(), predictedEntity.getX() + iX - mc.player.getX())) - 90.0f;

            Vec3d playerPos = new Vec3d(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()), mc.player.getZ());

            float f = pitch * 0.017453292F;
            float f1 = yaw * 0.017453292F;

            double d0 = -MathHelper.sin(f1) * MathHelper.cos(f);
            double d1 = -MathHelper.sin(f);
            double d2 = MathHelper.cos(f1) * MathHelper.cos(f);

            Vec3d motion = new Vec3d(d0, d1, d2).normalize().multiply(velocity);
            List<Vec3d> path = new ArrayList<>();
            path.add(playerPos);

            Vec3d currentPos = playerPos;

            for (int i = 0; i < 100; i++) {
                Vec3d nextPos = currentPos.add(motion);
                HitResult result = mc.world.raycast(new RaycastContext(currentPos, nextPos, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
                if (result.getType() != HitResult.Type.MISS) {
                    path.add(result.getPos());
                    break;
                }
                currentPos = nextPos;
                motion = motion.multiply(0.99);
                motion = motion.add(0, -0.05, 0);
                path.add(currentPos);
            }
            if(path.size() > 1) {
                for (int i = 1; i < path.size(); i++) {
                    Render3DEngine.drawLine(path.get(i - 1), path.get(i), new Color(0xFFFFFFFF, true));
                }
            }
        }

        if (rotation.getValue() == Rotation.Client && mode.getValue() == Mode.BowAim && mc.player.getActiveItem().getItem() instanceof BowItem) {
            mc.player.setYaw((float) Render2DEngine.interpolate(mc.player.prevYaw, rotationYaw, Render3DEngine.getTickDelta()));
            mc.player.setPitch((float) Render2DEngine.interpolate(mc.player.prevPitch, rotationPitch, Render3DEngine.getTickDelta()));
        }
    }

    private float calculateArc(@NotNull PlayerEntity target, double velocity) {
        double yArc = target.getY() + (double) (target.getEyeHeight(target.getPose())) - (mc.player.getY() + (double) mc.player.getEyeHeight(mc.player.getPose()));
        double dX = target.getX() - mc.player.getX();
        double dZ = target.getZ() - mc.player.getZ();
        double dirRoot = Math.sqrt(dX * dX + dZ * dZ);
        return calculateArc(velocity, dirRoot, yArc);
    }

    private float calculateArc(double d, double dr, double y) {

        y = 2.0 * y * (d * d);
        y = 0.05000000074505806 * ((0.05000000074505806 * (dr * dr)) + y);
        y = Math.sqrt(d * d * d * d - y);
        d = d * d - y;
        y = Math.atan2(d * d + y, 0.05000000074505806 * dr);
        d = Math.atan2(d, 0.05000000074505806 * dr);
        return (float) Math.min(y, d);
    }

    private PlayerEntity findTargetThroughWalls(float fov) {
        PlayerEntity best_entity = null;
        float best_fov = fov;

        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player) continue;
            if (pl.isDead()) continue;
            if (!pl.isAlive()) continue;
            if (Managers.FRIEND.isFriend(pl)) continue;
            if (mc.player.squaredDistanceTo(pl) > aimRange.getPow2Value()) continue;

            float temp_fov = Math.abs(((float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(pl.getZ() - mc.player.getZ(), pl.getX() - mc.player.getX())) - 90.0)) - MathHelper.wrapDegrees(mc.player.getYaw()));
            if (temp_fov < best_fov) {
                best_entity = pl;
                best_fov = temp_fov;
            }
        }
        return best_entity;
    }

    private enum Rotation {
        Client, Silent
    }

    private enum Mode {
         AimAssist, BowAim
    }
}
