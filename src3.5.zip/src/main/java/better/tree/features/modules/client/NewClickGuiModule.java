package better.tree.features.modules.client;

import better.tree.features.modules.Module;
import better.tree.gui.clickui.NewClickGUI;

public class NewClickGuiModule extends Module {
    private static NewClickGUI INSTANCE;

    public NewClickGuiModule() {
        super("NewClickGui", Category.CLIENT);
        INSTANCE = new NewClickGUI();
    }

    @Override
    public void onEnable() {
        if (mc != null) {
            mc.setScreen(INSTANCE);
        }
        toggle();
    }
}
