package better.tree.features.modules.combat;

import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public final class StaticHitboxes extends Module {
    public static StaticHitboxes INSTANCE;

    public final Setting<Boolean> onlyPlayers = new Setting<>("OnlyPlayers", true);

    public StaticHitboxes() {
        super("StaticHitboxes", Category.COMBAT);
        INSTANCE = this;
    }
}