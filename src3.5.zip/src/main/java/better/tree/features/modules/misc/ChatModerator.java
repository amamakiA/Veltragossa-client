package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.text.Text;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public class ChatModerator extends Module {
    private final Setting<String> blacklistedWords = new Setting<>("Blacklisted Words", "sperma,sperm");
    private final Setting<Boolean> cancelMessage = new Setting<>("Cancel Message", true);
    private final Setting<Boolean> censorMessage = new Setting<>("Censor Message", false);
    private final Setting<String> censorReplacement = new Setting<>("Replacement", "***", v -> censorMessage.getValue());

    public ChatModerator() {
        super("ChatModerator", Category.MISC);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        if (event.getPacket() instanceof ChatMessageS2CPacket) {
            ChatMessageS2CPacket chatPacket = (ChatMessageS2CPacket) event.getPacket();
            Text messageContent = chatPacket.unsignedContent();
            if (messageContent == null) {
                messageContent = Text.of(chatPacket.body().content());
            }

            String msg = messageContent.getString();
            String[] words = blacklistedWords.getValue().split(",");

            for (String word : words) {
                word = word.trim();
                if (word.isEmpty()) continue;

                if (msg.toLowerCase().contains(word.toLowerCase())) {
                    if (cancelMessage.getValue()) {
                        event.cancel();
                        return;
                    }

                    if (censorMessage.getValue()) {
                        String censored = msg.replaceAll("(?i)" + word, censorReplacement.getValue());
                        event.cancel();
                        sendMessage("[Censored] " + censored);
                        return;
                    }
                }
            }
        }
    }
}