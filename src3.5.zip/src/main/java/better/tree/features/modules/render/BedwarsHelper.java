package better.tree.features.modules.render;

import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.block.enums.BedPart;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.render.Render3DEngine;

import java.awt.Color;

public class BedwarsHelper extends Module {

    private final Setting<Boolean> bedEsp = new Setting<>("BedESP", true);

    public BedwarsHelper() {
        super("BedwarsHelper", Category.RENDER);
    }

    @Override
    public void onRender3D(MatrixStack stack) {
        if (bedEsp.getValue()) {
            for (BlockEntity blockEntity : StorageEsp.getBlockEntities()) {
                if (blockEntity instanceof BedBlockEntity) {
                    BedBlockEntity bed = (BedBlockEntity) blockEntity;
                    BlockState blockState = bed.getCachedState();
                    if (blockState.getBlock() instanceof BedBlock) {
                        if (blockState.get(BedBlock.PART) == BedPart.FOOT) {
                            BlockPos bedPos = bed.getPos();
                            Direction facing = blockState.get(BedBlock.FACING);
                            BlockPos headPos = bedPos.offset(facing);

                            if(bedEsp.getValue()){
                                Box bedBox = new Box(bedPos).union(new Box(headPos));
                                DyeColor color = ((BedBlock) blockState.getBlock()).getColor();
                                Color renderColor = new Color(color.getFireworkColor());
                                Render3DEngine.drawBoxOutline(bedBox, renderColor, 2);

                            }
                        }
                    }
                }
            }
        }
    }
}