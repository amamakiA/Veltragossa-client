/*package veltragossa.hack.features.modules.render;

import modules.features.veltragossa.hack.Module;

public class Skeleton extends Module { TODO
    public Skeleton() {
        super("Skeleton", Category.RENDER);
    }
}
*/