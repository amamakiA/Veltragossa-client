package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.jetbrains.annotations.NotNull;
import better.tree.core.Managers;
import better.tree.core.manager.client.ModuleManager;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.Module;
import better.tree.features.modules.combat.FakeLag;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public class KeyBinds extends HudElement {
    public final Setting<ColorSetting> oncolor = new Setting<>("OnColor", new ColorSetting(new Color (0x952EBD)));
    public final Setting<ColorSetting> offcolor = new Setting<>("OffColor", new ColorSetting(new Color (0xFF444444)));


    public final Setting<Boolean> onlyEnabled = new Setting<>("OnlyEnabled", false);

    private final Map<Module, Float> animProgress = new ConcurrentHashMap<>();

    public KeyBinds() {
        super("KeyBinds", 50, 30);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        int y_offset = 0;
        float max_width = 0.0f;
        float headerWidth = 60.0f;
        float headerHeight = 16.0f;

        MatrixStack matrices = context.getMatrices();


        boolean isOnRightSide = getPosX() > mc.getWindow().getScaledWidth() / 2;

        Render2DEngine.drawHudBase(matrices, getPosX(), getPosY() - 7.0f, headerWidth, headerHeight, HudEditor.hudRound.getValue());



        float iconSize = 12.0f;
        float iconPadding = 4.0f;
        float iconY = getPosY() - 7.0f + (headerHeight - iconSize) / 2.0f;
        float textY = getPosY() - 7.0f + (headerHeight - FontRenderers.sf_bold.getFontHeight(" ")) / 2.0f + 2f;
        float textX;
        float iconX;
        if (isOnRightSide) {
            iconX = getPosX() + headerWidth - iconSize - iconPadding;
            textX = getPosX() + iconPadding;
        } else {
            iconX = getPosX() + iconPadding;
            textX = getPosX() + iconSize + iconPadding * 2;
        }

        net.minecraft.client.util.math.MatrixStack ms = matrices;
        better.tree.utility.render.Render2DEngine.setupRender();
        com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, better.tree.utility.render.TextureStorage.keyboard);
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
        Render2DEngine.renderGradientTexture(ms, iconX, iconY, iconSize, iconSize, 0, 0, 512, 512, 512, 512,
                HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
        Render2DEngine.endRender();

        FontRenderers.sf_bold.drawString(
                matrices,
                "KeyBinds",
                textX,
                textY,
                HudEditor.textColor.getValue().getColor()
        );

        boolean hasAnyBinds = false;
        for (Module feature : Managers.MODULE.modules) {
            if (Objects.equals(feature.getBind().getBind(), "None") || feature == ModuleManager.clickGui || feature == ModuleManager.ThunderHackGui)
                continue;

            hasAnyBinds = true;

            boolean shouldRender = feature.isOn() || !onlyEnabled.getValue();

            float progress = animProgress.getOrDefault(feature, 0f);
            float target = shouldRender ? 1f : 0f;
            progress += (target - progress) * 0.1f;
            animProgress.put(feature, progress);

            if (progress < 0.05f) continue;

            if (y_offset == 0) {
                y_offset += 12;
            }

            float nameWidth = FontRenderers.sf_bold_mini.getStringWidth(feature.getName());
            float bindWidth = FontRenderers.sf_bold_mini.getStringWidth(KeyBinds.getShortKeyName(feature));

            float elementWidth = 12.0f + nameWidth + 6.0f + bindWidth + 12.0f;
            float elementHeight = 14.0f;

            int baseColor = feature.isOn() ? oncolor.getValue().getColor() : offcolor.getValue().getColor();
            Color c = new Color(baseColor, true);
            int alpha = (int) (c.getAlpha() * progress);
            Color animatedColor = new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);


            float baseX = isOnRightSide ?
                    (getPosX() + headerWidth - elementWidth) :
                    getPosX();
            float slideX = baseX + (isOnRightSide ? (1f - progress) * 15f : -(1f - progress) * 15f);

            Render2DEngine.drawHudBase(matrices, slideX, getPosY() + (float) y_offset, elementWidth, elementHeight, HudEditor.hudRound.getValue());


            float nameX = isOnRightSide ?
                    slideX + elementWidth - nameWidth - 6.0f :
                    slideX + 6.0f;
            float bindX = isOnRightSide ?
                    slideX + 10.0f :
                    slideX + elementWidth - 10.0f - bindWidth;
            float separatorX = isOnRightSide ?
                    slideX + bindWidth + 12.0f :
                    slideX + nameWidth + 12.0f;

            FontRenderers.sf_bold_mini.drawString(matrices, feature.getName(), nameX, getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f, animatedColor.getRGB());
            FontRenderers.sf_bold_mini.drawString(matrices, KeyBinds.getShortKeyName(feature), bindX, getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f, animatedColor.getRGB());
            Render2DEngine.drawRect(matrices, separatorX, getPosY() + (float) y_offset + 2.0f, 0.5f, elementHeight - 4.0f, new Color(0x44FFFFFF, true));

            y_offset = (int) ((float) y_offset + (elementHeight + 4.0f));
            max_width = Math.max(max_width, elementWidth);

            if (feature.getClass().getSimpleName().equals("Aura")) {
                float auraWidth = 28.0f;
                float auraHeight = 14.0f;
                float auraX = isOnRightSide ?
                        slideX - auraWidth - 6.0f :
                        slideX + elementWidth + 6.0f;
                float auraY = getPosY() + (float) y_offset - elementHeight - 4.0f;

                Render2DEngine.drawHudBase(matrices, auraX, auraY, auraWidth, auraHeight, HudEditor.hudRound.getValue());
                String rangeText = String.format("%.2f", getAuraRange());
                FontRenderers.sf_bold_mini.drawCenteredString(
                        matrices,
                        rangeText,
                        auraX + auraWidth / 2.0f,
                        auraY + (auraHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2.0f + 2f,
                        animatedColor.getRGB()
                );
            }

            if (feature instanceof FakeLag fakeLag) {
                if (feature.isOn() && fakeLag.isLaggingNow()) {
                    String lagText = fakeLag.getCurrentLagMs() + "ms";
                    float lagWidth = Math.max(28.0f, FontRenderers.sf_bold_mini.getStringWidth(lagText) + 12.0f);
                    float lagHeight = 14.0f;
                    float lagX = isOnRightSide ?
                            slideX - lagWidth - 6.0f :
                            slideX + elementWidth + 6.0f;
                    float lagY = getPosY() + (float) y_offset - elementHeight - 4.0f;

                    Render2DEngine.drawHudBase(matrices, lagX, lagY, lagWidth, lagHeight, HudEditor.hudRound.getValue());
                    FontRenderers.sf_bold_mini.drawCenteredString(
                            matrices,
                            lagText,
                            lagX + lagWidth / 2.0f,
                            lagY + (lagHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2.0f + 2f,
                            animatedColor.getRGB()
                    );
                }
            }
        }

        if (!hasAnyBinds) {
            y_offset += 12;
            float elementWidth = 80.0f;
            float elementHeight = 14.0f;

            float noBindsTextX = isOnRightSide ?
                    getPosX() + elementWidth - FontRenderers.sf_bold_mini.getStringWidth("No keybinds") - 6.0f :
                    getPosX() + 6.0f;

            Render2DEngine.drawHudBase(matrices, getPosX(), getPosY() + (float) y_offset, elementWidth, elementHeight, HudEditor.hudRound.getValue());
            FontRenderers.sf_bold_mini.drawString(
                    matrices,
                    "No keybinds",
                    noBindsTextX,
                    getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f,
                    offcolor.getValue().getColor()
            );

            y_offset += elementHeight + 4.0f;
            max_width = Math.max(max_width, elementWidth);
        }

        setBounds(getPosX(), getPosY(), Math.max(headerWidth, max_width + (max_width > 0.0f ? 42 : 0)), y_offset + 12);
    }

    @NotNull
    public static String getShortKeyName(Module feature) {
        String sbind = feature.getBind().getBind();
        String keyName = switch (sbind) {
            case "LEFT_CONTROL" -> "LCTRL";
            case "RIGHT_CONTROL" -> "RCTRL";
            case "LEFT_SHIFT" -> "LSHIFT";
            case "RIGHT_SHIFT" -> "RSHIFT";
            case "LEFT_ALT" -> "LALT";
            case "RIGHT_ALT" -> "RALT";
            default -> sbind.toUpperCase();
        };
        return " " + keyName + " ";
    }

    private float getAuraRange() {
        if (mc.player != null && mc.player.isFallFlying() && ModuleManager.aura.elytra.getValue()) {
            return ModuleManager.aura.elytraAttackRange.getValue();
        }
        return ModuleManager.aura.attackRange.getValue();
    }
}
