package better.tree.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.redstones.mediaplayerinfo.IMediaSession;
import dev.redstones.mediaplayerinfo.MediaInfo;
import dev.redstones.mediaplayerinfo.MediaPlayerInfo;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.utility.Timer;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MediaNowPlaying extends HudElement {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private MediaInfo media = new MediaInfo("", "", new byte[0], 0, 0, false);
    private final Identifier artworkId = Identifier.of("veltragossa:media/artwork");
    private byte[] lastArtwork = new byte[0];

    private final Timer lastMediaTimer = new Timer();
    private float exitAnim = 0f;
    private float progressAnim = 0f;

    public MediaNowPlaying() { super("ShowMedia", 160, 36); }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.age % 5 != 0) return;

        executor.execute(() -> {
            try {
                MediaInfo info = MediaPlayerInfo.Instance.getMediaSessions()
                        .stream()
                        .map(s -> {
                            try { return s.getMedia(); } catch (Throwable ignored) { return null; }
                        })
                        .filter(mi -> mi != null)
                        .max(Comparator.comparing(MediaInfo::getPlaying))
                        .orElse(null);
                if (info != null) {
                    String ti = safe(info == null ? null : info.getTitle());
                    String ar = safe(info == null ? null : info.getArtist());
                    if (info != null && (!ti.isEmpty() || !ar.isEmpty())) {
                        byte[] art = info.getArtworkPng();
                        if (art != null && art.length > 0 && !Arrays.equals(art, lastArtwork)) {
                            uploadArtwork(art);
                            lastArtwork = art;
                        }
                        if (art == null || art.length == 0) {
                            lastArtwork = new byte[0];
                        }
                        media = info;
                        lastMediaTimer.reset();
                    }
                }
            } catch (Throwable ignored) {}
        });
    }

    private void uploadArtwork(byte[] png) {
        try {
            ByteBuffer buf = ByteBuffer.allocateDirect(png.length);
            buf.put(png).flip();
            NativeImage img = NativeImage.read(buf);
            NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
            mc.execute(() -> mc.getTextureManager().registerTexture(artworkId, tex));
        } catch (Exception ignored) {}
    }

    @Override
    public void onRender2D(DrawContext ctx) {
        super.onRender2D(ctx);

        boolean visible = !lastMediaTimer.passedMs(2000);
        float dt = Math.max(0.01f, better.tree.utility.render.Render3DEngine.getTickDelta());
        float targetExit = visible ? 1f : 0f;
        exitAnim += (targetExit - exitAnim) * Math.min(1f, dt * 10f);
        if (exitAnim < 0.02f) return;

        String title = safe(media.getTitle());
        if (title.isEmpty()) title = "No title";
        String artist = safe(media.getArtist());

        float coverBoxSize = 32f;
        float infoBoxWidth = 110f;
        float padding = 6f;
        float borderRadius = 4f;

        float width = coverBoxSize + infoBoxWidth;
        float height = coverBoxSize;
        float x = getPosX();
        float y = getPosY();

        ctx.getMatrices().push();
        float cx = x + width / 2f;
        float cy = y + height / 2f;
        ctx.getMatrices().translate(cx, cy, 0);
        ctx.getMatrices().scale(exitAnim, exitAnim, 1f);
        ctx.getMatrices().translate(-cx, -cy, 0);


        Render2DEngine.drawHudBase(ctx.getMatrices(), x, y, width, height, HudEditor.hudRound.getValue());


        float imgPadding = 4f;
        float imgSize = coverBoxSize - imgPadding * 2f;
        if (lastArtwork.length > 0) {
            RenderSystem.setShader(GameRenderer::getPositionTexProgram);
            RenderSystem.setShaderTexture(0, artworkId);
            Render2DEngine.renderTexture(ctx.getMatrices(), x + imgPadding, y + imgPadding, imgSize, imgSize, 0, 0, imgSize, imgSize, imgSize, imgSize);
        } else {
            Render2DEngine.drawRound(ctx.getMatrices(), x + imgPadding, y + imgPadding, imgSize, imgSize, 2f, HudEditor.getColor(0));
        }


        float rightContentX = x + coverBoxSize + padding;
        float rightContentWidth = infoBoxWidth - padding * 2f;
        float titleY = y + 8f;
        float artistY = titleY + 10f;

        Color titleColor = new Color(HudEditor.textColor.getValue().getColor(), true);
        Color artistColor = new Color(HudEditor.textColor2.getValue().getColor(), true);

        Render2DEngine.addWindow(ctx.getMatrices(), rightContentX, y, rightContentX + rightContentWidth, y + height, 1.0);
        drawScrolling(ctx, title, rightContentX, titleY, titleColor, rightContentWidth);
        if (!artist.isEmpty()) drawScrolling(ctx, artist, rightContentX, artistY, artistColor, rightContentWidth);
        Render2DEngine.popWindow();


        float progress = media.getDuration() > 0 ? Math.min(1f, Math.max(0f, (float) media.getPosition() / (float) media.getDuration())) : 0f;
        progressAnim += (progress - progressAnim) * Math.min(1f, dt * 10f);
        float sliderY = y + height - 7f;
        Render2DEngine.drawRound(ctx.getMatrices(), rightContentX, sliderY, rightContentWidth, 2f, 1f, new Color(0x22000000, true));
        Render2DEngine.renderRoundedGradientRect(ctx.getMatrices(), HudEditor.getColor(0), HudEditor.getColor(90), HudEditor.getColor(90), HudEditor.getColor(0), rightContentX, sliderY, rightContentWidth * progressAnim, 2f, 1f);

        setBounds(x, y, width, height);
        ctx.getMatrices().pop();
    }

    private void drawScrolling(DrawContext ctx, String text, float x, float y, Color color, float maxWidth) {
        text = safe(text);
        float full = FontRenderers.getModulesRenderer().getStringWidth(text);
        float shownX = x;
        if (full > maxWidth) {
            long now = System.currentTimeMillis();
            float pause = 1000f, duration = 4000f;
            float total = pause + duration + pause + duration;
            float t = (now % (long) total);
            if (t < pause) shownX = x;
            else if (t < pause + duration) shownX = x - (t - pause) / duration * (full - maxWidth);
            else if (t < pause + duration + pause) shownX = x - (full - maxWidth);
            else shownX = x - (full - maxWidth) + (t - (pause + duration + pause)) / duration * (full - maxWidth);
        }
        FontRenderers.getModulesRenderer().drawString(ctx.getMatrices(), text, shownX, y, color.getRGB());
    }

    private static String safe(String s) { return s == null ? "" : s; }
}
