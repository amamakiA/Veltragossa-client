package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.animation.AnimationUtility;

import java.awt.*;

public class Cooldowns extends HudElement {
    private final Setting<ColorSetting> barColor = new Setting<>("BarColor", new ColorSetting(new Color(0xFF00FF00)));
    private final Setting<Boolean> showTitle = new Setting<>("ShowTitle", true);


    private float animationAttack = 0f;
    private float animationHurt = 0f;

    private float width, height;

    public Cooldowns() {
        super("Cooldowns", 100, 100);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        float posX = getPosX();
        float posY = getPosY();
        float padding = 5f;
        float barWidth = 65f;
        float barHeight = 5f;
        float labelSpacing = 10f;
        float fontSize = 6.5f;

        animationAttack = AnimationUtility.fast(animationAttack, mc.player.getAttackCooldownProgress(0.5f), 50f);
        animationHurt = AnimationUtility.fast(animationHurt, 1f - ((float) mc.player.hurtTime / 10f), 50f);

        width = 100f;
        height = showTitle.getValue() ? 40f : 30f;

        Render2DEngine.drawHudBase(context.getMatrices(), posX, posY, width, height, HudEditor.hudRound.getValue());

        if (showTitle.getValue()) {
            FontRenderers.sf_bold.drawCenteredString(context.getMatrices(),
                    "Cooldowns",
                    posX + width / 2,
                    posY + padding,
                    HudEditor.textColor.getValue().getColorObject());
            posY += fontSize + padding;
        }



        float barY1 = posY + labelSpacing;
        float barY2 = posY + labelSpacing * 2;
        float barRadius = 2.5f;
        float barTextOffset1 = (barHeight - FontRenderers.sf_bold_mini.getFontHeight("Attack")) / 2;
        float barTextOffset2 = (barHeight - FontRenderers.sf_bold_mini.getFontHeight("Hurt")) / 2;


        Render2DEngine.drawBlurredShadow(context.getMatrices(), posX + 30f - 2, barY1 - 2, barWidth + 4, barHeight + 4, 8, new Color(0,0,0,40));
        Render2DEngine.drawBlurredShadow(context.getMatrices(), posX + 30f - 2, barY2 - 2, barWidth + 4, barHeight + 4, 8, new Color(0,0,0,40));


        Render2DEngine.drawRound(context.getMatrices(), posX + 30f, barY1, barWidth, barHeight, barRadius, new Color(0, 0, 0, 64));
        Render2DEngine.drawRound(context.getMatrices(), posX + 30f, barY2, barWidth, barHeight, barRadius, new Color(0, 0, 0, 64));


        Render2DEngine.drawRound(context.getMatrices(), posX + 30f, barY1, barWidth * animationAttack, barHeight, barRadius, barColor.getValue().getColorObject());
        Render2DEngine.drawRound(context.getMatrices(), posX + 30f, barY2, barWidth * animationHurt, barHeight, barRadius, barColor.getValue().getColorObject());


        FontRenderers.sf_bold_mini.drawString(context.getMatrices(), "Attack", posX + padding, barY1 + barTextOffset1, HudEditor.textColor.getValue().getColor());
        FontRenderers.sf_bold_mini.drawString(context.getMatrices(), "Hurt", posX + padding, barY2 + barTextOffset2, HudEditor.textColor.getValue().getColor());

        setBounds(getPosX(), getPosY(), width, height);
    }
}