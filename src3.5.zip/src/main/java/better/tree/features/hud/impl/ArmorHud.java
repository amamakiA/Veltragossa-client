package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;
import java.util.List;

public class ArmorHud extends HudElement {
    private final Setting<Mode> mode = new Setting<>("Durability", Mode.YES);
    private final Setting<ColorSetting> barColor = new Setting<>("DurabilityBarColor", new ColorSetting(new Color(0xFF00FF00)));
    private final Setting<Boolean> showTitle = new Setting<>("ShowTitle", false);

    public ArmorHud() {
        super("ArmorHud", 60, 25);
    }

    private enum Mode {
        NOPE, YES, DIGITAL
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        float posX = getPosX();
        float posY = getPosY();
        float padding = 5f;
        float itemSize = 20f;
        float spacing = 4f;

        List<ItemStack> armorItems = mc.player.getInventory().armor.stream()
                .filter(stack -> !stack.isEmpty())
                .toList();

        if (armorItems.isEmpty()) {
            return;
        }

        float width, height;
        float xItemOffset, yItemOffset;

        if (mode.getValue() == Mode.DIGITAL) {
            width = itemSize + 60;
            height = armorItems.size() * (itemSize + 6) + padding * 2 + (showTitle.getValue() ? 10 : 0);
            xItemOffset = posX + padding;
            yItemOffset = posY + padding + (showTitle.getValue() ? 10 : 0);
        } else {
            width = armorItems.size() * (itemSize + spacing) - spacing + padding * 2;
            height = itemSize + padding * 2 + (showTitle.getValue() ? 10 : 0);
            float totalItemsWidth = armorItems.size() * itemSize + (armorItems.size() - 1) * spacing;
            xItemOffset = showTitle.getValue() ? posX + padding : posX + (width - totalItemsWidth) / 2f;
            yItemOffset = posY + padding + (showTitle.getValue() ? 10 : 0);
        }

        Render2DEngine.drawHudBase(context.getMatrices(), posX, posY, width, height, HudEditor.hudRound.getValue());
        setBounds(posX, posY, width, height);

        if (showTitle.getValue()) {
            FontRenderers.sf_bold.drawCenteredString(context.getMatrices(), "Armor", posX + width / 2, posY + padding, HudEditor.textColor.getValue().getColorObject());
        }

        for (ItemStack itemStack : armorItems.reversed()) {
            if (itemStack.isEmpty()) continue;

            switch (mode.getValue()) {
                case NOPE -> {
                    context.drawItem(itemStack, (int) xItemOffset, (int) yItemOffset);
                    context.drawItemInSlot(mc.textRenderer, itemStack, (int) xItemOffset, (int) yItemOffset);
                    xItemOffset += itemSize + spacing;
                }
                case YES -> {
                    context.drawItem(itemStack, (int) xItemOffset, (int) yItemOffset);
                    context.drawItemInSlot(mc.textRenderer, itemStack, (int) xItemOffset, (int) yItemOffset);

                    if (itemStack.getMaxDamage() > 0) {
                        float durabilityRatio = 1f - ((float) itemStack.getDamage() / itemStack.getMaxDamage());
                        float barHeight = itemSize * durabilityRatio;
                        float barY = yItemOffset + itemSize - barHeight;

                        Render2DEngine.drawRect(context.getMatrices(),
                                xItemOffset + itemSize - 3,
                                barY,
                                2,
                                barHeight,
                                barColor.getValue().getColorObject());
                    }

                    xItemOffset += itemSize + spacing;
                }
                case DIGITAL -> {
                    context.drawItem(itemStack, (int) xItemOffset, (int) yItemOffset);
                    context.getMatrices().push();
                    context.getMatrices().translate(0, 0, 151);

                    if (itemStack.getMaxDamage() > 0) {
                        int max = itemStack.getMaxDamage();
                        int current = max - itemStack.getDamage();
                        float ratio = (float) current / max;

                        Color durabilityColor;
                        if (ratio > 0.6f) {
                            durabilityColor = new Color(0xFF00FF00);
                        } else if (ratio > 0.3f) {
                            durabilityColor = new Color(0xFFFFFF00);
                        } else {
                            durabilityColor = new Color(0xFFFF0000);
                        }

                        String durabilityText = current + "/" + max;

                        Render2DEngine.drawBlurredShadow(context.getMatrices(), xItemOffset + itemSize + 16, yItemOffset + 8, 9, 9, 12, Color.BLACK);
                        FontRenderers.sf_medium.drawCenteredString(context.getMatrices(), durabilityText, (int) (xItemOffset + itemSize + 20), (int) (yItemOffset + 11f), durabilityColor);
                    }

                    context.getMatrices().pop();
                    yItemOffset += itemSize + 6;
                }
            }
        }
    }
}