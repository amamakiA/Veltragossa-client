
package better.tree.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import better.tree.core.Managers;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.setting.Setting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

public class TPSCounter extends HudElement {

    private final Setting<Boolean> extraTps = new Setting<>("ExtraTPS", true);

    public TPSCounter() {
        super("TPS", 50, 10);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        String str = "TPS " + Managers.SERVER.getTPS();
        if (extraTps.getValue()) {
            str += " [" + Managers.SERVER.getTPS2() + "]";
        }

        float textWidth = FontRenderers.getModulesRenderer().getStringWidth(str);
        float padding = 6f;
        float iconSize = 10f;
        float width = textWidth + iconSize + padding * 3;
        float height = 13f;
        float pX = getPosX();
        float pY = getPosY();

        Render2DEngine.drawHudBase(context.getMatrices(), pX, pY, width, height, HudEditor.hudRound.getValue());

        Render2DEngine.setupRender();
        RenderSystem.setShaderTexture(0, TextureStorage.tpsIcon);
        Render2DEngine.renderGradientTexture(
                context.getMatrices(),
                pX + padding,
                pY + 1.5f,
                iconSize,
                iconSize,
                0, 0, 512, 512, 512, 512,
                HudEditor.getColor(270),
                HudEditor.getColor(0),
                HudEditor.getColor(180),
                HudEditor.getColor(90)
        );
        Render2DEngine.endRender();

        FontRenderers.getModulesRenderer().drawString(
                context.getMatrices(),
                str,
                pX + iconSize + padding * 2,
                pY + 4f,
                HudEditor.textColor.getValue().getColor()
        );

        setBounds(pX, pY, width, height);
    }
}