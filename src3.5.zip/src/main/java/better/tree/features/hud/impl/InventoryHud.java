package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.windows.WindowsScreen;
import better.tree.setting.Setting;
import better.tree.utility.render.Render2DEngine;

public class InventoryHud extends HudElement {
    private final Setting<Float> scale = new Setting<>("Scale", 1.0f, 0.5f, 2.0f);
    public InventoryHud() {
        super("InventoryHud", 100, 100);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        if (mc.currentScreen instanceof WindowsScreen) return;
        PlayerEntity player = mc.player;
        if (player == null) return;

        MatrixStack matrices = context.getMatrices();
        float x = getPosX();
        float y = getPosY();
        float slotSize = 18 * scale.getValue();
        float spacing = 2 * scale.getValue();
        float totalWidth = slotSize * 9 + spacing * 8;
        float totalHeight = slotSize * 3 + spacing * 2;

        Render2DEngine.drawHudBase(matrices, x, y, totalWidth, totalHeight, HudEditor.hudRound.getValue());

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int index = 9 + row * 9 + col;
                ItemStack stack = player.getInventory().main.get(index);
                float slotX = x + col * (slotSize + spacing);
                float slotY = y + row * (slotSize + spacing);
                renderItem(context, stack, (int) slotX, (int) slotY, scale.getValue());
            }
        }

        setBounds(getPosX(), getPosY(), totalWidth, totalHeight);
    }

    private void renderItem(DrawContext context, ItemStack stack, int x, int y, float scale) {
        if (!stack.isEmpty()) {
            context.getMatrices().push();
            context.getMatrices().translate(x + 8 * scale, y + 8 * scale, 0.0F);
            context.getMatrices().scale(scale * 0.9f, scale * 0.9f, 1.0F);
            context.getMatrices().translate(-(x + 8 * scale), -(y + 8 * scale), 0.0F);
            context.drawItem(stack, x, y);
            context.drawItemInSlot(mc.textRenderer, stack, x, y);
            context.getMatrices().pop();
        }
    }
}