package better.tree.features.hud.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import better.tree.setting.impl.ColorSetting;
import better.tree.veltragossa;
import better.tree.core.Managers;
import better.tree.core.manager.client.ModuleManager;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.features.modules.client.Media;
import better.tree.features.modules.misc.NameProtect;
import better.tree.setting.Setting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextUtil;
import better.tree.utility.render.TextureStorage;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WaterMark extends HudElement {
    public WaterMark() {
        super("WaterMark", 100, 35);
    }

    public static final Setting<Mode> mode = new Setting<>("Mode", Mode.New);
    public final Setting<Boolean> background = new Setting<>("Background", true);
    public final Setting<ColorSetting> backgroundColor = new Setting<>("Background Color", new ColorSetting(new Color(0, 0, 0, 100)));
    public final Setting<ColorSetting> textColor = new Setting<>("Text Color", new ColorSetting(-1));
    public final Setting<ColorSetting> veltraColor = new Setting<>("Logo color", new ColorSetting(-1));
    private final Setting<Boolean> ru = new Setting<>("Random Text", false, v -> mode.getValue() == Mode.Small);

    private final TextUtil textUtil = new TextUtil(
            "Veltra/Gossa",
            "Better/Than/Paid??",
            "GrozaClient",
            "Vanadium = cool? Nope.",
            "Legit/Rage",
            "2115<3",
            "VeltragoHuj",
            "aMamaki",
            "Skibidi tojlet",
            "Chipi Chipa Chapa Chapa",
            "Who's in charge here? Veltra rules! ezz",
            "DzikiKukurydz",
            "VeltraKruk",
            "Sophie Rain",
            "Sakura is good? NOO!",
            "Tung Tung Tung Sahur",
            "Valorant = Gey",
            "Celestial = cool",
            "SexIGroszek",
            "Dc:Zelek5351",
            "VeltraCipka",
            "Kabanosik",
            "Absolute Cinema",
            "NiggaHack<3",
            "Bebeto",
            "Grim = Trash"

    );

    private enum Mode {
        Big, Small, New
    }

    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        String username = ((ModuleManager.media.isEnabled() && Media.nickProtect.getValue()) || ModuleManager.nameProtect.isEnabled()) ? (ModuleManager.nameProtect.isEnabled() ? NameProtect.getCustomName() : "Protected") : mc.getSession().getUsername();

        if (mode.getValue() == Mode.Big) {
            if (background.getValue()) {
                Render2DEngine.drawRound(context.getMatrices(), getPosX(), getPosY(), 106, 30, 3, backgroundColor.getValue().getColorObject());
            }
            FontRenderers.thglitch.drawString(context.getMatrices(), "Veltragossa", getPosX() + 5.5, getPosY() + 5, veltraColor.getValue().getColor());
            FontRenderers.monsterrat.drawString(context.getMatrices(), " " + veltragossa.VERSION +"  Release", getPosX() + 35.5f, getPosY() + 21f, textColor.getValue().getColor());
            setBounds(getPosX(), getPosY(), 106, 30);
        } else if (mode.getValue() == Mode.Small) {
            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                float offset1 = FontRenderers.sf_bold.getStringWidth(username) + 72;
                float offset2 = FontRenderers.sf_bold.getStringWidth((mc.isInSingleplayer() ? "SinglePlayer" : mc.getNetworkHandler().getServerInfo().address));
                float offset3 = (Managers.PROXY.isActive() ? FontRenderers.sf_bold.getStringWidth(Managers.PROXY.getActiveProxy().getName()) + 11 : 0);

                if (background.getValue()) {
                    Render2DEngine.drawRoundedBlur(context.getMatrices(), getPosX(), getPosY(), 50f, 15f, 3, backgroundColor.getValue().getColorObject());
                    Render2DEngine.drawRoundedBlur(context.getMatrices(), getPosX() + 55, getPosY(), offset1 + offset2 - 36 + offset3, 15f, 3, backgroundColor.getValue().getColorObject());
                }

                Render2DEngine.setupRender();

                Render2DEngine.drawRect(context.getMatrices(), getPosX() + 13, getPosY() + 1.5f, 0.5f, 11, new Color(0x44FFFFFF, true));

                FontRenderers.sf_bold.drawString(context.getMatrices(),  "  "+ veltragossa.VERSION, getPosX() + 18, getPosY() + 5, textColor.getValue().getColor());

                RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
                RenderSystem.setShaderTexture(0, TextureStorage.miniLogo);
                Render2DEngine.renderGradientTexture(context.getMatrices(), getPosX() + 1, getPosY() + 2, 11, 11, 0, 0, 128, 128, 128, 128,
                        HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));

                RenderSystem.setShaderTexture(0, TextureStorage.playerIcon);
                Render2DEngine.renderGradientTexture(context.getMatrices(), getPosX() + 58, getPosY() + 3, 8, 8, 0, 0, 128, 128, 128, 128,
                        HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));

                RenderSystem.setShaderTexture(0, TextureStorage.serverIcon);
                Render2DEngine.renderGradientTexture(context.getMatrices(), getPosX() + offset1, getPosY() + 2, 10, 10, 0, 0, 128, 128, 128, 128,
                        HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));

                if (Managers.PROXY.isActive()) {
                    RenderSystem.setShaderTexture(0, TextureStorage.proxyIcon);
                    Render2DEngine.renderGradientTexture(context.getMatrices(), getPosX() + offset1 + offset2 + 16, getPosY() + 2, 10, 10, 0, 0, 128, 128, 128, 128,
                            HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));

                    FontRenderers.sf_bold.drawString(context.getMatrices(), Managers.PROXY.getActiveProxy().getName(), getPosX() + offset1 + offset2 + 28, getPosY() + 5, textColor.getValue().getColor());
                }

                Render2DEngine.endRender();

                Render2DEngine.setupRender();
                RenderSystem.defaultBlendFunc();
                FontRenderers.sf_bold.drawString(context.getMatrices(), username, getPosX() + 68, getPosY() + 4.5f, textColor.getValue().getColor());
                FontRenderers.sf_bold.drawString(context.getMatrices(), (mc.isInSingleplayer() ? "SinglePlayer" : mc.getNetworkHandler().getServerInfo().address), getPosX() + offset1 + 13, getPosY() + 4.5f, textColor.getValue().getColor());
                Render2DEngine.endRender();
                setBounds(getPosX(), getPosY(), 100, 15f);
            } else {
                String firstPart = ru.getValue() ? textUtil.toString() + " " : "Veltragossa ";
                String info = " | " + username + " | " + Managers.SERVER.getPing() + " ms" + " | " + (mc.isInSingleplayer() ? "SinglePlayer" : mc.getNetworkHandler().getServerInfo().address);
                float width = FontRenderers.sf_bold.getStringWidth(firstPart + info) + 5;
                if (background.getValue()) {
                    Render2DEngine.drawRound(context.getMatrices(), getPosX(), getPosY(), width, 10, 3, backgroundColor.getValue().getColorObject());
                }
                FontRenderers.sf_bold.drawString(context.getMatrices(), firstPart, getPosX() + 2, getPosY() + 2.5f, veltraColor.getValue().getColor());
                FontRenderers.sf_bold.drawString(context.getMatrices(), info, getPosX() + 2 + FontRenderers.sf_bold.getStringWidth(firstPart), getPosY() + 2.5f, textColor.getValue().getColor());
                setBounds(getPosX(), getPosY(), width, 10);
            }
        } else if (mode.getValue() == Mode.New) {
            SimpleDateFormat format = new SimpleDateFormat("HH:mm");
            String time = format.format(new Date());
            String tps = String.format("%.1f", Managers.SERVER.getTPS());
            String info = username + " | " + tps + " tps | " + time;
            float width = FontRenderers.sf_bold.getStringWidth("Veltragossa " + info) + 10;
            if (background.getValue()) {
                Render2DEngine.drawRound(context.getMatrices(), getPosX(), getPosY(), width, 18, 3, backgroundColor.getValue().getColorObject());
            }
            FontRenderers.sf_bold.drawString(context.getMatrices(), "Veltragossa", getPosX() + 5, getPosY() + 5, veltraColor.getValue().getColor());
            FontRenderers.sf_bold.drawString(context.getMatrices(), info, getPosX() + 5 + FontRenderers.sf_bold.getStringWidth("Veltragossa "), getPosY() + 5, textColor.getValue().getColor());
            setBounds(getPosX(), getPosY(), width, 18);
        }
    }

    @Override
    public void onUpdate() {
        textUtil.tick();
    }
}