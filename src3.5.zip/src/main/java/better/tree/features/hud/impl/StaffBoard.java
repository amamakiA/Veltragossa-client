package better.tree.features.hud.impl;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;
import better.tree.features.cmd.impl.StaffCommand;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

import java.util.List;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StaffBoard extends HudElement {
    private static final Pattern validUserPattern = Pattern.compile("^\\w{3,16}$");
    private List<String> players = new ArrayList<>();
    private List<String> notSpec = new ArrayList<>();

    public StaffBoard() {
        super("StaffBoard", 50, 50);
    }

    public static List<String> getOnlinePlayer() {
        return mc.player.networkHandler.getPlayerList().stream()
                .map(PlayerListEntry::getProfile)
                .map(GameProfile::getName)
                .filter(profileName -> validUserPattern.matcher(profileName).matches())
                .collect(Collectors.toList());
    }

    public static List<String> getOnlinePlayerD() {
        List<String> S = new ArrayList<>();
        for (PlayerListEntry player : mc.player.networkHandler.getPlayerList()) {
            if (mc.isInSingleplayer() || player.getScoreboardTeam() == null) break;
            String prefix = player.getScoreboardTeam().getPrefix().getString();
            if (check(Formatting.strip(prefix).toLowerCase())
                    || StaffCommand.staffNames.toString().toLowerCase().contains(player.getProfile().getName().toLowerCase())
                    || player.getProfile().getName().toLowerCase().contains("1danil_mansoru1")
                    || player.getProfile().getName().toLowerCase().contains("barslan_")
                    || player.getProfile().getName().toLowerCase().contains("timmings")
                    || player.getProfile().getName().toLowerCase().contains("timings")
                    || player.getProfile().getName().toLowerCase().contains("ruthless")
                    || player.getScoreboardTeam().getPrefix().getString().contains("YT")
                    || (player.getScoreboardTeam().getPrefix().getString().contains("Y") && player.getScoreboardTeam().getPrefix().getString().contains("T"))) {
                String name = Arrays.asList(player.getScoreboardTeam().getPlayerList().toArray()).toString().replace("[", "").replace("]", "");

                if (player.getGameMode() == GameMode.SPECTATOR) {
                    S.add(player.getScoreboardTeam().getPrefix().getString() + name + ":gm3");
                    continue;
                }
                S.add(player.getScoreboardTeam().getPrefix().getString() + name + ":active");
            }
        }
        return S;
    }

    public List<String> getVanish() {
        List<String> list = new ArrayList<>();
        for (Team s : mc.world.getScoreboard().getTeams()) {
            if (s.getPrefix().getString().isEmpty() || mc.isInSingleplayer()) continue;
            String name = Arrays.asList(s.getPlayerList().toArray()).toString().replace("[", "").replace("]", "");

            if (getOnlinePlayer().contains(name) || name.isEmpty())
                continue;
            if (StaffCommand.staffNames.toString().toLowerCase().contains(name.toLowerCase())
                    && check(s.getPrefix().getString().toLowerCase())
                    || check(s.getPrefix().getString().toLowerCase())
                    || name.toLowerCase().contains("1danil_mansoru1")
                    || name.toLowerCase().contains("barslan_")
                    || name.toLowerCase().contains("timmings")
                    || name.toLowerCase().contains("timings")
                    || name.toLowerCase().contains("ruthless")
                    || s.getPrefix().getString().contains("YT")
                    || (s.getPrefix().getString().contains("Y") && s.getPrefix().getString().contains("T"))
            )
                list.add(s.getPrefix().getString() + name + ":vanish");
        }
        return list;
    }

    public static boolean check(String name) {
        if (mc.getCurrentServerEntry() != null && mc.getCurrentServerEntry().address.contains("mcfunny")) {
            return name.contains("helper") || name.contains("moder") || name.contains("модер") || name.contains("хелпер");
        }
        return name.contains("mod") || name.contains("moderator") || name.contains("pom") || name.contains("pomocnik") || name.contains("smod") || name.contains("th") || name.contains("helper") || name.contains("moder") || name.contains("admin") || name.contains("owner") || name.contains("curator") || name.contains("ᴘᴏᴍ") || name.contains("ᴀᴅᴍɪɴ") || name.contains("ᴘᴏᴍᴏᴄɴɪᴋ") || name.contains("хелпер") || name.contains("поддержка") || name.contains("сотрудник") || name.contains("зам") || name.contains("стажёр");
    }

    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        List<String> all = new java.util.ArrayList<>();
        all.addAll(players);
        all.addAll(notSpec);

        String staffString = all.stream()
                .map(s -> s.split(":")[0] + " (" + (s.split(":")[1].equalsIgnoreCase("vanish") ? "V" : s.split(":")[1].equalsIgnoreCase("gm3") ? "GM3" : "A") + ")")
                .collect(Collectors.joining(", "));

        if (staffString.isEmpty()) {
            staffString = "No staff online";
        }

        float textWidth = FontRenderers.getModulesRenderer().getStringWidth(staffString);
        float padding = 6f;
        float iconSize = 10f;
        float width = textWidth + iconSize + padding * 3;
        float height = 13f;
        float pX = getPosX();
        float pY = getPosY();

        Render2DEngine.drawHudBase(context.getMatrices(), pX, pY, width, height, HudEditor.hudRound.getValue());

        Render2DEngine.setupRender();
        RenderSystem.setShaderTexture(0, TextureStorage.thTeam);
        Render2DEngine.renderGradientTexture(
                context.getMatrices(),
                pX + padding,
                pY + 1.5f,
                iconSize,
                iconSize,
                0, 0, 30, 30, 30, 30,
                HudEditor.getColor(270),
                HudEditor.getColor(0),
                HudEditor.getColor(180),
                HudEditor.getColor(90)
        );
        Render2DEngine.endRender();

        FontRenderers.getModulesRenderer().drawString(
                context.getMatrices(),
                staffString,
                pX + iconSize + padding * 2,
                pY + 4f,
                HudEditor.textColor.getValue().getColor()
        );

        setBounds(pX, pY, width, height);
    }

    @Override
    public void onUpdate() {
        if (mc.player != null && mc.player.age % 10 == 0) {
            players = getVanish();
            notSpec = getOnlinePlayerD();
            players.sort(String::compareTo);
            notSpec.sort(String::compareTo);
        }
    }
}