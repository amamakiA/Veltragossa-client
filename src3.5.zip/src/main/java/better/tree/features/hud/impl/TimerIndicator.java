package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.features.modules.movement.Timer;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.animation.EaseOutCirc;

import java.awt.*;

public class TimerIndicator extends HudElement {
    private final EaseOutCirc timerAnimation = new EaseOutCirc();

    public TimerIndicator() {
        super("TimerIndicator", 70, 18);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        float x = getPosX();
        float y = getPosY();
        float width = 80f;
        float height = 14f;

        String percentText = Timer.energy >= 0.99f ? "100%" : (int) Math.ceil(Timer.energy * 100f) + "%";

        if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
            Render2DEngine.drawRoundedBlur(context.getMatrices(), x, y, width, height, 4,
                    HudEditor.getBlurColor());
            Render2DEngine.drawRect(context.getMatrices(), x, y, width, height, new Color(0, 0, 0, 110));

            Render2DEngine.draw2DGradientRect(context.getMatrices(), x, y, x + width * Timer.energy, y + height,
                    HudEditor.getColor(0), HudEditor.getColor(90), HudEditor.getColor(180), HudEditor.getColor(270));

            FontRenderers.sf_bold.drawCenteredString(context.getMatrices(),
                    percentText, x + width / 2f, y + (height / 2f - 4f), Color.WHITE.getRGB());

            setBounds(x, y, width, height);

        } else {
            Render2DEngine.drawGradientBlurredShadow(context.getMatrices(),
                    x - 1, y - 1, width + 2, height + 2, 6,
                    HudEditor.getColor(90), HudEditor.getColor(180), HudEditor.getColor(0), HudEditor.getColor(270));
            Render2DEngine.drawRect(context.getMatrices(), x, y, width, height, new Color(0, 0, 0, 150));
            Render2DEngine.draw2DGradientRect(context.getMatrices(), x, y, x + width * Timer.energy, y + height,
                    HudEditor.getColor(0), HudEditor.getColor(90), HudEditor.getColor(180), HudEditor.getColor(270));
            Render2DEngine.drawBlurredShadow(context.getMatrices(), x + width * 0.25f, y,
                    width * 0.5f, height, 6, new Color(0, 0, 0, 60));
            FontRenderers.sf_bold.drawCenteredString(context.getMatrices(),
                    percentText, x + width / 2f, y + (height / 2f - 4f), Color.WHITE.getRGB());

            setBounds(x, y, width, height);
        }
    }

    @Override
    public void onUpdate() {
        timerAnimation.update();
    }
}
