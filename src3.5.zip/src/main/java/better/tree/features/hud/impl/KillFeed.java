package better.tree.features.hud.impl;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EntityStatuses;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.jetbrains.annotations.NotNull;
import better.tree.events.impl.PacketEvent;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.features.modules.combat.Aura;
import better.tree.features.modules.combat.AutoCrystal;
import better.tree.setting.Setting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class KillFeed extends HudElement {
    public KillFeed() {
        super("KillFeed", 50, 50);
    }

    private Setting<Boolean> resetOnDeath = new Setting<>("ResetOnDeath", true);

    private final List<KillComponent> players = new ArrayList<>();

    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        String killFeedString = players.stream().map(KillComponent::getString).collect(Collectors.joining(", "));
        if (killFeedString.isEmpty()) {
            killFeedString = "No kills yet";
        }

        float textWidth = FontRenderers.getModulesRenderer().getStringWidth(killFeedString);
        float padding = 6f;
        float iconSize = 10f;
        float width = textWidth + iconSize + padding * 3;
        float height = 13f;
        float pX = getPosX();
        float pY = getPosY();

        Render2DEngine.drawHudBase(context.getMatrices(), pX, pY, width, height, HudEditor.hudRound.getValue());

        Render2DEngine.setupRender();
        RenderSystem.setShaderTexture(0, TextureStorage.swordIcon);
        Render2DEngine.renderGradientTexture(
                context.getMatrices(),
                pX + padding,
                pY + 1.5f,
                iconSize,
                iconSize,
                0, 0, 16, 16, 16, 16,
                HudEditor.getColor(270),
                HudEditor.getColor(0),
                HudEditor.getColor(180),
                HudEditor.getColor(90)
        );
        Render2DEngine.endRender();

        FontRenderers.getModulesRenderer().drawString(
                context.getMatrices(),
                killFeedString,
                pX + iconSize + padding * 2,
                pY + 4f,
                HudEditor.textColor.getValue().getColor()
        );

        setBounds(pX, pY, width, height);
    }

    @EventHandler
    public void onPacket(PacketEvent.@NotNull Receive e) {
        if (!(e.getPacket() instanceof EntityStatusS2CPacket pac)) return;
        if (pac.getStatus() == EntityStatuses.PLAY_DEATH_SOUND_OR_ADD_PROJECTILE_HIT_PARTICLES && pac.getEntity(mc.world) instanceof PlayerEntity pl) {

            if(pl == mc.player && resetOnDeath.getValue()) {
                players.clear();
                return;
            }

            if ((Aura.target != null && Aura.target == pac.getEntity(mc.world)) || (AutoCrystal.target != null && AutoCrystal.target == pac.getEntity(mc.world))) {
                for (KillComponent kc : Lists.newArrayList(players))
                    if (Objects.equals(kc.getName(), pl.getName().getString())) {
                        kc.increase();
                        return;
                    }
                players.add(new KillComponent(pl.getName().getString()));
            }
        }
    }

    @Override
    public void onDisable() {
        players.clear();
    }

    private class KillComponent {
        private String name;
        private int count;

        public KillComponent(String name) {
            this.name = name;
            this.count = 1;
        }

        public void increase() {
            count++;
        }

        public String getName() {
            return name;
        }

        public String getString() {
            return name + (count > 1 ?  (" (x" + count + ")") : "");
        }
    }
}