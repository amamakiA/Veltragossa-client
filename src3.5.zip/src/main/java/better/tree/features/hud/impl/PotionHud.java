package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Formatting;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;

public class PotionHud extends HudElement {
    public final Setting<ColorSetting> effectColor = new Setting<>("EffectColor", new ColorSetting(new Color(0xFFFFFF)));

    public final Setting<Boolean> colored = new Setting<>("UsePotionColor", true);


    private float width, height;

    public PotionHud() {
        super("PotionHud", 100, 100);
    }

    public static String getDuration(StatusEffectInstance pe) {
        if (pe.isInfinite()) {
            return "*:*";
        } else {
            int ticks = pe.getDuration();
            int mins = ticks / 1200;
            String sec = String.format("%02d", (ticks % 1200) / 20);
            return mins + ":" + sec;
        }
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        int y_offset = 0;
        float max_width = 0.0f;
        float elementHeight = 14.0f;

        float headerWidth = 60.0f;
        float headerHeight = 16.0f;


        boolean isOnRightSide = getPosX() > mc.getWindow().getScaledWidth() / 2;

        Render2DEngine.drawHudBase(context.getMatrices(), getPosX(), getPosY() - 7.0f, headerWidth, headerHeight, HudEditor.hudRound.getValue());


        float iconSize = 12.0f;
        float iconPadding = 4.0f;
        float iconY = getPosY() - 7.0f + (headerHeight - iconSize) / 2.0f;
        float textY = getPosY() - 7.0f + (headerHeight - FontRenderers.sf_bold.getFontHeight(" ")) / 2.0f + 2f;
        float textX;
        float iconX;
        if (isOnRightSide) {
            iconX = getPosX() + headerWidth - iconSize - iconPadding;
            textX = getPosX() + iconPadding;
        } else {
            iconX = getPosX() + iconPadding;
            textX = getPosX() + iconSize + iconPadding * 2;
        }

        Render2DEngine.setupRender();
        com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, better.tree.utility.render.TextureStorage.potion);
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
        Render2DEngine.renderGradientTexture(context.getMatrices(), iconX, iconY, iconSize, iconSize, 0, 0, 512, 512, 512, 512,
                HudEditor.getColor(270), HudEditor.getColor(0), HudEditor.getColor(180), HudEditor.getColor(90));
        Render2DEngine.endRender();

        FontRenderers.sf_bold.drawString(
                context.getMatrices(),
                "Potions",
                textX,
                textY,
                HudEditor.textColor.getValue().getColor()
        );

        y_offset += 12;

        boolean hasEffects = false;
        for (StatusEffectInstance potionEffect : mc.player.getStatusEffects()) {
            hasEffects = true;

            StatusEffect potion = potionEffect.getEffectType().value();

            String level = switch (potionEffect.getAmplifier()) {
                case 0 -> "I";
                case 1 -> "II";
                case 2 -> "III";
                case 3 -> "IV";
                case 4 -> "V";
                default -> "+" + (potionEffect.getAmplifier() + 1);
            };

            String nameText = potion.getName().getString() + " " + Formatting.RED + level;
            String timeText = getDuration(potionEffect);

            float nameWidth = FontRenderers.sf_bold_mini.getStringWidth(nameText);
            float timeWidth = FontRenderers.sf_bold_mini.getStringWidth(timeText);

            float elementWidth = 12.0f + nameWidth + 6.0f + timeWidth + 12.0f;


            float baseX = isOnRightSide ?
                    (getPosX() + headerWidth - elementWidth) :
                    getPosX();

            int baseColor = colored.getValue()
                    ? new Color(potionEffect.getEffectType().value().getColor()).getRGB()
                    : effectColor.getValue().getColor();
            Color c = new Color(baseColor, true);
            Color animatedColor = new Color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());

            float effectTextX = isOnRightSide ?
                    baseX + elementWidth - nameWidth - 6.0f :
                    baseX + 6.0f;
            float timeX = isOnRightSide ?
                    baseX + 10.0f :
                    baseX + elementWidth - 10.0f - timeWidth;
            float separatorX = isOnRightSide ?
                    baseX + timeWidth + 12.0f :
                    baseX + nameWidth + 12.0f;

            Render2DEngine.drawHudBase(context.getMatrices(), baseX, getPosY() + (float) y_offset, elementWidth, elementHeight, HudEditor.hudRound.getValue());
            FontRenderers.sf_bold_mini.drawString(context.getMatrices(), nameText, effectTextX, getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f, animatedColor.getRGB());
            FontRenderers.sf_bold_mini.drawString(context.getMatrices(), timeText, timeX, getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f, animatedColor.getRGB());
            Render2DEngine.drawRect(context.getMatrices(), separatorX, getPosY() + (float) y_offset + 2.0f, 0.5f, elementHeight - 4.0f, new Color(0x44FFFFFF, true));

            y_offset = (int) ((float) y_offset + (elementHeight + 4.0f));
            max_width = Math.max(max_width, elementWidth);
        }

        if (!hasEffects) {
            float elementWidth = 80.0f;
            float baseX = isOnRightSide ?
                    (getPosX() + headerWidth - elementWidth) :
                    getPosX();
            float noEffectsTextX = isOnRightSide ?
                    baseX + elementWidth - FontRenderers.sf_bold_mini.getStringWidth("No effects") - 6.0f :
                    baseX + 6.0f;

            Render2DEngine.drawHudBase(context.getMatrices(), baseX, getPosY() + (float) y_offset, elementWidth, elementHeight, HudEditor.hudRound.getValue());
            FontRenderers.sf_bold_mini.drawString(
                    context.getMatrices(),
                    "No effects",
                    noEffectsTextX,
                    getPosY() + (float) y_offset + (elementHeight - FontRenderers.sf_bold_mini.getFontHeight(" ")) / 2f + 2f,
                    effectColor.getValue().getColor()
            );

            y_offset += elementHeight + 4.0f;
            max_width = Math.max(max_width, elementWidth);
        }

        setBounds(getPosX(), getPosY(), Math.max(headerWidth, max_width), Math.max(y_offset, headerHeight + 12));
    }
}