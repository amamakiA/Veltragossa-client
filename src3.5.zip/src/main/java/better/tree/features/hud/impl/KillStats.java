package better.tree.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import better.tree.events.impl.PacketEvent;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.client.HudEditor;
import better.tree.features.modules.combat.Aura;
import better.tree.features.modules.combat.AutoCrystal;
import better.tree.utility.math.MathUtility;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

public class KillStats extends HudElement {
    private int death = 0, killstreak = 0, kills = 0;

    public KillStats() {
        super("KillStats", 100, 35);
    }

    @Override
    public void onDisable() {
        death = 0;
        kills = 0;
        killstreak = 0;
    }

    @EventHandler
    private void death(PacketEvent.Receive event) {
        if (event.getPacket() instanceof EntityStatusS2CPacket pac && pac.getStatus() == 3) {
            if (!(pac.getEntity(mc.world) instanceof PlayerEntity)) return;
            if (pac.getEntity(mc.world) == mc.player) {
                death++;
                killstreak = 0;
            } else if (Aura.target == pac.getEntity(mc.world) || AutoCrystal.target == pac.getEntity(mc.world)) {
                killstreak++;
                kills++;
            }
        }
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        String streak = "KillStreak: " + killstreak;
        String kd = " KD: " + MathUtility.round((float) kills / (death > 0 ? death : 1));
        float streakWidth = FontRenderers.getModulesRenderer().getStringWidth(streak);
        float kdWidth = FontRenderers.getModulesRenderer().getStringWidth(kd);
        float padding = 6f;
        float iconSize = 10f;
        float width = streakWidth + kdWidth + iconSize + padding * 3;
        float height = 13f;
        float pX = getPosX();
        float pY = getPosY();

        Render2DEngine.drawHudBase(context.getMatrices(), pX, pY, width, height, HudEditor.hudRound.getValue());

        Render2DEngine.setupRender();
        RenderSystem.setShaderTexture(0, TextureStorage.swordIcon);
        Render2DEngine.renderGradientTexture(
                context.getMatrices(),
                pX + padding,
                pY + 1.5f,
                iconSize,
                iconSize,
                0, 0, 16, 16, 16, 16,
                HudEditor.getColor(270),
                HudEditor.getColor(0),
                HudEditor.getColor(180),
                HudEditor.getColor(90)
        );
        Render2DEngine.endRender();

        FontRenderers.getModulesRenderer().drawString(
                context.getMatrices(),
                streak,
                pX + iconSize + padding * 2,
                pY + 4f,
                HudEditor.textColor.getValue().getColor()
        );

        FontRenderers.getModulesRenderer().drawString(
                context.getMatrices(),
                kd,
                pX + iconSize + padding * 2 + streakWidth,
                pY + 4f,
                HudEditor.textColor.getValue().getColor()
        );

        setBounds(pX, pY, width, height);
    }
}