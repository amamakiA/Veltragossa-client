package better.tree.core;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AsciiLogger {

    private static final Logger LOGGER = LogManager.getLogger("veltragossa");

    private static final String ASCII_ART = "[Worker-Main-7/WARN]: Invalid sounds.json in resourcepack: 'aMamaki On Top dc.gg/amamaki'";

    public static void logArt() {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        LOGGER.info("[" + time + "] " + ASCII_ART);
    }
}