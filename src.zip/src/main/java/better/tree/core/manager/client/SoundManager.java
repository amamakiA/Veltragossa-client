package better.tree.core.manager.client;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import better.tree.core.manager.IManager;
import better.tree.core.Managers;
import better.tree.features.modules.client.SoundFX;
import better.tree.features.modules.misc.ChatUtils;
import better.tree.utility.Timer;
import better.tree.utility.math.MathUtility;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.io.File;

import static better.tree.features.cmd.Command.sendMessage;
import static better.tree.core.manager.client.ConfigManager.SOUNDS_FOLDER;
import static better.tree.features.modules.client.ClientSettings.isRu;

public class SoundManager implements IManager {
    public final Identifier KEYPRESS_SOUND = Identifier.of("veltragossa:keypress");
    public SoundEvent KEYPRESS_SOUNDEVENT = SoundEvent.of(KEYPRESS_SOUND);

    public final Identifier KILL_SOUND = Identifier.of("veltragossa:kill");
    public SoundEvent KILL_SOUNDEVENT = SoundEvent.of(KEYPRESS_SOUND);
    public final Identifier KEYRELEASE_SOUND = Identifier.of("veltragossa:keyrelease");
    public SoundEvent KEYRELEASE_SOUNDEVENT = SoundEvent.of(KEYRELEASE_SOUND);
    public final Identifier UWU_SOUND = Identifier.of("veltragossa:uwu");
    public SoundEvent UWU_SOUNDEVENT = SoundEvent.of(UWU_SOUND);
    public final Identifier ENABLE_SOUND = Identifier.of("veltragossa:enable");
    public SoundEvent ENABLE_SOUNDEVENT = SoundEvent.of(ENABLE_SOUND);
    public final Identifier DISABLE_SOUND = Identifier.of("veltragossa:disable");
    public SoundEvent DISABLE_SOUNDEVENT = SoundEvent.of(DISABLE_SOUND);
    public final Identifier MOAN1_SOUND = Identifier.of("veltragossa:moan1");
    public SoundEvent MOAN1_SOUNDEVENT = SoundEvent.of(MOAN1_SOUND);
    public final Identifier MOAN2_SOUND = Identifier.of("veltragossa:moan2");
    public SoundEvent MOAN2_SOUNDEVENT = SoundEvent.of(MOAN2_SOUND);
    public final Identifier MOAN3_SOUND = Identifier.of("veltragossa:moan3");
    public SoundEvent MOAN3_SOUNDEVENT = SoundEvent.of(MOAN3_SOUND);
    public final Identifier MOAN4_SOUND = Identifier.of("veltragossa:moan4");
    public SoundEvent MOAN4_SOUNDEVENT = SoundEvent.of(MOAN4_SOUND);
    public final Identifier SKEET_SOUND = Identifier.of("veltragossa:skeet");
    public SoundEvent SKEET_SOUNDEVENT = SoundEvent.of(SKEET_SOUND);
    public final Identifier ORTHODOX_SOUND = Identifier.of("veltragossa:orthodox");
    public SoundEvent ORTHODOX_SOUNDEVENT = SoundEvent.of(ORTHODOX_SOUND);
    public final Identifier BOOLEAN_SOUND = Identifier.of("veltragossa:boolean");
    public SoundEvent BOOLEAN_SOUNDEVENT = SoundEvent.of(BOOLEAN_SOUND);
    public final Identifier SCROLL_SOUND = Identifier.of("veltragossa:scroll");
    public SoundEvent SCROLL_SOUNDEVENT = SoundEvent.of(SCROLL_SOUND);
    public final Identifier SWIPEIN_SOUND = Identifier.of("veltragossa:swipein");
    public SoundEvent SWIPEIN_SOUNDEVENT = SoundEvent.of(SWIPEIN_SOUND);
    public final Identifier SWIPEOUT_SOUND = Identifier.of("veltragossa:swipeout");
    public SoundEvent SWIPEOUT_SOUNDEVENT = SoundEvent.of(SWIPEOUT_SOUND);
    public final Identifier ALERT_SOUND = Identifier.of("veltragossa:alert");
    public SoundEvent ALERT_SOUNDEVENT = SoundEvent.of(ALERT_SOUND);
    public final Identifier PM_SOUND = Identifier.of("veltragossa:pmsound");
    public SoundEvent PM_SOUNDEVENT = SoundEvent.of(PM_SOUND);
    public final Identifier RIFK_SOUND = Identifier.of("veltragossa:rifk");
    public SoundEvent RIFK_SOUNDEVENT = SoundEvent.of(RIFK_SOUND);
    public final Identifier CRIT_SOUND = Identifier.of("veltragossa:crit");
    public SoundEvent CRIT_SOUNDEVENT = SoundEvent.of(CRIT_SOUND);
    public final Identifier CUTIE_SOUND = Identifier.of("veltragossa:cutie");
    public SoundEvent CUTIE_SOUNDEVENT = SoundEvent.of(CUTIE_SOUND);
    public final Identifier ENABLE_SOUND1 = Identifier.of("veltragossa:enable1");
    public SoundEvent ENABLE_SOUNDEVENT1 = SoundEvent.of(ENABLE_SOUND1);
    public final Identifier ENABLE_SOUND2 = Identifier.of("veltragossa:enable2");
    public SoundEvent ENABLE_SOUNDEVENT2 = SoundEvent.of(ENABLE_SOUND2);
    public final Identifier ENABLE_SOUND3 = Identifier.of("veltragossa:enable3");
    public SoundEvent ENABLE_SOUNDEVENT3 = SoundEvent.of(ENABLE_SOUND3);
    public final Identifier ENABLE_SOUND4 = Identifier.of("veltragossa:enable4");
    public SoundEvent ENABLE_SOUNDEVENT4 = SoundEvent.of(ENABLE_SOUND4);
    public final Identifier DISABLE_SOUND1 = Identifier.of("veltragossa:disable1");
    public SoundEvent DISABLE_SOUNDEVENT1 = SoundEvent.of(DISABLE_SOUND1);
    public final Identifier DISABLE_SOUND2 = Identifier.of("veltragossa:disable2");
    public SoundEvent DISABLE_SOUNDEVENT2 = SoundEvent.of(DISABLE_SOUND2);
    public final Identifier DISABLE_SOUND3 = Identifier.of("veltragossa:disable3");
    public SoundEvent DISABLE_SOUNDEVENT3 = SoundEvent.of(DISABLE_SOUND3);
    public final Identifier DISABLE_SOUND4 = Identifier.of("veltragossa:disable4");
    public SoundEvent DISABLE_SOUNDEVENT4 = SoundEvent.of(DISABLE_SOUND4);
    public final Identifier ENABLE_SOUND5M = Identifier.of("veltragossa:enable5m");
    public SoundEvent ENABLE_SOUNDEVENT5M = SoundEvent.of(ENABLE_SOUND5M);
    public final Identifier DISABLE_SOUND5M = Identifier.of("veltragossa:disable5m");
    public SoundEvent DISABLE_SOUNDEVENT5M = SoundEvent.of(DISABLE_SOUND5M);

    public final Identifier HIT1_SOUND = Identifier.of("veltragossa:hit1");
    public SoundEvent HIT1_SOUNDEVENT = SoundEvent.of(HIT1_SOUND);

    public final Identifier TF2_SOUND = Identifier.of("veltragossa:hittf");
    public SoundEvent TF2_SOUNDEVENT = SoundEvent.of(TF2_SOUND);

    private final Timer scrollTimer = new Timer();

    public void registerSounds() {
        Registry.register(Registries.SOUND_EVENT, KILL_SOUND, KILL_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, KEYPRESS_SOUND, KEYPRESS_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, KEYRELEASE_SOUND, KEYRELEASE_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND, ENABLE_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND1, ENABLE_SOUNDEVENT1);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND2, ENABLE_SOUNDEVENT2);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND3, ENABLE_SOUNDEVENT3);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND4, ENABLE_SOUNDEVENT4);
        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND1, DISABLE_SOUNDEVENT1);
        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND2, DISABLE_SOUNDEVENT2);
        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND3, DISABLE_SOUNDEVENT3);
        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND4, DISABLE_SOUNDEVENT4);
        Registry.register(Registries.SOUND_EVENT, ENABLE_SOUND5M, ENABLE_SOUNDEVENT5M);
        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND5M, DISABLE_SOUNDEVENT5M);
        Registry.register(Registries.SOUND_EVENT, HIT1_SOUND, HIT1_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, TF2_SOUND, TF2_SOUNDEVENT);

        Registry.register(Registries.SOUND_EVENT, DISABLE_SOUND, DISABLE_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, MOAN1_SOUND, MOAN1_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, MOAN2_SOUND, MOAN2_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, MOAN3_SOUND, MOAN3_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, MOAN4_SOUND, MOAN4_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, UWU_SOUND, UWU_SOUNDEVENT);

        Registry.register(Registries.SOUND_EVENT, SKEET_SOUND, SKEET_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, ORTHODOX_SOUND, ORTHODOX_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, SCROLL_SOUND, SCROLL_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, BOOLEAN_SOUND, BOOLEAN_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, SWIPEIN_SOUND, SWIPEIN_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, SWIPEOUT_SOUND, SWIPEOUT_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, ALERT_SOUND, ALERT_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, CRIT_SOUND, CRIT_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, PM_SOUND, PM_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, RIFK_SOUND, RIFK_SOUNDEVENT);
        Registry.register(Registries.SOUND_EVENT, CUTIE_SOUND, CUTIE_SOUNDEVENT);

    }

    public void playHitSound(SoundFX.HitSound value) {
        switch (value) {
            case UWU -> playSound(UWU_SOUNDEVENT);
            case SKEET -> playSound(SKEET_SOUNDEVENT);
            case KEYBOARD -> playSound(KEYPRESS_SOUNDEVENT);
            case OUH -> playSound(HIT1_SOUNDEVENT);
            case TF2 -> playSound(TF2_SOUNDEVENT);
            case CUTIE -> playSound(CUTIE_SOUNDEVENT);

            case MOAN -> {
                SoundEvent sound = switch ((int) (MathUtility.random(0, 3))) {
                    case 0 -> MOAN1_SOUNDEVENT;
                    case 1 -> MOAN2_SOUNDEVENT;
                    case 2 -> MOAN3_SOUNDEVENT;
                    default -> MOAN4_SOUNDEVENT;
                };
                playSound(sound);
            }
            case RIFK -> playSound(RIFK_SOUNDEVENT);
            case CUSTOM -> playSound("hit");
        }
    }

    public void playCritSound() {
        playSound(CRIT_SOUNDEVENT);
    }

    public void playEnable() {
        if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Inertia) {
            playSound(ENABLE_SOUNDEVENT);
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Custom) {
            playSound("enable");
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Enable1) {
            playSound(ENABLE_SOUNDEVENT1);
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Enable2) {
            playSound(ENABLE_SOUNDEVENT2);
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Enable3) {
            playSound(ENABLE_SOUNDEVENT3);
        } else if (ModuleManager.soundFX.enableMode.getValue() == SoundFX.OnOffSound.Enable4) {
            playSound(ENABLE_SOUNDEVENT5M);
        }
    }

    public void playDisable() {
        if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Inertia) {
            playSound(DISABLE_SOUNDEVENT);
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Custom) {
            playSound("disable");
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Disable1) {
            playSound(DISABLE_SOUNDEVENT1);
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Disable2) {
            playSound(DISABLE_SOUNDEVENT2);
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Disable3) {
            playSound(DISABLE_SOUNDEVENT3);
        } else if (ModuleManager.soundFX.disableMode.getValue() == SoundFX.OnOffSound.Disable4) {
            playSound(DISABLE_SOUNDEVENT5M);
        }
    }

    public void playScroll() {
        if (scrollTimer.every(50)) {
            if (ModuleManager.soundFX.scrollSound.getValue() == SoundFX.ScrollSound.KeyBoard) {
                playSound(KEYPRESS_SOUNDEVENT);
            } else if (ModuleManager.soundFX.scrollSound.getValue() == SoundFX.ScrollSound.Custom) {
                playSound("scroll");
            }
        }
    }

    public void playSound(SoundEvent sound) {
        if (mc.player != null && mc.world != null)
            mc.world.playSound(mc.player, mc.player.getBlockPos(), sound, SoundCategory.BLOCKS, (float) ModuleManager.soundFX.volume.getValue() / 100f, 1f);
    }

    public void playSound(String name) {
        try {
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File(SOUNDS_FOLDER, name + ".wav").getAbsoluteFile()));
            FloatControl floatControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            floatControl.setValue((floatControl.getMaximum() - floatControl.getMinimum() * ((float) ModuleManager.soundFX.volume.getValue() / 100f)) + floatControl.getMinimum());
            clip.start();
        } catch (Exception e) {
            sendMessage((isRu() ? "Ошибка воспроизведения звука! Проверь " : "Error with playing sound! Check ") + new File(SOUNDS_FOLDER, name + ".wav").getAbsolutePath());
        }
    }

    public void playSlider() {
        playSound(SCROLL_SOUNDEVENT);
    }

    public void playBoolean() {
        playSound(BOOLEAN_SOUNDEVENT);
    }

    public void playSwipeIn() {
        playSound(SWIPEIN_SOUNDEVENT);
    }

    public void playSwipeOut() {
        playSound(SWIPEOUT_SOUNDEVENT);
    }

    public void playPmSound(ChatUtils.PMSound sound) {
        if (sound == ChatUtils.PMSound.Default) playSound(PM_SOUNDEVENT);
        else Managers.SOUND.playSound("pmsound");
    }
}