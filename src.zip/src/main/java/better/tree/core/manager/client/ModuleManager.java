package better.tree.core.manager.client;

import better.tree.features.hud.impl.*;
import better.tree.features.modules.client.*;
import better.tree.features.modules.combat.*;
import better.tree.features.modules.misc.*;
import better.tree.features.modules.movement.*;
import better.tree.features.modules.movement.Timer;
import better.tree.features.modules.player.*;
import better.tree.features.modules.render.*;
import better.tree.features.modules.render.Particles;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import better.tree.veltragossa;
import better.tree.core.manager.IManager;
import better.tree.gui.clickui.ClickGUI;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.Module;


import java.lang.reflect.Field;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class ModuleManager implements IManager {

    public ArrayList<Module> modules = new ArrayList<>();
    public List<Module> sortedModules = new ArrayList<>();
    public List<Integer> activeMouseKeys = new ArrayList<>();

    public  static SkinChanger SkinChanger = new SkinChanger();
    public static AntiPacketException antiPacketException = new AntiPacketException();
    public static LevitationControl levitationControl = new LevitationControl();

    public static InventoryCleaner inventoryCleaner = new InventoryCleaner();

    public static AntiCheatDetector antiCheatDetector = new AntiCheatDetector();
    public static NoWaterCollision noWaterCollision = new NoWaterCollision();
    public static BaritoneSettings baritoneSettings = new BaritoneSettings();
    public static PortalInventory portalInventory = new PortalInventory();
    public static TotemPopCounter totemPopCounter = new TotemPopCounter();
    public static HotbarReplenish hotbarReplenish = new HotbarReplenish();
    public static DurabilityAlert durabilityAlert = new DurabilityAlert();
    public static AutoCrystalBase autoCrystalBase = new AutoCrystalBase();
    public static CrosshairArrows crosshairArrows = new CrosshairArrows();
    public static PearlBlockThrow pearlBlockThrow = new PearlBlockThrow();
    public static AutoCrystalInfo autoCrystalInfo = new AutoCrystalInfo();
    public static ChatTranslator chatTranslator = new ChatTranslator();
    public static PacketCanceler packetCanceler = new PacketCanceler();
    public static ClientSettings clientSettings = new ClientSettings();
    public static TimerIndicator timerIndicator = new TimerIndicator();
    public static ThunderHackGui ThunderHackGui = new ThunderHackGui();
    public static NoServerRotate noServerRotate = new NoServerRotate();
    public static BreakHighLight breakHighLight = new BreakHighLight();
    public static BlockHighLight blockHighLight = new BlockHighLight();
    public static AntiBadEffects antiBadEffects = new AntiBadEffects();
    public static MouseElytraFix mouseElytraFix = new MouseElytraFix();
    public static TotemAnimation totemAnimation = new TotemAnimation();
    public static PortalGodMode portalGodMode = new PortalGodMode();
    public static OptifineCapes optifineCapes = new OptifineCapes();
    public static Notifications notifications = new Notifications();
    public static AntiAim antiAim = new AntiAim();
    public static NoEntityTrace noEntityTrace = new NoEntityTrace();
    public static MessageAppend messageAppend = new MessageAppend();
    public static AirStuck airStuck = new AirStuck();

    public static ElytraReplace elytraReplace = new ElytraReplace();
    public static ChorusExploit chorusExploit = new ChorusExploit();
    public static MoreKnockback moreKnockback = new MoreKnockback();

    public static final MaceSwap maceSwap = new MaceSwap();
    public static final ChatModerator ChatModerator = new ChatModerator();

    public static AntiLegitMiss antiLegitMiss = new AntiLegitMiss();

    public static TridentBoost tridentBoost = new TridentBoost();

    public static PearlTracker PearlTracker = new PearlTracker();
    public static AutoHitBlock AutoHitBlock = new AutoHitBlock();
    public static TridentFly tridentFly = new TridentFly();
    public static Trajectories trajectories = new Trajectories();
    public static TargetStrafe targetStrafe = new TargetStrafe();
    public static RadarRewrite radarRewrite = new RadarRewrite();
    public static PVPResources pvpResources = new PVPResources();
    public static NoServerSlot noServerSlot = new NoServerSlot();
    public static NoCameraClip noCameraClip = new NoCameraClip();
    public static ItemScroller itemScroller = new ItemScroller();
    public static HitParticles hitParticles = new HitParticles();
    public static ElytraRecast elytraRecast = new ElytraRecast();
    public static EbatteSratte ebatteSratte = new EbatteSratte();
    public static ChestStealer chestStealer = new ChestStealer();
    public static AutoTpAccept autoTpAccept = new AutoTpAccept();
    public static AntiServerRP antiServerRP = new AntiServerRP();
    public static TotemCounter totemCounter = new TotemCounter();
    public static PerfectDelay perfectDelay = new PerfectDelay();
    public static ServerHelper serverHelper = new ServerHelper();
    public static TridentReady TridentReady = new TridentReady();
    public static KillMsg killMsg = new KillMsg();
    public static ChestCounter chestCounter = new ChestCounter();

    public static StashLogger stashLogger = new StashLogger();
    public static MentionLogger MentionLogger = new MentionLogger();
    public static FastLatency fastLatency = new FastLatency();
    public static PearlChaser pearlChaser = new PearlChaser();
    public static PingSpoofTest pingSpoofTest = new PingSpoofTest();
    public static WorldTweaks worldTweaks = new WorldTweaks();
    public static VisualRange visualRange = new VisualRange();
    public static Speedometer speedometer = new Speedometer();
    public static ReverseStep reverseStep = new ReverseStep();
    public static NoJumpDelay noJumpDelay = new NoJumpDelay();
    public static NameProtect nameProtect = new NameProtect();
    public static MiddleClick middleClick = new MiddleClick();
    public static LogoutSpots logoutSpots = new LogoutSpots();

    public static LagNotifier lagNotifier = new LagNotifier();
    public static BreadCrumbs breadCrumbs = new BreadCrumbs();
    public static AutoRespawn autoRespawn = new AutoRespawn();
    public static AutoCrystal autoCrystal = new AutoCrystal();

    public static EntitySpeed entitySpeed = new EntitySpeed();
    public static AspectRatio aspectRatio = new AspectRatio();
    public static ClientSpoof clientSpoof = new ClientSpoof();
    public  static BedwarsHelper BedwarsHelper = new BedwarsHelper();
    public static LegitHelper legitHelper = new LegitHelper();
    public static AutoAnchor autoAnchor = new AutoAnchor();

    public static WaterSpeed waterSpeed = new WaterSpeed();
    public static TriggerBot triggerBot = new TriggerBot();
    public static TPSCounter tpsCounter = new TPSCounter();
    public static StorageEsp storageEsp = new StorageEsp();
    public static StaffBoard staffBoard = new StaffBoard();

    public static SoundESP SoundEsp = new SoundESP();
    public static NoInteract noInteract = new NoInteract();
    public static ModuleList moduleList = new ModuleList();
    public static KillEffect killEffect = new KillEffect();
    public static JumpCircle jumpCircle = new JumpCircle();
    public static TargetHalo TargetHalo = new TargetHalo();
    public static HoleAnchor holeAnchor = new HoleAnchor();
    public static Fullbright fullbright = new Fullbright();
    public static FpsCounter fpsCounter = new FpsCounter();
    public static FakePlayer fakePlayer = new FakePlayer();
    public static ElytraSwap elytraSwap = new ElytraSwap();
    public static ElytraPlus elytraPlus = new ElytraPlus();
    public static FastTrident fastTrident = new FastTrident();
    public static AutoSprint autoSprint = new AutoSprint();
    public static AutoGApple autoGApple = new AutoGApple();
    public static AntiHunger antiHunger = new AntiHunger();

    public static ElytraSpeed elytraSpeed = new ElytraSpeed();
    public static Animations animations = new Animations();
    public static DamageTint damageTint = new DamageTint();
    public static AntiAttack antiAttack = new AntiAttack();
    public static GapplesHud gapplesHud = new GapplesHud();
    public static webhud webHud = new webhud();
    public static HitBubbles hitBubbles = new HitBubbles();
    public static AutoTrader autoTrader = new AutoTrader();
    public static KillStats killStats = new KillStats();
    public static AutoAnvil autoAnvil = new AutoAnvil();
    public static InventoryHud InventoryHud = new InventoryHud();

    public static Particles particles = new Particles();
    public static ToolSaver toolSaver = new ToolSaver();
    public static WayPoints wayPoints = new WayPoints();
    public static WaterMark waterMark = new WaterMark();
    public static ViewModel viewModel = new ViewModel();
    public FakeLag FakeLag = new FakeLag();
    public static TunnelEsp tunnelEsp = new TunnelEsp();

    public static TargetHud targetHud = new TargetHud();
    public static SpeedMine speedMine = new SpeedMine();
    public static PotionHud potionHud = new PotionHud();
    public static PearlBait pearlBait = new PearlBait();
    public static PacketFly packetFly = new PacketFly();
    public static MultiTask multitask = new MultiTask();
    public static LegacyHud legacyHud = new LegacyHud();

    public static HudEditor hudEditor = new HudEditor();
    public static Crosshair crosshair = new Crosshair();
    public static Criticals criticals = new Criticals();

    public static AutoTotem autoTotem = new AutoTotem();
    public static AutoLeave autoLeave = new AutoLeave();
    public static NarratorOffs NarratorOffs = new NarratorOffs();

    public static AutoArmor autoArmor = new AutoArmor();
    public static AutoGG AutoGG = new AutoGG();
    public static Cooldowns cooldowns = new Cooldowns();
    public static TapeMouse tapeMouse = new TapeMouse();
    public static Rotations rotations = new Rotations();
    public static MemoryHud memoryHud = new MemoryHud();
    public static Companion companion = new Companion();
    public static AntiCrash antiCrash = new AntiCrash();

    public static ViewLock viewLock = new ViewLock();
    public static Velocity velocity = new Velocity();

    public static Tooltips tooltips = new Tooltips();
    public static Surround surround = new Surround();
    public static Scaffold scaffold = new Scaffold();
    public static PopChams popChams = new PopChams();
    public static NoRender noRender = new NoRender();
    public static NameTags nameTags = new NameTags();
    public static LongJump longJump = new LongJump();
    public static KeyBinds keyBinds = new KeyBinds();
    public static HoleSnap holeSnap = new HoleSnap();
    public static HoleFill holeFill = new HoleFill();
    public static ExtraTab extraTab = new ExtraTab();
    public static ClickGui clickGui = new ClickGui();

    public static AutoTrap autoTrap = new AutoTrap();
    public static AutoTool autoTool = new AutoTool();

    public static AutoSoup autoSoup = new AutoSoup();
    public static AutoBuff autoBuff = new AutoBuff();

    public static AutoAuth autoAuth = new AutoAuth();
    public static ArmorHud armorHud = new ArmorHud();
    public static AirPlace airPlace = new AirPlace();
    public static AutoChatCMD AutoChatCMD = new AutoChatCMD();

    public static SelfTrap selfTrap = new SelfTrap();
    public static ChatSpammer chatspammer = new ChatSpammer();
    public static AntiVoid antiVoid = new AntiVoid();
    public static KillFeed killFeed = new KillFeed();
    public static AutoWalk autoWalk = new AutoWalk();
    public static AutoReply AutoReply = new AutoReply();
    public static WindHop WindHop = new WindHop();
    public static BlockESP blockESP = new BlockESP();
    public static SafeWalk safeWalk = new SafeWalk();
    public static Windows windows = new Windows();
    public static Breaker breaker = new Breaker();
    public static AutoEat autoEat = new AutoEat();
    public static AntiAFK antiAFK = new AntiAFK();
    public static SoundFX soundFX = new SoundFX();
    public static AutoBed autoBed = new AutoBed();
    public static ResetCfg resetCfg = new ResetCfg();


    public static Tracker tracker = new Tracker();

    public static TpsSync tpsSync = new TpsSync();
    
    public static Shaders shaders = new Shaders();
    public static PingHud pingHud = new PingHud();
    public static ItemESP itemESP = new ItemESP();
    public static HoleESP holeESP = new HoleESP();
    public static GuiMove guiMove = new GuiMove();
    public static FreeCam freeCam = new FreeCam();
    public static FastUse fastUse = new FastUse();

    public static BowSpam bowSpam = new BowSpam();

    public static BoatFly boatFly = new BoatFly();
    public static Blocker blocker = new Blocker();

    public static AutoWeb autoWeb = new AutoWeb();

    public static AntiWeb antiWeb = new AntiWeb();
    public static AutoMLG AutoMLG = new AutoMLG();

    public static TargetSpeed targetSpeed = new TargetSpeed();
    public static AntiBot antiBot = new AntiBot();

    public static Tracers tracers = new Tracers();
    public static FireworkSpam fireworkSpam = new FireworkSpam();
    public static Parkour parkour = new Parkour();

    public static BowPop bowPop = new BowPop();

    public static XCarry xCarry = new XCarry();
    public static Trails trails = new Trails();
    public static Strafe strafe = new Strafe();
    public static Spider spider = new Spider();
    public static NoSlow noSlow = new NoSlow();
    public static NoFall noFall = new NoFall();
    public static Hotbar hotbar = new Hotbar();
    public static HitBox hitBox = new HitBox();
    public static Flight flight = new Flight();
    public static Coords coords = new Coords();
    public static Burrow burrow = new Burrow();

    public static AimBot aimBot = new AimBot();
    public static AntiAutoWeb AntiAutoWeb = new AntiAutoWeb();
    public  static StealWater StealWater = new StealWater();

    public static BedDestroyer BedDestroyer = new BedDestroyer();
    public static AntiTrap antiTrap = new AntiTrap();
    public static NoPush noPush = new NoPush();
    public  static  BackUpCfg backUpCfg = new BackUpCfg();
    public static UnHook unHook = new UnHook();
    public static Avoid avoid = new Avoid();
    public static BackTrack BackTrack = new BackTrack();

    public static Timer timer = new Timer();
    public static Regen regen = new Regen();
    public static Speed speed = new Speed();
    public static Reach reach = new Reach();

    public static Radar radar = new Radar();
    public static Nuker nuker = new Nuker();
    public static Media media = new Media();
    public static Cape cape = new Cape();
    public static Ghost ghost = new Ghost();
    public static Chams chams = new Chams();
    public static ChinaHat chinaHat = new ChinaHat();
    public static Blink blink = new Blink();
    public static Phase phase = new Phase();
    public static NoBob noBob = new NoBob();
    public static Jesus jesus = new Jesus();
    public static XRay xray = new XRay();
    public static Aura aura = new Aura();

    public static FOV fov = new FOV();
    public static AutoDripStone autoDripStone = new AutoDripStone();

    public static ESP esp = new ESP();
    public static RPC rpc = new RPC();
public static StaticHitboxes StaticHitboxes = new StaticHitboxes();
    public ModuleManager() {
        for (Field field : getClass().getDeclaredFields()) {
            if (Module.class.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                try {
                    modules.add((Module) field.get(this));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public Module get(String name) {
        for (Module module : modules) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public ArrayList<Module> getEnabledModules() {
        ArrayList<Module> enabledModules = new ArrayList<>();
        for (Module module : modules) {
            if (!module.isEnabled()) continue;
            enabledModules.add(module);
        }
        return enabledModules;
    }

    public ArrayList<Module> getModulesByCategory(Module.Category category) {
        ArrayList<Module> modulesCategory = new ArrayList<>();
        modules.forEach(module -> {
            if (module.getCategory() == category) {
                modulesCategory.add(module);
            }
        });
        return modulesCategory;
    }

    public List<Module.Category> getCategories() {
        return new ArrayList<>(Module.Category.values());
    }

    public void onLoad(String category) {
        try {
            veltragossa.EVENT_BUS.unsubscribe(unHook);
        } catch (Exception ignored) {
        }
        unHook.setEnabled(false);

        modules.sort(Comparator.comparing(Module::getName));

        modules.forEach(m -> {
            if (m.isEnabled() && (m.getCategory().getName().equalsIgnoreCase(category) || category.equals("none")))
                veltragossa.EVENT_BUS.subscribe(m);
        });

        if (ConfigManager.firstLaunch) {
            ModuleManager.notifications.enable();
            rpc.enable();
            soundFX.enable();
        }
    }

    public void onUpdate() {
        if (Module.fullNullCheck()) return;
        modules.stream().filter(Module::isEnabled).forEach(Module::onUpdate);
    }

    public void onRender2D(DrawContext context) {
        if (mc.getDebugHud().shouldShowDebugHud() || mc.options.hudHidden) return;
        HudElement.anyHovered = false;
        modules.stream().filter(Module::isEnabled).forEach(module -> module.onRender2D(context));
        if (!HudElement.anyHovered && !ClickGUI.anyHovered)
            if (GLFW.glfwGetPlatform() != GLFW.GLFW_PLATFORM_WAYLAND) {
                GLFW.glfwSetCursor(mc.getWindow().getHandle(), GLFW.glfwCreateStandardCursor(GLFW.GLFW_ARROW_CURSOR));
            }
        veltragossa.core.onRender2D(context);
    }

    public void onRender3D(MatrixStack stack) {
        modules.stream().filter(Module::isEnabled).forEach(module -> module.onRender3D(stack));
    }

    public void sortModules() {
        sortedModules = getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> FontRenderers.getModulesRenderer().getStringWidth(module.getFullArrayString()) * -1)).collect(Collectors.toList());
    }

    public void onLogout() {
        modules.forEach(Module::onLogout);
    }

    public void onLogin() {
        modules.forEach(Module::onLogin);
    }

    public void onUnload(String category) {
        modules.forEach(module -> {
            if (module.isEnabled() && (module.getCategory().getName().equalsIgnoreCase(category) || category.equals("none"))) {
                veltragossa.EVENT_BUS.unsubscribe(module);
                module.setEnabled(false);
            }
        });
        modules.forEach(Module::onUnload);
    }

    public void onKeyPressed(int eventKey) {
        if (eventKey == -1 || eventKey == 0 || mc.currentScreen instanceof ClickGUI) {
            return;
        }
        modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey)
                module.toggle();
        });
    }

    public void onKeyReleased(int eventKey) {
        if (eventKey == -1 || eventKey == 0 || mc.currentScreen instanceof ClickGUI)
            return;

        modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey && module.getBind().isHold())
                module.disable();
        });
    }

    public void onMoseKeyPressed(int eventKey) {
        if (eventKey == -1 || mc.currentScreen instanceof ClickGUI) {
            return;
        }

        modules.forEach(module -> {
            if (Objects.equals(module.getBind().getBind(), "M" + eventKey)) {
                module.toggle();
            }
        });
    }

    public void onMoseKeyReleased(int eventKey) {
        if (eventKey == -1 || mc.currentScreen instanceof ClickGUI)
            return;

        activeMouseKeys.add(eventKey);

        modules.forEach(module -> {
            if (Objects.equals(module.getBind().getBind(), "M" + eventKey) && module.getBind().isHold())
                module.disable();
        });
    }

    public ArrayList<Module> getModulesSearch(String string) {
        ArrayList<Module> modulesCategory = new ArrayList<>();
        modules.forEach(module -> {
            if (module.getName().toLowerCase().contains(string.toLowerCase()))
                modulesCategory.add(module);
        });
        return modulesCategory;
    }

    public void registerModule(Module module) {
        if (module == null) return;

        this.modules.add(module);

        if (module.isEnabled())
            veltragossa.EVENT_BUS.subscribe(module);
    }

    public void registerHudElement(HudElement hudElement) {
        if (hudElement == null) return;

        this.modules.add(hudElement);
    }
}

