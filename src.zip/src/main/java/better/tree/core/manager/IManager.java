package better.tree.core.manager;

import net.minecraft.client.MinecraftClient;

public interface IManager {
    MinecraftClient mc = MinecraftClient.getInstance();
}