package better.tree.core.manager.client;

import com.google.common.collect.Lists;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Formatting;
import better.tree.core.manager.IManager;
import better.tree.features.cmd.Command;
import better.tree.gui.notification.Notification;
import better.tree.features.modules.client.Notifications;
import org.apache.commons.lang3.SystemUtils;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static better.tree.veltragossa.LOGGER;

public class NotificationManager implements IManager {
    private final List<Notification> notifications = new ArrayList<>();
    private TrayIcon trayIcon;

    public void publicity(String title, String content, int second, Notification.Type type) {
                if (ModuleManager.notifications.getMode() == Notifications.Mode.Text)
            Command.sendMessage(Formatting.GRAY + "[" + Formatting.DARK_PURPLE + title + Formatting.GRAY + "] " + type.getColor() + content);

        if (!mc.isWindowFocused())
            nativeNotification(content, title);

        notifications.add(new Notification(title, content, type, second * 1000));
    }

    public void onRender2D(DrawContext context) {
        if (!ModuleManager.notifications.isEnabled()) return;

        float startY = isDefault() ? mc.getWindow().getScaledHeight() - 36f : mc.getWindow().getScaledHeight() / 2f + 25;

        if (notifications.size() > 8)
            notifications.removeFirst();

        notifications.removeIf(Notification::shouldDelete);

        for (Notification n : Lists.newArrayList(notifications)) {
            startY = (float) (startY - n.getHeight() - 3f);
            n.renderShaders(context.getMatrices(), startY + (isDefault() ? 0 : notifications.size() * 16));
            n.render(context.getMatrices(), startY + (isDefault() ? 0 : notifications.size() * 16));
        }
    }

    public void onUpdate() {
        if (!ModuleManager.notifications.isEnabled()) return;
        notifications.forEach(Notification::onUpdate);
    }

    public static boolean isDefault() {
        return ModuleManager.notifications.getMode() == Notifications.Mode.Default;
    }

    private void nativeNotification(String message, String title) {
        if (SystemUtils.IS_OS_WINDOWS) {
            windows(message, title);
        } else if (SystemUtils.IS_OS_LINUX) {
            linux(message);
        } else if (SystemUtils.IS_OS_MAC) {
            mac(message);
        } else {
            LOGGER.error("Unsupported OS: {}", SystemUtils.OS_NAME);
        }
    }

    private void windows(final String message, final String title) {
        if (SystemTray.isSupported()) {
            try {
                if (trayIcon == null) {
                    final SystemTray tray = SystemTray.getSystemTray();
                    final Image image = Toolkit.getDefaultToolkit().createImage("resources/icon.png");

                    trayIcon = new TrayIcon(image, "veltragossa");
                    trayIcon.setImageAutoSize(true);
                    trayIcon.setToolTip("veltragossa");
                    tray.add(trayIcon);
                }

                trayIcon.displayMessage(title, message, TrayIcon.MessageType.INFO);
            } catch (Exception e) {
                LOGGER.error(e.getMessage());
            }
        } else {
            LOGGER.error("SystemTray is not supported");
        }
    }

    private void mac(final String message) {
        final ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("osascript", "-e", "display notification \"" + message + "\" with title \"veltragossa\"");
        try {
            processBuilder.start();
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
    }

    private void linux(final String message) {
        final ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("notify-send", "-a", "veltragossa", message);

        try {
            processBuilder.start();
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
    }
}