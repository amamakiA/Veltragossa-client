package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Formatting;
import better.tree.core.Managers;
import better.tree.gui.font.FontRenderers;
import better.tree.gui.font.FontRenderer;
import better.tree.features.hud.HudElement;
import better.tree.features.modules.Module;
import better.tree.features.modules.client.HudEditor;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.animation.AnimationUtility;

import java.awt.*;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ModuleList extends HudElement {
    private final Setting<Mode> mode = new Setting<>("Mode", Mode.New);
    private final Setting<Integer> gste = new Setting<>("GS", 30, 1, 50);
    private final Setting<Boolean> hrender = new Setting<>("HideHud", true);
    private final Setting<Boolean> hhud = new Setting<>("HideRender", true);
    private final Setting<ColorSetting> color3 = new Setting<>("RectColor", new ColorSetting(-16777216));
    private final Setting<ColorSetting> color4 = new Setting<>("SideRectColor", new ColorSetting(-16777216));
    private final Setting<Float> animationSpeed = new Setting<>("AnimationSpeed", 10f, 1f, 20f, v -> mode.getValue() == Mode.New);

    private final Map<Module, Float> moduleY = new ConcurrentHashMap<>();

    public ModuleList() {
        super("ArrayList", 50, 30);
    }

    public void onRender2D(DrawContext context) {
        super.onRender2D(context);

        int stringWidth;
        boolean reverse = getPosX() > (mc.getWindow().getScaledWidth() / 2f);
        int offset = 0;
        float maxWidth = 0;
        float reversedX = getPosX();

        List<Module> list;

        try {
            list = Managers.MODULE.getEnabledModules().stream().sorted(Comparator.comparing(module -> getFontRenderer().getStringWidth(module.getFullArrayString()) * -1)).toList();
        } catch (IllegalArgumentException ex) {
            return;
        }

        if (mode.getValue() == Mode.New) {
            for (Module module : list) {
                if (!shouldRender(module)) {
                    moduleY.remove(module);
                    continue;
                }
                if (!moduleY.containsKey(module)) {
                    moduleY.put(module, getPosY() + offset);
                }
            }

            offset = 0;
            for (Module module : list) {
                if (!shouldRender(module)) continue;

                float currentY = moduleY.get(module);
                float targetY = getPosY() + offset;
                moduleY.put(module, AnimationUtility.fast(currentY, targetY, animationSpeed.getValue()));

                stringWidth = (int) (getFontRenderer().getStringWidth(module.getFullArrayString()) + 3);
                if (stringWidth > maxWidth) {
                    maxWidth = stringWidth;
                }
                offset += 10;
            }

            offset = 0;
            for (Module module : list) {
                if (!shouldRender(module)) continue;
                Color color = HudEditor.getColor(offset);
                stringWidth = (int) (getFontRenderer().getStringWidth(module.getFullArrayString()) + 3);
                float y = moduleY.get(module);

                Render2DEngine.drawRect(context.getMatrices(), reverse ? reversedX - stringWidth : getPosX(), y, stringWidth, 10, new Color(0, 0, 0, 120));
                Render2DEngine.drawRect(context.getMatrices(), reverse ? reversedX : getPosX() + stringWidth, y, 1, 10, color);
                getFontRenderer().drawString(context.getMatrices(), module.getFullArrayString(), (reverse ? reversedX - stringWidth : getPosX()) + 2, y + 2, -1);
                offset += 10;
            }
            setBounds(getPosX(), getPosY(), (int) maxWidth * (reverse ? -1 : 1), offset);
            return;
        }

        for (Module module : list) {
            if (!shouldRender(module))
                continue;

            Color color1 = HudEditor.getColor(offset);

            stringWidth = (int) (getFontRenderer().getStringWidth(module.getDisplayName() + Formatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + Formatting.WHITE + module.getDisplayInfo() + Formatting.GRAY + "]") : "")) + 3);
                Render2DEngine.drawBlurredShadow(context.getMatrices(), reverse ? reversedX - stringWidth - 3 : getPosX(), getPosY() + offset - 1, stringWidth + 4, 9f, gste.getValue(), color1);

            if (stringWidth > maxWidth)
                maxWidth = stringWidth;

            offset += 9;
        }

        offset = 0;

        for (Module module : list) {
            if (!shouldRender(module))
                continue;

            stringWidth = (int) (getFontRenderer().getStringWidth(module.getDisplayName() + Formatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + Formatting.WHITE + module.getDisplayInfo() + Formatting.GRAY + "]") : "")) + 3);
            Color color1 = HudEditor.getColor(offset);

            if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {

                Render2DEngine.drawRoundedBlur(context.getMatrices(), reverse ? reversedX - stringWidth : getPosX(), getPosY() + offset, stringWidth + 1.0f, 9.0f, 2, HudEditor.blurColor.getValue().getColorObject());
            } else {
                Render2DEngine.drawRect(context.getMatrices(), reverse ? reversedX - stringWidth : getPosX(), getPosY() + offset, stringWidth + 1.0f, 9.0f, mode.getValue() == Mode.ColorRect ? color1 : color3.getValue().getColorObject());
                Render2DEngine.drawRect(context.getMatrices(), reverse ? reversedX + 1f : getPosX() - 2.0f, getPosY() + offset, 2.0f, 9f, mode.getValue() == Mode.ColorRect ? color4.getValue().getColorObject() : color1);
            }

            getFontRenderer().drawString(context.getMatrices(), module.getDisplayName() + Formatting.GRAY + (module.getDisplayInfo() != null ? " [" + Formatting.WHITE + module.getDisplayInfo() + Formatting.GRAY + "]" : ""), reverse ? reversedX - stringWidth + 2.0f : getPosX() + 3.0f, getPosY() + 3.0f + offset, mode.getValue() == Mode.ColorRect ? -1 : color1.getRGB());

            offset += 9;
        }
        setBounds(getPosX(), getPosY(),(int) maxWidth * (reverse ? -1 : 1), offset);
    }

    private FontRenderer getFontRenderer() {
        return switch (fontMode.getValue()) {
            case Modules -> FontRenderers.modules;
            case Settings -> FontRenderers.settings;
            case Categories -> FontRenderers.categories;
            case Monsterrat -> FontRenderers.monsterrat;
            case SfBold -> FontRenderers.sf_bold;
            case SfBoldMini -> FontRenderers.sf_bold_mini;
            case SfBoldMicro -> FontRenderers.sf_bold_micro;
            case SfMedium -> FontRenderers.sf_medium;
            case SfMediumMini -> FontRenderers.sf_medium_mini;
            case SfMediumModules -> FontRenderers.sf_medium_modules;
            case Minecraft -> FontRenderers.minecraft;
            case Profon -> FontRenderers.profont;
        };
    }

    private boolean shouldRender(Module m) {
        return m.isDrawn() && (!hrender.getValue() || m.getCategory() != Category.RENDER) && (!hhud.getValue() || m.getCategory() != Category.HUD);
    }

    private enum Mode {
        ColorText, ColorRect, New
    }

    private enum FontMode {
        Modules, Settings, Categories, Monsterrat, SfBold, SfBoldMini, SfBoldMicro, SfMedium, SfMediumMini, SfMediumModules, Minecraft, Profon
    }

    private final Setting<FontMode> fontMode = new Setting<>("Font", FontMode.Modules);
}
