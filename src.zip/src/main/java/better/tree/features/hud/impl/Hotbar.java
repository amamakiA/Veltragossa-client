package better.tree.features.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import better.tree.gui.font.FontRenderers;
import better.tree.features.hud.HudElement;
import better.tree.gui.windows.WindowsScreen;
import better.tree.features.modules.client.HudEditor;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;

public class Hotbar extends HudElement {
    private float selectItemX = 0f;

    public Hotbar() {
        super("Hotbar", 0, 0);
    }

    public static final Setting<Mode> lmode = new Setting<>("LeftHandMode", Mode.Merged);
    private final Setting<ColorSetting> selectedItemColor =
            new Setting<>("SelectedItemColor", new ColorSetting(new Color(0x4CFFFFFF, true)));

    public enum Mode {
        Merged, Separately
    }

    @Override
    public void onRender2D(DrawContext context) {
        if (mc.currentScreen instanceof WindowsScreen) return;

        PlayerEntity playerEntity = mc.player;
        if (playerEntity != null) {
            MatrixStack matrices = context.getMatrices();
            int i = mc.getWindow().getScaledWidth() / 2;
            int y = mc.getWindow().getScaledHeight() - 25;


            if (mc.player.getOffHandStack().isEmpty()) {
                Render2DEngine.drawHudBase(matrices, i - 90, y, 180, 20, HudEditor.hudRound.getValue());
            } else if (lmode.getValue() == Mode.Merged) {
                Render2DEngine.drawHudBase(matrices, i - 111, y, 201, 20, HudEditor.hudRound.getValue());

                if (HudEditor.hudStyle.is(HudEditor.HudStyle.Blurry)) {
                    Render2DEngine.drawRect(matrices, i - 109 + 18, y + 2, 0.5f, 15, new Color(0x44FFFFFF, true));
                } else {
                    Render2DEngine.verticalGradient(matrices, i - 109 + 18, y + 2,
                            i - 108 + 18 - 0.5f, y + 13,
                            Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0),
                            HudEditor.textColor.getValue().getColorObject());
                    Render2DEngine.verticalGradient(matrices, i - 109 + 18, y + 13,
                            i - 108 + 18 - 0.5f, y + 19,
                            HudEditor.textColor.getValue().getColorObject(),
                            Render2DEngine.injectAlpha(HudEditor.textColor.getValue().getColorObject(), 0));
                }
            } else {
                Render2DEngine.drawHudBase(matrices, i - 90, y, 180, 20, HudEditor.hudRound.getValue());
                Render2DEngine.drawHudBase(matrices, i - 112, y, 20, 20, HudEditor.hudRound.getValue());
            }


            float targetX = playerEntity.getInventory().selectedSlot * 20f;
            selectItemX += (targetX - selectItemX) * 0.2f;


            Color selectedColor = selectedItemColor.getValue().getColorObject();
            Render2DEngine.drawRound(matrices, (int) (i - 89 + selectItemX), y, 20, 20, 4f, selectedColor);
        }
    }

    public static void renderHotBarItems(float tickDelta, DrawContext context) {
        if (mc.currentScreen instanceof WindowsScreen) return;

        PlayerEntity playerEntity = mc.player;
        if (playerEntity != null) {
            MatrixStack matrices = context.getMatrices();
            int i = mc.getWindow().getScaledWidth() / 2;
            int y = mc.getWindow().getScaledHeight() - 21;

            if (!mc.player.getOffHandStack().isEmpty()) {
                if (lmode.getValue() == Mode.Merged) {
                    renderHotbarItem(context, i - 109, y, playerEntity.getOffHandStack());
                } else {
                    renderHotbarItem(context, i - 111, y, playerEntity.getOffHandStack());
                }
            }

            for (int m = 0; m < 9; ++m) {
                int x = (int) (i - 90 + m * 20 + 2);
                renderHotbarItem(context, x, y, playerEntity.getInventory().main.get(m));
            }
        }
    }

    private static void renderHotbarItem(DrawContext context, int x, int y, ItemStack itemStack) {
        if (!itemStack.isEmpty()) {
            context.getMatrices().push();
            context.getMatrices().translate(x + 8, y + 8, 0.0F);
            context.getMatrices().scale(0.9f, 0.9f, 1.0F);
            context.getMatrices().translate(-(x + 8), -(y + 8), 0.0F);
            context.drawItem(itemStack, x, y);
            context.drawItemInSlot(mc.textRenderer, itemStack, x, y);
            context.getMatrices().pop();
        }
    }

    public static void renderXpBar(MatrixStack matrices) {
        mc.getProfiler().push("expBar");
        mc.getProfiler().pop();

        if (mc.player.experienceLevel > 0) {
            mc.getProfiler().push("expLevel");
            String string = "" + mc.player.experienceLevel;
            int k = (int) ((mc.getWindow().getScaledWidth() - FontRenderers.sf_bold_mini.getStringWidth(string)) / 2);
            int l = mc.getWindow().getScaledHeight() - 35;
            FontRenderers.sf_bold_mini.drawString(matrices, string, k, l, 8453920);
            mc.getProfiler().pop();
        }
    }
}