package better.tree.features.cmd.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.client.util.InputUtil;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import better.tree.core.Managers;
import better.tree.features.cmd.Command;
import better.tree.features.cmd.args.ModuleArgumentType;
import better.tree.features.modules.Module;
import better.tree.setting.impl.Bind;

import java.util.Objects;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static better.tree.features.hud.impl.KeyBinds.getShortKeyName;
import static better.tree.features.modules.client.ClientSettings.isRu;

public class BindCommand extends Command {
    public BindCommand() {
        super("bind");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("module", ModuleArgumentType.create())
                .then(arg("key", StringArgumentType.word()).executes(context -> {
                    final Module module = context.getArgument("module", Module.class);
                    final String stringKey = context.getArgument("key", String.class);

                    if (stringKey == null) {
                        sendMessage(Formatting.AQUA + module.getName() + Formatting.GRAY + " is bound to " + Formatting.YELLOW + module.getBind().getBind());
                        return SINGLE_SUCCESS;
                    }

                    int key;
                    if (stringKey.equalsIgnoreCase("none") || stringKey.equalsIgnoreCase("null")) {
                        key = -1;
                    } else {
                        try {
                            key = InputUtil.fromTranslationKey("key.keyboard." + stringKey.toLowerCase()).getCode();
                        } catch (NumberFormatException e) {
                            sendMessage(Formatting.RED + (isRu() ? "Такой кнопки не существует!" : "There is no such button"));
                            return SINGLE_SUCCESS;
                        }
                    }

                    if (key == 0) {
                        sendMessage(Formatting.RED + "Unknown key '" + stringKey + "'!");
                        return SINGLE_SUCCESS;
                    }
                    module.setBind(key, !stringKey.equals("M") && stringKey.contains("M"), false);

                    sendMessage(Formatting.GREEN + "Bind for " + Formatting.AQUA + module.getName() + Formatting.WHITE + " set to " + Formatting.YELLOW + stringKey.toUpperCase());

                    return SINGLE_SUCCESS;
                }))
        );

        builder.then(literal("list").executes(context -> {
            StringBuilder binds = new StringBuilder();

            binds.append(Formatting.DARK_GRAY)
                    .append("========== ")
                    .append(Formatting.GREEN)
                    .append("KeyBinds")
                    .append(Formatting.DARK_GRAY)
                    .append(" ==========\n");

            boolean hasBinds = false;
            for (Module feature : Managers.MODULE.modules) {
                if (!Objects.equals(feature.getBind().getBind(), "None")) {
                    hasBinds = true;
                    binds.append(Formatting.AQUA)
                            .append("• ")
                            .append(Formatting.WHITE)
                            .append(feature.getName())
                            .append(Formatting.GRAY)
                            .append(" -> ")
                            .append(Formatting.YELLOW)
                            .append(getShortKeyName(feature))
                            .append(feature.getBind().isHold() ? Formatting.DARK_RED + " [HOLD]" : "")
                            .append("\n");
                }
            }

            if (!hasBinds) {
                binds.append(Formatting.RED).append("Brak ustawionych bindów / No   Binds!");
            } else {
                binds.append(Formatting.DARK_GRAY)
                        .append("==========================");
            }

            sendMessage(binds.toString());
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("clear").executes(context -> {
            for (Module mod : Managers.MODULE.modules) mod.setBind(new Bind(-1, false, false));
            sendMessage(Formatting.GREEN + "All binds cleared!");
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("reset").executes(context -> {
            for (Module mod : Managers.MODULE.modules) mod.setBind(new Bind(-1, false, false));
            sendMessage(Formatting.GREEN + "Done!");
            return SINGLE_SUCCESS;
        }));
    }
}