package better.tree.features.cmd.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import better.tree.features.cmd.Command;
import better.tree.features.modules.client.RPC;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class RpcCommand extends Command {
    public RpcCommand() {
        super("rpc");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("bigImg", StringArgumentType.greedyString()).executes(context -> {
            String bigImg = context.getArgument("bigImg", String.class);

            RPC.WriteFile(bigImg, "none");
            sendMessage(Formatting.GREEN + "Большая картинка RPC изменена на " + Formatting.AQUA + bigImg);

            return SINGLE_SUCCESS;
        }).then(arg("littleImg", StringArgumentType.greedyString()).executes(context -> {
            String bigImg = context.getArgument("bigImg", String.class);
            String littleImg = context.getArgument("littleImg", String.class);

            RPC.WriteFile(bigImg, littleImg);
            sendMessage(Formatting.GREEN + "Большая картинка RPC изменена на " + Formatting.AQUA + bigImg);
            sendMessage(Formatting.GREEN + "Маленькая картинка RPC изменена на " + Formatting.AQUA + littleImg);

            return SINGLE_SUCCESS;
        })));

        builder.executes(context -> {
            sendMessage(Formatting.YELLOW + "Usage: .rpc <bigImgUrl> or .rpc <bigImgUrl> <littleImgUrl>");
            return SINGLE_SUCCESS;
        });
    }
}