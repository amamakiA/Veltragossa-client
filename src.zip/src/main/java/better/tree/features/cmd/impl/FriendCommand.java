package better.tree.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import better.tree.core.Managers;
import better.tree.features.cmd.Command;
import better.tree.features.cmd.args.FriendArgumentType;
import better.tree.features.cmd.args.PlayerArgumentType;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class FriendCommand extends Command {
    public FriendCommand() {
        super("friend", "friends");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("reset").executes(context -> {
            Managers.FRIEND.clear();
            sendMessage(Formatting.GREEN + "Friends got reset.");

            return SINGLE_SUCCESS;
        }));

        builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            PlayerListEntry player = context.getArgument("player", PlayerListEntry.class);

            Managers.FRIEND.addFriend(player.getProfile().getName());
            sendMessage(Formatting.GREEN + player.getProfile().getName() + " has been friended!");
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("remove").then(arg("player", FriendArgumentType.create()).executes(context -> {
            String nickname = context.getArgument("player", String.class);

            Managers.FRIEND.removeFriend(nickname);
            sendMessage(Formatting.RED + nickname + " has been unfriended!");
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("is").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            PlayerListEntry player = context.getArgument("player", PlayerListEntry.class);
            sendMessage(Formatting.AQUA + player.getProfile().getName() + (Managers.FRIEND.isFriend(player.getProfile().getName()) ? Formatting.GREEN + " is friended." : Formatting.RED + " isn't friended."));

            return SINGLE_SUCCESS;
        })));

        builder.executes(context -> {
            if (Managers.FRIEND.getFriends().isEmpty()) {
                sendMessage(Formatting.YELLOW + "Friend list empty :(");
            } else {
                StringBuilder f = new StringBuilder(Formatting.AQUA + "Friends: " + Formatting.WHITE);
                for (String friend : Managers.FRIEND.getFriends()) {
                    try {
                        f.append(friend).append(", ");
                    } catch (Exception ignored) {
                    }
                }
                sendMessage(f.toString());
            }
            return SINGLE_SUCCESS;
        });
    }
}