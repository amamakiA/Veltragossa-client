package better.tree.features.cmd.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import better.tree.features.cmd.Command;
import better.tree.features.cmd.args.ModuleArgumentType;
import better.tree.features.modules.Module;
import better.tree.features.modules.client.ClientSettings;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class DrawCommand extends Command {
    public DrawCommand() {
        super("draw");
    }

    @Override
    public void executeBuild(@NotNull LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("module", ModuleArgumentType.create()).executes(context -> {
            Module module = context.getArgument("module", Module.class);

            module.setDrawn(!module.isDrawn());

            if(ClientSettings.isRu()){
                sendMessage(Formatting.AQUA + "Модуль " + Formatting.GREEN + module.getName() + Formatting.AQUA + " теперь " + (module.isDrawn() ? Formatting.GREEN + "виден в ArrayList" : Formatting.RED + "не виден в ArrayList"));
            } else {
                sendMessage(Formatting.AQUA + module.getName() + Formatting.AQUA + " is now " + (module.isDrawn() ? Formatting.GREEN + "visible in ArrayList" : Formatting.RED + "invisible in ArrayList"));
            }

            return SINGLE_SUCCESS;
        }));
    }
}