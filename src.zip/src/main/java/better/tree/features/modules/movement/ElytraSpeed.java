package better.tree.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import better.tree.veltragossa;
import better.tree.core.Managers;
import better.tree.events.impl.EventAttack;
import better.tree.events.impl.EventPlayerTravel;
import better.tree.features.modules.Module;
import better.tree.gui.notification.Notification;
import better.tree.setting.Setting;
import better.tree.utility.Timer;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.player.SearchInvResult;

public class ElytraSpeed extends Module {

    private final Setting<Integer> fireworkDelay = new Setting<>("Delay", 500, 0, 1000);
    private final Setting<Boolean> enableLogging = new Setting<>("Log", false);
    private final Setting<BypassMode> bypassMode = new Setting<>("AntiCheatBypass", BypassMode.None);
    private final Setting<DoubleTapMode> doubleTapMode = new Setting<>("DoubleTap", DoubleTapMode.None);
    private final Setting<SpeedMethod> movementMode = new Setting<>("Speed Bypass", SpeedMethod.GRIM);

    private final Setting<Float> velocityMultiplier = new Setting<>("Speed Multiplier", 1.5f, 0.1f, 5.0f,
            v -> movementMode.getValue() != SpeedMethod.PACKET);
    private final Setting<Float> maxVelocity = new Setting<>("Max Speed", 5.0f, 0.1f, 20.0f,
            v -> movementMode.getValue() == SpeedMethod.CUSTOM);
    private final Setting<Float> minimumDistance = new Setting<>("Min Distance", 2.0f, 0.1f, 10.0f);

    private final Setting<Boolean> timerEnabled = new Setting<>("Use Timer", false);
    private final Setting<Float> timerMultiplier = new Setting<>("Timer Rage", 1.0f, 0.1f, 10.0f,
            v -> timerEnabled.getValue());

    private final Setting<Boolean> disableAutomatically = new Setting<>("AutoOFF", true);
    private final Setting<Integer> disableAfterSeconds = new Setting<>("OFF  Time", 5, 1, 30);

    private final Timer autoDisableTimer = new Timer();
    private final Timer fireworkTimer = new Timer();

    public ElytraSpeed() {
        super("ElytraSpeed", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (disableAutomatically.getValue()) {
            autoDisableTimer.reset();
        }
    }

    @Override
    public void onDisable() {
        if (timerEnabled.getValue()) {
            veltragossa.TICK_TIMER = 1.0f;
        }
    }

    @EventHandler
    public void onUpdate() {
        if (disableAutomatically.getValue() && autoDisableTimer.passedS(disableAfterSeconds.getValue())) {
            this.disable();
        }

        if (!fireworkTimer.passedMs(fireworkDelay.getValue())) return;

        if (doubleTapMode.getValue() == DoubleTapMode.Auto && !hasMaxElytraSpeed()) {
            useDoubleFirework();
            logNotification("Double tap used", Notification.Type.SUCCESS);
        } else {
            useFirework();
        }

        fireworkTimer.reset();
    }

    @EventHandler
    public void onPlayerAttack(EventAttack event) {
        if (disableAutomatically.getValue() && event.getEntity() instanceof PlayerEntity) {
            this.disable();
        }
    }

    @EventHandler
    public void modifyVelocity(EventPlayerTravel e) {
        if (movementMode.getValue() == SpeedMethod.GRIM) {
            if (bypassMode.getValue() == BypassMode.GrimAC &&
                    !e.isPre() &&
                    veltragossa.core.getSetBackTime() > 1000 &&
                    mc.player.isFallFlying()) {

                Vec3d motionVector = mc.player.getVelocity()
                        .multiply(velocityMultiplier.getValue(), 1.0, velocityMultiplier.getValue());

                if (motionVector.lengthSquared() > maxVelocity.getValue() * maxVelocity.getValue()) {
                    double scaleFactor = maxVelocity.getValue() / motionVector.length();
                    motionVector = new Vec3d(
                            motionVector.x * scaleFactor,
                            motionVector.y,
                            motionVector.z * scaleFactor
                    );
                }

                mc.player.setVelocity(motionVector);
            }

        } else if (movementMode.getValue() == SpeedMethod.PACKET) {
            Vec3d packetVelocity = mc.player.getVelocity()
                    .multiply(velocityMultiplier.getValue(), 1.0, velocityMultiplier.getValue());

            mc.player.setVelocity(packetVelocity);
            sendVelocityPacket(packetVelocity);

        } else if (movementMode.getValue() == SpeedMethod.CUSTOM) {
            Vec3d currentVelocity = mc.player.getVelocity();
            double currentSpeed = Math.sqrt(currentVelocity.x * currentVelocity.x + currentVelocity.z * currentVelocity.z);

            if (currentSpeed > maxVelocity.getValue()) {
                double scaleFactor = maxVelocity.getValue() / currentSpeed;
                currentVelocity = new Vec3d(
                        currentVelocity.x * scaleFactor,
                        currentVelocity.y,
                        currentVelocity.z * scaleFactor
                );
                logNotification("Speed capped to Max Speed", Notification.Type.WARNING);
            } else {
                currentVelocity = currentVelocity.multiply(velocityMultiplier.getValue(), 1.0, velocityMultiplier.getValue());
            }

            mc.player.setVelocity(currentVelocity);
        }

        if (timerEnabled.getValue()) {
            veltragossa.TICK_TIMER = timerMultiplier.getValue();
        }
    }

    private boolean hasMaxElytraSpeed() {
        double speed = Math.sqrt(mc.player.getVelocity().x * mc.player.getVelocity().x +
                mc.player.getVelocity().z * mc.player.getVelocity().z);
        return speed >= 33.50;
    }

    private void useDoubleFirework() {
        useFirework();
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        useFirework();
    }

    private void useFirework() {
        SearchInvResult hotbarFirework = InventoryUtility.findItemInHotBar(Items.FIREWORK_ROCKET);
        SearchInvResult inventoryFirework = InventoryUtility.findItemInInventory(Items.FIREWORK_ROCKET);

        InventoryUtility.saveSlot();

        if (hotbarFirework.found()) {
            hotbarFirework.switchTo();
        } else if (inventoryFirework.found()) {
            mc.interactionManager.clickSlot(
                    mc.player.currentScreenHandler.syncId,
                    inventoryFirework.slot(),
                    mc.player.getInventory().selectedSlot,
                    SlotActionType.SWAP,
                    mc.player
            );
            sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
        } else {
            logNotification("No fireworks found!", Notification.Type.ERROR);
            return;
        }

        sendSequencedPacket(id -> new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, id, mc.player.getYaw(), mc.player.getPitch()));
        sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));

        InventoryUtility.returnSlot();

        if (!hotbarFirework.found() && inventoryFirework.found()) {
            mc.interactionManager.clickSlot(
                    mc.player.currentScreenHandler.syncId,
                    inventoryFirework.slot(),
                    mc.player.getInventory().selectedSlot,
                    SlotActionType.SWAP,
                    mc.player
            );
            sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
        }
    }

    private void sendVelocityPacket(Vec3d velocity) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                mc.player.getX() + velocity.x,
                mc.player.getY(),
                mc.player.getZ() + velocity.z,
                mc.player.isOnGround()
        ));
    }

    private void logNotification(String message, Notification.Type type) {
        if (enableLogging.getValue()) {
            Managers.NOTIFICATION.publicity("ElytraSpeed", message, 1, type);
        }
    }

    public enum SpeedMethod { PACKET, GRIM, CUSTOM }
    public enum BypassMode { None, GrimAC }
    public enum DoubleTapMode { None, Auto }
}