package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import better.tree.features.modules.misc.FakePlayer;
import better.tree.core.manager.client.ModuleManager;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.EventAttack;
import better.tree.events.impl.EventTick;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BackTrack extends Module {

    private final Setting<Float> activationChance = new Setting<>("ActivationChance", 89.0f, 0.0f, 100.0f);




    private Entity target;
    private Vec3d ghostPosition;
    private Vec3d realPosition;
    private final ConcurrentLinkedQueue<DelayedPacket> serverDelayerPackets = new ConcurrentLinkedQueue<>();
    private boolean serverDelayerActive = false;
    private boolean serverDelayerActivatedForTarget = false;
    private long lastDamageTime = 0;
    private int lastAttackedTargetId = -1;
    private long lastAttackTime = 0;
    private int ticksSinceEnable = 0;
    private float serverReportedHealth = Float.NaN;
    private Vec3d serverVelocity;

    public BackTrack() {
        super("Backtrack", Module.Category.COMBAT);
    }

    @Override
    public void onEnable() {
        ticksSinceEnable = 0;
    }

    @Override
    public void onDisable() {
        resetTargetPosition();
        clearAllData();
    }


    @EventHandler
    public void onAttack(EventAttack event) {
        if (!isEnabled() || Math.random() * 100.0 > activationChance.getValue()) {
            return;
        }

        Entity attackedEntity = event.getEntity();

        boolean isFakePlayer = attackedEntity == better.tree.features.modules.misc.FakePlayer.fakePlayer;
        if (attackedEntity == null || (!(attackedEntity instanceof LivingEntity) && !isFakePlayer) || attackedEntity == mc.player) {
            return;
        }

        if (target == null || target.getId() != attackedEntity.getId()) {
            setNewTarget(attackedEntity);
        }

        lastAttackedTargetId = attackedEntity.getId();
        lastAttackTime = System.currentTimeMillis();

        if (event.isPre() && target != null && ghostPosition != null) {
            applyGhostPosition();
        }
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (!isEnabled()) return;

        ticksSinceEnable++;


        boolean isFakePlayer = target == better.tree.features.modules.misc.FakePlayer.fakePlayer;
        if (target != null && (!isFakePlayer && (!target.isAlive() || target.isRemoved()))) {
            clearAllData();
            return;
        }

        if (serverDelayerActive && target != null && ghostPosition != null) {
            updateTargetPosition();
        }


        if (target != null && realPosition != null && serverVelocity != null) {
            realPosition = realPosition.add(serverVelocity);
        }
    }

    @Override
    public void onRender3D(MatrixStack matrixStack) {
        if (target == null || ghostPosition == null || realPosition == null) {
            return;
        }

        double halfWidth = target.getWidth() / 2.0;
        double height = target.getHeight();


        Box realBox = new Box(-halfWidth, 0.0, -halfWidth, halfWidth, height, halfWidth).offset(realPosition);
        Render3DEngine.drawBoxOutline(realBox, new Color(169, 19, 211, 150), 1.5f);


        Box ghostBox = new Box(-halfWidth, 0.0, -halfWidth, halfWidth, height, halfWidth).offset(ghostPosition);
        Render3DEngine.drawBoxOutline(ghostBox, new Color(242, 245, 250, 150), 1.5f);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        if (!isEnabled()) {
            return;
        }

        Packet<?> packet = event.getPacket();
        if (packet instanceof net.minecraft.network.packet.s2c.play.GameMessageS2CPacket
            || packet.getClass().getSimpleName().toLowerCase().contains("chat")
            || packet instanceof net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket) {
            return;
        }

        if (packet instanceof net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket statusPacket) {
            Entity statusEntity = statusPacket.getEntity(mc.world);
            boolean isFakePlayer = statusEntity == better.tree.features.modules.misc.FakePlayer.fakePlayer;
            if ((statusEntity instanceof LivingEntity living || isFakePlayer) && target != null && statusEntity.getId() == target.getId()) {
                try {

                    serverReportedHealth = ((LivingEntity)statusEntity).getHealth() + ((LivingEntity)statusEntity).getAbsorptionAmount();
                } catch (Exception ignored) {
                }

            }
        }
        if (packet instanceof PlayerPositionLookS2CPacket || packet instanceof DisconnectS2CPacket) {
            clearAllData();
            return;
        }



        if (target != null) {
            try {
                if (packet instanceof EntityS2CPacket move && ((better.tree.injection.accesors.IEntityS2CPacket) move).getId() == target.getId()) {
                    Vec3d base = realPosition != null ? realPosition : target.getPos();
                    double dx = move.getDeltaX();
                    double dy = move.getDeltaY();
                    double dz = move.getDeltaZ();

                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10 || Math.abs(dz) > 10) {
                        dx /= 4096.0;
                        dy /= 4096.0;
                        dz /= 4096.0;
                    }
                    realPosition = new Vec3d(base.x + dx, base.y + dy, base.z + dz);
                } else if (packet instanceof EntityVelocityUpdateS2CPacket vel && vel.getId() == target.getId()) {

                    serverVelocity = new Vec3d(vel.getVelocityX() / 8000.0, vel.getVelocityY() / 8000.0, vel.getVelocityZ() / 8000.0);
                }
            } catch (Throwable ignored) {
            }
        }

        if (serverDelayerActivatedForTarget && target != null) {

            String pktName = packet.getClass().getSimpleName().toLowerCase();
            if (pktName.contains("health") || pktName.contains("entityattributes") || pktName.contains("entityproperties") || pktName.contains("entitymetadata") || pktName.contains("entitytracking") || pktName.contains("entityupdate") || pktName.contains("entitystatus")) {

                return;
            }

            serverDelayerPackets.add(new DelayedPacket(packet, System.currentTimeMillis()));
            event.cancel();
        }

        if (target != null && !serverDelayerActivatedForTarget) {
            serverDelayerActive = true;
            serverDelayerActivatedForTarget = true;
        }

        if (serverDelayerActivatedForTarget && target != null) {
            serverDelayerPackets.add(new DelayedPacket(packet, System.currentTimeMillis()));
            event.cancel();
        }
    }


    private void clearAllData() {
        target = null;
        ghostPosition = null;
        realPosition = null;
        serverDelayerActive = false;
        serverDelayerActivatedForTarget = false;
        serverDelayerPackets.clear();
    }

    private void setNewTarget(Entity newTarget) {
        target = newTarget;
        ghostPosition = newTarget.getPos();
        realPosition = newTarget.getPos();
        serverDelayerActivatedForTarget = false;

    }

    private void applyGhostPosition() {
        if (target == null || ghostPosition == null) return;
        target.setPos(ghostPosition.x, ghostPosition.y, ghostPosition.z);
        target.prevX = ghostPosition.x;
        target.prevY = ghostPosition.y;
        target.prevZ = ghostPosition.z;
    }

    private void updateTargetPosition() {
        if (target == null || ghostPosition == null) return;
        target.setPos(ghostPosition.x, ghostPosition.y, ghostPosition.z);
        target.prevX = ghostPosition.x;
        target.prevY = ghostPosition.y;
        target.prevZ = ghostPosition.z;
        target.lastRenderX = ghostPosition.x;
        target.lastRenderY = ghostPosition.y;
        target.lastRenderZ = ghostPosition.z;
        target.setVelocity(0, 0, 0);
    }

    private void resetTargetPosition() {
        if (target != null && realPosition != null) {
            target.setPos(realPosition.x, realPosition.y, realPosition.z);
            target.lastRenderX = realPosition.x;
            target.lastRenderY = realPosition.y;
            target.lastRenderZ = realPosition.z;
            target.prevX = realPosition.x;
            target.prevY = realPosition.y;
            target.prevZ = realPosition.z;
        }
    }


    public boolean isTargetInReach(Entity entity) {
        if (!isEnabled() || target == null || target.getId() != entity.getId() || ghostPosition == null) {
            return false;
        }
        double distance = mc.player.getPos().distanceTo(ghostPosition);
        double maxReach = mc.player.getEntityInteractionRange() + 3.0;
        return distance <= maxReach;
    }

    public boolean shouldExtendReach(Entity entity) {
        return isEnabled() && target != null && target.getId() == entity.getId() && ghostPosition != null;
    }

    public Vec3d getGhostPosition(Entity entity) {
        if (!isEnabled() || target == null || target.getId() != entity.getId()) {
            return null;
        }
        return ghostPosition;
    }

    public boolean hasTarget(Entity entity) {
        return isEnabled() && target != null && target.getId() == entity.getId();
    }


    private static class DelayedPacket {
        public final Packet<?> packet;
        public final long timestamp;

        public DelayedPacket(Packet<?> packet, long timestamp) {
            this.packet = packet;
            this.timestamp = timestamp;
        }
    }

    @Override
    public String getDisplayInfo() {
        return serverDelayerPackets.size() + " ServDelayer";
    }
}
