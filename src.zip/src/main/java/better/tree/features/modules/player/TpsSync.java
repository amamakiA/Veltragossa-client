package better.tree.features.modules.player;

import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import better.tree.veltragossa;
import better.tree.core.Managers;
import better.tree.core.manager.client.ModuleManager;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;

public class TpsSync extends Module {
    public TpsSync() {
        super("TpsSync", Module.Category.PLAYER);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onTick(EventTick e) {
        if (ModuleManager.timer.isEnabled()) return;
        if (Managers.SERVER.getTPS() > 1)
            veltragossa.TICK_TIMER = Managers.SERVER.getTPS() / 20f;
        else veltragossa.TICK_TIMER = 1f;
    }

    @Override
    public void onDisable() {
        veltragossa.TICK_TIMER = 1f;
    }
}