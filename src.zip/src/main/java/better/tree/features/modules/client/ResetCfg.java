package better.tree.features.modules.client;

import better.tree.features.modules.Module;
import better.tree.core.Managers;
import better.tree.core.manager.client.ConfigManager;

public class ResetCfg extends Module {
    public ResetCfg() {
        super("Reset Cfg", Category.CLIENT);
    }

    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            disable();
            return;
        }

        ConfigManager.allowAutoSave = false;
        Managers.MODULE.modules.forEach(module -> {
            module.resetToDefaults();
            module.disable();
        });

        sendMessage("All module settings have been reset to default values!");
        disable();

        ConfigManager.allowAutoSave = true;
    }
}
