package better.tree.features.modules.client;

import better.tree.features.modules.Module;

public final class Notifications extends Module {
    public Notifications() {
        super("Notifications", Category.CLIENT);
    }

    public Mode getMode() {
        return Mode.Default;
    }

    public enum Mode {
        Default, CrossHair, Text
    }
}