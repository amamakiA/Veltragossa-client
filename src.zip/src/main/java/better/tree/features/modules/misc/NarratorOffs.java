package better.tree.features.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.NarratorMode;
import better.tree.features.modules.Module;

public class NarratorOffs extends Module {

    public NarratorOffs() {
        super("NarratorOffs", Category.MISC);
    }

    @Override
    public void onEnable() {
        forceNarratorOff();
        sendMessage("Narrator został wyłączony i zablokowany.");
    }

    @Override
    public void onUpdate() {
        if (MinecraftClient.getInstance().options.getNarrator().getValue() != NarratorMode.OFF) {
            forceNarratorOff();
            sendMessage("Narrator automatycznie wyłączony.");
        }
    }

    private void forceNarratorOff() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.options.getNarrator().setValue(NarratorMode.OFF);
        mc.getNarratorManager().clear();
    }
}