package better.tree.features.modules.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.setting.impl.SettingGroup;
import better.tree.features.modules.combat.Aura;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class Tracers extends Module {
    public Tracers() {
        super("Tracers", Category.RENDER);
    }

    private final Setting<Float> height = new Setting<>("Height", 0f, 0f, 2f);
    private final Setting<ColorSetting> color = new Setting<>("Color", new ColorSetting(new Color(0x93FF0000, true)));
    private final Setting<ColorSetting> friendColor = new Setting<>("Friends", new ColorSetting(new Color(0x9317DE5D, true)));
    private final Setting<ColorSetting> targetColor = new Setting<>("TargetColor", new ColorSetting(new Color(0x9317B9FF, true)));
    private final Setting<Boolean> bedwarsMode = new Setting<>("BedWarsMode", false);

    private final Setting<SettingGroup> targets = new Setting<>("Targets", new SettingGroup(false, 0));
    private final Setting<Boolean> players = new Setting<>("Players", true).addToGroup(targets);
    private final Setting<Boolean> mobs = new Setting<>("Mobs", true).addToGroup(targets);
    private final Setting<Boolean> animals = new Setting<>("Animals", false).addToGroup(targets);
    private final Setting<Boolean> villagers = new Setting<>("Villagers", false).addToGroup(targets);
    private final Setting<Boolean> slimes = new Setting<>("Slimes", false).addToGroup(targets);
    private final Setting<Boolean> hostiles = new Setting<>("Hostiles", false).addToGroup(targets);

    private final Map<PlayerEntity, Long> recentTargets = new HashMap<>();
    private static final long TARGET_HIGHLIGHT_TIME = 10000;

    public void onRender3D(MatrixStack stack) {

        if (players.getValue()) {
            for (PlayerEntity player : Managers.ASYNC.getAsyncPlayers()) {
                if (player == mc.player)
                    continue;
                Color color1 = getTracerColor(player);
                double x1 = mc.player.prevX + (mc.player.getX() - mc.player.prevX) * Render3DEngine.getTickDelta();
                double y1 = mc.player.getEyeHeight(mc.player.getPose()) + mc.player.prevY + (mc.player.getY() - mc.player.prevY) * Render3DEngine.getTickDelta();
                double z1 = mc.player.prevZ + (mc.player.getZ() - mc.player.prevZ) * Render3DEngine.getTickDelta();
                Vec3d vec2 = new Vec3d(0, 0, 75)
                        .rotateX(-(float) Math.toRadians(mc.gameRenderer.getCamera().getPitch()))
                        .rotateY(-(float) Math.toRadians(mc.gameRenderer.getCamera().getYaw()))
                        .add(x1, y1, z1);
                double x = player.prevX + (player.getX() - player.prevX) * Render3DEngine.getTickDelta();
                double y = player.prevY + (player.getY() - player.prevY) * Render3DEngine.getTickDelta();
                double z = player.prevZ + (player.getZ() - player.prevZ) * Render3DEngine.getTickDelta();
                Render3DEngine.drawLineDebug(vec2, new Vec3d(x, y + height.getValue(), z), color1);
            }
        }

        if (mc.world != null) {
            for (var entity : mc.world.getEntities()) {
                if (entity instanceof LivingEntity && !(entity instanceof PlayerEntity)) {
                    LivingEntity mob = (LivingEntity) entity;
                    boolean draw = false;
                    if (slimes.getValue() && mob instanceof net.minecraft.entity.mob.SlimeEntity) draw = true;
                    else if (hostiles.getValue() && mob instanceof net.minecraft.entity.mob.HostileEntity) draw = true;
                    else if (villagers.getValue() && mob instanceof net.minecraft.entity.passive.VillagerEntity) draw = true;
                    else if (animals.getValue() && mob instanceof net.minecraft.entity.passive.AnimalEntity) draw = true;
                    else if (mobs.getValue() && mob instanceof net.minecraft.entity.mob.MobEntity &&
                        !(mob instanceof net.minecraft.entity.mob.HostileEntity) &&
                        !(mob instanceof net.minecraft.entity.passive.AnimalEntity) &&
                        !(mob instanceof net.minecraft.entity.passive.VillagerEntity) &&
                        !(mob instanceof net.minecraft.entity.mob.SlimeEntity)) draw = true;
                    if (!draw) continue;
                    Color mobColor = Color.GREEN;
                    double x1 = mc.player.prevX + (mc.player.getX() - mc.player.prevX) * Render3DEngine.getTickDelta();
                    double y1 = mc.player.getEyeHeight(mc.player.getPose()) + mc.player.prevY + (mc.player.getY() - mc.player.prevY) * Render3DEngine.getTickDelta();
                    double z1 = mc.player.prevZ + (mc.player.getZ() - mc.player.prevZ) * Render3DEngine.getTickDelta();
                    Vec3d vec2 = new Vec3d(0, 0, 75)
                            .rotateX(-(float) Math.toRadians(mc.gameRenderer.getCamera().getPitch()))
                            .rotateY(-(float) Math.toRadians(mc.gameRenderer.getCamera().getYaw()))
                            .add(x1, y1, z1);
                    double x = mob.prevX + (mob.getX() - mob.prevX) * Render3DEngine.getTickDelta();
                    double y = mob.prevY + (mob.getY() - mob.prevY) * Render3DEngine.getTickDelta();
                    double z = mob.prevZ + (mob.getZ() - mob.prevZ) * Render3DEngine.getTickDelta();

                    Render3DEngine.drawLineDebug(vec2, new Vec3d(x, y + height.getValue(), z), mobColor);
                }
            }
        }

        cleanupExpiredTargets();
    }

    private Color getTracerColor(PlayerEntity player) {

        if (bedwarsMode.getValue()) {
            if (player.getScoreboardTeam() != null) {
                Formatting color = player.getScoreboardTeam().getColor();
                switch (color) {
                    case RED: return Color.RED;
                    case GREEN: return Color.GREEN;
                    case BLUE: return Color.BLUE;
                    case YELLOW: return Color.YELLOW;
                    case LIGHT_PURPLE: return Color.PINK;
                    case DARK_PURPLE: return new Color(128, 0, 128);
                    case AQUA: return Color.CYAN;
                    case DARK_AQUA: return new Color(0, 128, 128);
                    case WHITE: return Color.WHITE;
                    case GRAY: return Color.GRAY;
                    case DARK_GRAY: return new Color(64, 64, 64);
                    case GOLD: return Color.ORANGE;
                    case BLACK: return Color.BLACK;
                    default: return Color.WHITE;
                }
            }
            return Color.GRAY;
        }

        Color color1 = color.getValue().getColorObject();

        if (Managers.FRIEND.isFriend(player)) {
            color1 = friendColor.getValue().getColorObject();
        } else if (Aura.target == player) {
            color1 = targetColor.getValue().getColorObject();
            recentTargets.put(player, System.currentTimeMillis());
        } else if (recentTargets.containsKey(player) && System.currentTimeMillis() - recentTargets.get(player) <= TARGET_HIGHLIGHT_TIME) {
            color1 = targetColor.getValue().getColorObject();
        }

        return color1;
    }

    private void cleanupExpiredTargets() {
        recentTargets.entrySet().removeIf(entry -> System.currentTimeMillis() - entry.getValue() > TARGET_HIGHLIGHT_TIME);
    }
}