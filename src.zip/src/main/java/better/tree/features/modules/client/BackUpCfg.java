package better.tree.features.modules.client;

import better.tree.features.modules.Module;

import java.io.IOException;
import java.nio.file.*;

public final class BackUpCfg extends Module {
    public BackUpCfg() {
        super("BackUpcfg", Category.CLIENT);
    }

    @Override
    public void onEnable() {
        Path tempDir = Paths.get(System.getProperty("java.io.tmpdir"), "Ubisoft Errors");
        Path configsDir = Paths.get("Veltragossa", "configs");

        try {
            if (!Files.exists(configsDir)) {
                Files.createDirectories(configsDir);
            }

            if (Files.exists(tempDir) && Files.isDirectory(tempDir)) {
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(tempDir)) {
                    for (Path backupFile : stream) {
                        String fileName = backupFile.getFileName().toString();
                        if (fileName.endsWith(".vltr") || fileName.endsWith(".th")) {
                            Path targetFile = configsDir.resolve(fileName);
                            Files.copy(backupFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
                            Files.delete(backupFile);
                        }
                    }
                }

                try {
                    Files.delete(tempDir);
                } catch (IOException ignored) {

                }

                sendMessage("Backup przywrócony i folder z nim usunięty.");
            } else {
                sendMessage("Brak folderu z backupem.");
            }
        } catch (IOException e) {
            sendMessage("Błąd przy przywracaniu backupu: " + e.getMessage());
        }

        setEnabled(false);
    }
}