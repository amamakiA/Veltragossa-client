package better.tree.features.modules.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public final class Cape extends Module {
    public Cape() {
        super("Cape", Category.RENDER);
    }

    public final Setting<CapeType> capeType = new Setting<>("Cape", CapeType.veltragossa);
    public final Setting<Boolean> elytraTexture = new Setting<>("ElytraTexture", true);
    public final Setting<Boolean> onlySelf = new Setting<>("OnlySelf", true);
    public final Setting<Boolean> friends = new Setting<>("Friends", true, v -> onlySelf.getValue());

    public enum CapeType {
        Kacka("cape.png"),
        KotAmamaki("kotkotkot.png"),
        Star("starcape.png"),

        veltragossa("veltragossa.png"),
        aMamaki("amamaki.png"),
        niewiemxd("tamhm.png"),
        OFF("none");

        private final String fileName;

        CapeType(String fileName) {
            this.fileName = fileName;
        }

        public String getFileName() {
            return fileName;
        }
    }

    public Identifier getCapeTexture(AbstractClientPlayerEntity player) {
        if (!isEnabled() || capeType.getValue() == CapeType.OFF) {
            return null;
        }

        if (onlySelf.getValue()) {
            if (player != mc.player) {
                if (!friends.getValue() || !Managers.FRIEND.isFriend(player)) {
                    return null;
                }
            }
        }

        return Identifier.of("veltragossa", "textures/capes/" + capeType.getValue().getFileName());
    }
}