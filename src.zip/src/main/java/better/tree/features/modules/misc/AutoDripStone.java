package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.Timer;
import better.tree.utility.player.InteractionUtility;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;

import static better.tree.utility.player.InteractionUtility.checkNearBlocks;

public class AutoDripStone extends Module {
    private final Setting<Integer> range = new Setting<>("Range", 3, 1, 5);
    private final Setting<Integer> delay = new Setting<>("Delay", 1, 1, 1500);
    private final Setting<Boolean> silentSwitch = new Setting<>("SilentSwitch", true);

    private final Setting<ColorSetting> renderColor =
            new Setting<>("RenderColor", new ColorSetting(new Color(9, 232, 190, 150)));

    private final Timer timer = new Timer();
    private BlockPos lastPlacePos;

    public AutoDripStone() {
        super("AutoDripStone", Category.MISC);
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (mc.player == null || mc.world == null || !timer.passedMs(delay.getValue())) return;

        BlockPos playerPos = mc.player.getBlockPos();
        for (int x = -range.getValue(); x <= range.getValue(); x++) {
            for (int y = -range.getValue(); y <= range.getValue(); y++) {
                for (int z = -range.getValue(); z <= range.getValue(); z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    BlockState state = mc.world.getBlockState(pos);

                    if (state.getBlock() instanceof TrapdoorBlock && !state.get(TrapdoorBlock.OPEN)) {
                        if (handleDripstonePlacement(pos)) {
                            timer.reset();
                            return;
                        }
                    }
                }
            }
        }
    }

    private boolean handleDripstonePlacement(BlockPos trapdoorPos) {
        BlockPos placePos = trapdoorPos.down();
        if (!mc.world.getBlockState(placePos).isAir()) return false;

        int dripstoneSlot = InventoryUtility.findInHotBar(i -> i.getItem() == Items.POINTED_DRIPSTONE).slot();
        if (dripstoneSlot == -1) return false;

        int prevSlot = mc.player.getInventory().selectedSlot;
        if (silentSwitch.getValue()) switchToSlotSilent(dripstoneSlot);
        else switchToSlot(dripstoneSlot);

        InteractionUtility.BlockPosWithFacing targetBlock = checkNearBlocks(placePos);
        if (targetBlock == null) return false;

        placeBlock(targetBlock);
        lastPlacePos = placePos;

        timer.reset();
        mc.player.getInventory().selectedSlot = prevSlot;

        holdRightClickOnTrapdoor(trapdoorPos);
        return true;
    }

    private void holdRightClickOnTrapdoor(BlockPos trapdoorPos) {
        if (!timer.passedMs(1)) return;
        BlockHitResult hitResult = new BlockHitResult(mc.player.getPos(), Direction.UP, trapdoorPos, false);
        sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hitResult, 0));
        sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
    }

    private void switchToSlotSilent(int slot) {
        mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private void switchToSlot(int slot) {
        mc.player.getInventory().selectedSlot = slot;
    }

    private void placeBlock(InteractionUtility.BlockPosWithFacing block) {
        BlockHitResult bhr = new BlockHitResult(
                block.position().toCenterPos().add(new Vec3d(block.facing().getUnitVector()).multiply(0.5)),
                block.facing(), block.position(), false
        );

        if (!timer.passedMs(1)) return;
        sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, bhr, 0));
        sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
    }

    @Override
    protected void sendPacket(Packet<?> packet) {
        mc.player.networkHandler.sendPacket(packet);
    }

    @Override
    public void onRender3D(MatrixStack stack) {
        if (lastPlacePos == null) return;

        Color color = renderColor.getValue().getColorObject();
        int colorInt = color.getRGB();

        Render3DEngine.drawBoxOutline(new Box(lastPlacePos), color, 2);
        Render3DEngine.drawFilledBox(stack, new Box(lastPlacePos), Render2DEngine.injectAlpha(color, 100));
        Vec3d start = mc.player.getPos().add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);
        Vec3d end = Vec3d.ofCenter(lastPlacePos);
        Render3DEngine.drawLine(start, end, 2.0f, colorInt);
    }
}