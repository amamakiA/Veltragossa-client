package better.tree.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.util.LinkedList;
import java.util.Queue;

public class AirStuck extends Module {
    public AirStuck() {
        super("AirStuck", Category.MOVEMENT);
    }

    private final Setting<Boolean> freezeRotation = new Setting<>("FreezeRotation", true);

    private final Queue<Packet<?>> storedPackets = new LinkedList<>();
    private double freezeX, freezeY, freezeZ;
    private float freezeYaw, freezePitch;

    @Override
    public void onEnable() {
        if (mc.player == null || mc.world == null) {
            disable();
            return;
        }

        freezeX = mc.player.getX();
        freezeY = mc.player.getY();
        freezeZ = mc.player.getZ();
        freezeYaw = mc.player.getYaw();
        freezePitch = mc.player.getPitch();
        storedPackets.clear();
    }

    @Override
    public void onDisable() {
        while (!storedPackets.isEmpty()) {
            sendPacket(storedPackets.poll());
        }
        storedPackets.clear();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null) return;

        if (!mc.player.isAlive()) {
            disable();
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send event) {
        if (mc.player == null) return;

        Packet<?> packet = event.getPacket();

        if (packet instanceof PlayerMoveC2SPacket movePacket) {
            event.cancel();
            storedPackets.add(packet);

            mc.player.setPosition(freezeX, freezeY, freezeZ);

            if (freezeRotation.getValue()) {
                mc.player.setYaw(freezeYaw);
                mc.player.setPitch(freezePitch);
            }
        }
    }
}