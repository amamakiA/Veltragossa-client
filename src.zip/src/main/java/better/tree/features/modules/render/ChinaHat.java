package better.tree.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import org.joml.Matrix4f;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;

public class ChinaHat extends Module {
    public ChinaHat() {
        super("ChinaHat", Category.RENDER);
    }

    private final Setting<Float> radius = new Setting<>("Radius", 0.8f, 0.1f, 2.0f);
    private final Setting<Float> height = new Setting<>("Height", 0.5f, 0.1f, 1.5f);
    private final Setting<ColorSetting> primaryColor = new Setting<>("PrimaryColor", new ColorSetting(new Color(255, 0, 0, 150)));
    private final Setting<ColorSetting> secondaryColor = new Setting<>("SecondaryColor", new ColorSetting(new Color(0, 255, 0, 150)));
    private final Setting<Boolean> gradient = new Setting<>("Gradient", true);
    private final Setting<Boolean> friendsHat = new Setting<>("FriendsHat", true);

    private static final int SEGMENTS = 128;

    @Override
    public void onRender3D(MatrixStack stack) {
        if (mc.player == null || mc.world == null) return;

        if (friendsHat.getValue()) {
            for (PlayerEntity entity : mc.world.getPlayers()) {
                if (entity == mc.player) continue;
                if (!Managers.FRIEND.isFriend(entity)) continue;

                renderHatForEntity(stack, entity);
            }
        }

        renderHatForEntity(stack, mc.player);
    }

    private void renderHatForEntity(MatrixStack stack, PlayerEntity entity) {
        double x = entity.prevX + (entity.getX() - entity.prevX) * Render3DEngine.getTickDelta()
                - mc.getEntityRenderDispatcher().camera.getPos().getX();
        double y = entity.prevY + (entity.getY() - entity.prevY) * Render3DEngine.getTickDelta()
                - mc.getEntityRenderDispatcher().camera.getPos().getY() + entity.getHeight();
        double z = entity.prevZ + (entity.getZ() - entity.prevZ) * Render3DEngine.getTickDelta()
                - mc.getEntityRenderDispatcher().camera.getPos().getZ();

        stack.push();
        stack.translate(x, y, z);

        Render3DEngine.setupRender();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        BufferBuilder bufferBuilder = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = stack.peek().getPositionMatrix();

        long time = System.currentTimeMillis();

        Color centerColor = gradient.getValue()
                ? Render2DEngine.interpolateColorHue(primaryColor.getValue().getColorObject(),
                secondaryColor.getValue().getColorObject(),
                (float) (Math.sin(time * 0.002) + 1.0) / 2.0f)
                : primaryColor.getValue().getColorObject();

        bufferBuilder.vertex(matrix, 0f, height.getValue(), 0f).color(centerColor.getRGB());

        for (int i = 0; i <= SEGMENTS; i++) {
            double angle = (double) i / SEGMENTS * Math.PI * 2;
            float cos = (float) Math.cos(angle);
            float sin = (float) Math.sin(angle);

            float x1 = cos * radius.getValue() * 0.76f;
            float z1 = sin * radius.getValue() * 0.76f;

            Color segmentColor;
            if (gradient.getValue()) {
                float progress = (float) i / SEGMENTS;
                float wave = (float) ((Math.sin(time * 0.004 + progress * Math.PI * 2)
                        + Math.cos(time * 0.003 + progress * Math.PI * 2)) / 2.0);
                segmentColor = Render2DEngine.interpolateColorHue(primaryColor.getValue().getColorObject(),
                        secondaryColor.getValue().getColorObject(), wave);
            } else {
                segmentColor = secondaryColor.getValue().getColorObject();
            }

            bufferBuilder.vertex(matrix, x1, 0f, z1).color(segmentColor.getRGB());
        }

        Render2DEngine.endBuilding(bufferBuilder);

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        Render3DEngine.endRender();

        stack.pop();
    }
}