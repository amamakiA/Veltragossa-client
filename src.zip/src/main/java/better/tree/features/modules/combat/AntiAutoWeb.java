package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.client.util.math.MatrixStack;
import better.tree.core.Managers;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.features.modules.client.HudEditor;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.setting.impl.SettingGroup;
import better.tree.utility.Timer;
import better.tree.utility.player.InteractionUtility;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.Render3DEngine;

import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public final class AntiAutoWeb extends Module {

    private final Setting<BlockType> blockType = new Setting<>("BlockType", BlockType.LEVER);
    private final Setting<Integer> range = new Setting<>("Range", 5, 1, 7);
    private final Setting<Integer> placeWallRange = new Setting<>("WallRange", 5, 1, 7);
    private final Setting<PlaceTiming> placeTiming = new Setting<>("PlaceTiming", PlaceTiming.Default);
    private final Setting<Integer> blocksPerTick = new Setting<>("Block/Tick", 8, 1, 12,
            v -> this.placeTiming.getValue() == PlaceTiming.Default);
    private final Setting<Integer> placeDelay = new Setting<>("Delay/Place", 3, 0, 10);
    private final Setting<InteractionUtility.Interact> interact = new Setting<>("Interact", InteractionUtility.Interact.Strict);
    private final Setting<InteractionUtility.PlaceMode> placeMode = new Setting<>("PlaceMode", InteractionUtility.PlaceMode.Normal);
    private final Setting<InteractionUtility.Rotate> rotate = new Setting<>("Rotate", InteractionUtility.Rotate.None);
    private final Setting<Boolean> selfPlace = new Setting<>("SelfPlace", true);

    private final Setting<SettingGroup> selection = new Setting<>("Selection", new SettingGroup(false, 0));
    private final Setting<Boolean> head = new Setting<>("Head", true).addToGroup(this.selection);
    private final Setting<Boolean> legs = new Setting<>("Legs", true).addToGroup(this.selection);
    private final Setting<Boolean> surround = new Setting<>("Surround", true).addToGroup(this.selection);
    private final Setting<Boolean> upperSurround = new Setting<>("UpperSurround", false).addToGroup(this.selection);

    private final Setting<SettingGroup> renderCategory = new Setting<>("Render", new SettingGroup(false, 0));
    private final Setting<RenderMode> renderMode = new Setting<>("Render Mode", RenderMode.Fade).addToGroup(this.renderCategory);
    private final Setting<ColorSetting> renderFillColor = new Setting<>("Render Fill Color",
            new ColorSetting(HudEditor.getColor(0))).addToGroup(this.renderCategory);
    private final Setting<ColorSetting> renderLineColor = new Setting<>("Render Line Color", new ColorSetting(0x00000000), v -> false).addToGroup(this.renderCategory);
    private final Setting<Integer> renderLineWidth = new Setting<>("Render Line Width", 0, 1, 5, v -> false).addToGroup(this.renderCategory);
    private final Setting<Integer> effectDurationMs = new Setting<>("Effect Duration (MS)", 500, 0, 10000).addToGroup(this.renderCategory);

    private final List<BlockPos> sequentialBlocks = new ArrayList<>();
    public static Timer inactivityTimer = new Timer();
    private final Map<BlockPos, Long> renderPoses = new ConcurrentHashMap<>();
    private int delay = 0;

    public AntiAutoWeb() {
        super("AntiAutoWeb", Category.COMBAT);
    }

    public void onRender3D(MatrixStack stack) {
        this.renderPoses.forEach((pos, time) -> {
            long elapsed = System.currentTimeMillis() - time;
            if (elapsed > effectDurationMs.getValue()) {
                this.renderPoses.remove(pos);
                return;
            }

            switch (renderMode.getValue()) {
                case Fade -> {
                    float alpha = 1.0f - (elapsed / 500.0f);
                    Render3DEngine.drawFilledBox(stack, new Box(pos),
                            Render2DEngine.injectAlpha(renderFillColor.getValue().getColorObject(), (int) (100 * alpha)));
                    Render3DEngine.drawBoxOutline(new Box(pos),
                            Render2DEngine.injectAlpha(renderLineColor.getValue().getColorObject(), (int) (100 * alpha)),
                            renderLineWidth.getValue());
                }
                case Decrease -> {
                    float scale = 1.0f - (elapsed / 500.0f);
                    Box box = new Box(pos).expand(scale).offset(0.5 * scale, 0.5 * scale, 0.5 * scale);

                    Render3DEngine.drawFilledBox(stack, box,
                            Render2DEngine.injectAlpha(renderFillColor.getValue().getColorObject(), (int) (100 * scale)));
                    Render3DEngine.drawBoxOutline(box,
                            renderLineColor.getValue().getColorObject(),
                            renderLineWidth.getValue());
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.sequentialBlocks.clear();
        this.renderPoses.clear();
    }

    @EventHandler
    public void onTick(EventTick e) {
        BlockPos targetBlock = this.getSequentialPos();
        if (targetBlock == null) return;
        if (this.delay > 0) {
            this.delay--;
            return;
        }

        InventoryUtility.saveSlot();

        if (placeTiming.getValue() == PlaceTiming.Default) {
            for (int placed = 0; placed < blocksPerTick.getValue(); placed++) {
                BlockPos pos = this.getSequentialPos();
                if (pos == null) break;

                if (InteractionUtility.placeBlock(pos, rotate.getValue(), interact.getValue(),
                        placeMode.getValue(), this.getSlot(), false, true)) {
                    this.renderPoses.put(pos, System.currentTimeMillis());
                    this.delay = placeDelay.getValue();
                    inactivityTimer.reset();
                }
            }
        } else if (placeTiming.getValue() == PlaceTiming.Vanilla) {
            if (InteractionUtility.placeBlock(targetBlock, rotate.getValue(), interact.getValue(),
                    placeMode.getValue(), this.getSlot(), false, true)) {
                this.sequentialBlocks.add(targetBlock);
                this.renderPoses.put(targetBlock, System.currentTimeMillis());
                this.delay = placeDelay.getValue();
                inactivityTimer.reset();
            }
        }

        InventoryUtility.returnSlot();
    }

    private BlockPos getSequentialPos() {
        if (selfPlace.getValue()) {
            BlockPos playerPos = BlockPos.ofFloored(mc.player.getPos());
            List<BlockPos> positions = List.of(playerPos.down(), playerPos, playerPos.up());

            for (BlockPos pos : positions) {
                List<BlockPos> neighbors = List.of(pos.north(), pos.south(), pos.east(), pos.west(), pos.up(), pos.down());
                for (BlockPos bp : neighbors) {
                    if (InteractionUtility.canPlaceBlock(bp, interact.getValue(), true)
                            && mc.world.getBlockState(bp).isAir()) {
                        return bp;
                    }
                }
            }
            return null;
        }

        PlayerEntity target = Managers.COMBAT.getNearestTarget(range.getValue());
        if (target == null) return null;

        BlockPos targetPos = BlockPos.ofFloored(target.getPos());
        List<BlockPos> positions = new ArrayList<>();

        if (legs.getValue()) positions.add(targetPos);
        if (head.getValue()) positions.add(targetPos.up());
        if (surround.getValue()) {
            positions.add(targetPos.north());
            positions.add(targetPos.south());
            positions.add(targetPos.east());
            positions.add(targetPos.west());
        }
        if (upperSurround.getValue()) {
            positions.add(targetPos.north().up());
            positions.add(targetPos.south().up());
            positions.add(targetPos.east().up());
            positions.add(targetPos.west().up());
        }

        for (BlockPos bp : positions) {
            if (!InteractionUtility.canPlaceBlock(bp, interact.getValue(), true) || !mc.world.getBlockState(bp).isAir())
                continue;
            return bp;
        }
        return null;
    }

    private int getSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack item = mc.player.getInventory().getStack(i);
            if (item.isEmpty() || !(item.getItem() instanceof BlockItem blockItem)) continue;

            Block block = blockItem.getBlock();
            if (blockType.getValue() == BlockType.LEVER && block == Blocks.LEVER) return i;
            if (blockType.getValue() == BlockType.BUTTON && (block == Blocks.STONE_BUTTON || block == Blocks.OAK_BUTTON)) return i;
        }
        return -1;
    }

    public enum BlockType { LEVER, BUTTON }
    public enum PlaceTiming { Default, Vanilla }
    public enum RenderMode { Fade, Decrease }
}