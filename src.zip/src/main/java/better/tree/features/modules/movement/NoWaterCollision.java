package better.tree.features.modules.movement;

import better.tree.features.modules.Module;

public class NoWaterCollision extends Module {
    public NoWaterCollision() {
        super("NoWaterCollision", Category.MOVEMENT);
    }
}