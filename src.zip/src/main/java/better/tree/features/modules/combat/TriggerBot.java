package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import better.tree.core.Managers;
import better.tree.events.impl.PlayerUpdateEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.util.Random;

public final class TriggerBot extends Module {
    public final Setting<Float> range = new Setting<>("Range", 3f, 1f, 6.0f);
    public final Setting<Boolean> onlyCrit = new Setting<>("OnlyCrit", false);
    public final Setting<Boolean> smartCrit = new Setting<>("SmartCrit", true);
    public final Setting<Integer> minDelay = new Setting<>("MinDelay", 2, 0, 20);
    public final Setting<Integer> maxDelay = new Setting<>("MaxDelay", 6, 0, 20);

    private final Random random = new Random();
    private int delayTicks = 0;
    private double prevVerticalSpeed = 0.0;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @EventHandler
    public void onUpdate(PlayerUpdateEvent e) {
        if (mc.player == null || mc.world == null) return;

        double currentVerticalSpeed = mc.player.getVelocity().y;

        if (delayTicks > 0) {
            delayTicks--;
            prevVerticalSpeed = currentVerticalSpeed;
            return;
        }

        Entity target = Managers.PLAYER.getRtxTarget(
                mc.player.getYaw(),
                mc.player.getPitch(),
                range.getValue(),
                false
        );

        if (!(target instanceof LivingEntity living) || !living.isAlive()) return;
        if (Managers.FRIEND.isFriend(living.getName().getString())) return;

        float cd = mc.player.getAttackCooldownProgress(0f);
        boolean crit = canCrit(currentVerticalSpeed);

        if (onlyCrit.getValue() && !crit) {
            prevVerticalSpeed = currentVerticalSpeed;
            return;
        }

        if ((crit || !onlyCrit.getValue()) && cd >= 1f) {
            mc.interactionManager.attackEntity(mc.player, living);
            mc.player.swingHand(Hand.MAIN_HAND);
            delayTicks = random.nextInt(maxDelay.getValue() - minDelay.getValue() + 1) + minDelay.getValue();
        }

        prevVerticalSpeed = currentVerticalSpeed;
    }

    private boolean canCrit(double currentVerticalSpeed) {
        if (!smartCrit.getValue()) {
            return !mc.player.isOnGround() && mc.player.fallDistance > 0.0f;
        }

        boolean justJumped = mc.player.fallDistance > 0.0f && prevVerticalSpeed > 0.0f;

        return !mc.player.isOnGround()
                && mc.player.fallDistance > 0.0f
                && mc.player.fallDistance < 1.2f
                && justJumped;
    }
}
