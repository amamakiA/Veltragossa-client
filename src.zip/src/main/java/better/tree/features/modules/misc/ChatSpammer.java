package better.tree.features.modules.misc;

import better.tree.features.modules.Module;

import java.util.Random;

public class ChatSpammer extends Module {
    private static final int SPAM_INTERVAL_MS = 10_000;
    private static final String SPAM_MESSAGE = "Top Free Client veltragossa dc.gg/amamaki";

    private static final String ALLOWED_CHARS = "ABCDEFGHIJKLMNOPQRSTVWXYZabcdefghijklmnopqrstvwxyz0123456789!@#$%^&*()_-=+[]{}|:;,.<>?";
    private static final int RANDOM_CHARS_COUNT = 2;
    private final Random random = new Random();

    private long lastSpamTime = 0;

    public ChatSpammer() {
        super("ChatSpam", Category.MISC);
    }

    private String getRandomChars() {
        StringBuilder sb = new StringBuilder();
        while (sb.length() < RANDOM_CHARS_COUNT) {
            char c = ALLOWED_CHARS.charAt(random.nextInt(ALLOWED_CHARS.length()));
            if (c != '/') sb.append(c);
        }
        return sb.toString();
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastSpamTime >= SPAM_INTERVAL_MS) {
            String prefix = getRandomChars();
            String suffix = getRandomChars();
            String message = prefix + "  " + SPAM_MESSAGE + "  " + suffix;
            mc.player.networkHandler.sendChatMessage(message);
            lastSpamTime = currentTime;
        }
    }
}