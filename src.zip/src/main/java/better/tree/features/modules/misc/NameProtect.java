package better.tree.features.modules.misc;

import better.tree.features.modules.Module;
import better.tree.setting.Setting;

public class NameProtect extends Module {
    public NameProtect() {
        super("NameProtect",Category.MISC);
    }

    public static Setting<Boolean> hideFriends = new Setting<>("Hide friends", true);
    public static Setting<Boolean> invisible = new Setting<>("Invisible", false);

    public static String getCustomName() {
        if (invisible.getValue()) return " ";
        return "Protected";
    }
}