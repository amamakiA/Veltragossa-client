package better.tree.features.modules.player;

import better.tree.features.modules.Module;

public class PortalInventory extends Module {
    public PortalInventory() {
        super("PortalInventory", Category.PLAYER);
    }
}