package better.tree.features.modules.movement;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import better.tree.events.impl.EventSync;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.player.InventoryUtility;
import better.tree.utility.player.SearchInvResult;
import better.tree.utility.player.InteractionUtility;

public class AutoMLG extends Module {
    public enum MLGMode { Water, Cobweb, PowderSnow, Vines, Fake }

    private final Setting<MLGMode> mode = new Setting<>("Mode", MLGMode.Water);
    private final Setting<Boolean> retrieve = new Setting<>("Retrieve", true, v -> mode.is(MLGMode.Water));

    private boolean retrieveFlag;

    public AutoMLG() {
        super("AutoMLG", Category.MOVEMENT);
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (fullNullCheck()) return;

        if (mc.player.fallDistance > 3 && !mc.player.isFallFlying() && !mc.player.isTouchingWater()) {
            BlockPos playerPos = BlockPos.ofFloored(mc.player.getPos());

            switch (mode.getValue()) {
                case Water -> doWaterMLG(playerPos);
                case Cobweb -> doCobwebMLG(playerPos);
                case PowderSnow -> doSnowMLG(playerPos);
                case Vines -> doVinesMLG(playerPos);
                case Fake -> sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
            }
        } else if (retrieveFlag) {

            if (mode.is(MLGMode.Water)) {
                SearchInvResult bucketResult = InventoryUtility.findItemInHotBar(Items.BUCKET);
                if (bucketResult.found()) {
                    InventoryUtility.saveSlot();
                    bucketResult.switchTo();

                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                    mc.player.swingHand(Hand.MAIN_HAND);

                    InventoryUtility.returnSlot();
                    retrieveFlag = false;
                }
            }
        }
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (mc.player.isOnGround()) {
            retrieveFlag = false;
        }
    }

    private void doWaterMLG(BlockPos pos) {
        SearchInvResult water = InventoryUtility.findItemInHotBar(Items.WATER_BUCKET);
        if (!water.found()) return;

        mc.player.setPitch(90);
        InventoryUtility.saveSlot();
        water.switchTo();

        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);

        InventoryUtility.returnSlot();
        retrieveFlag = retrieve.getValue();
    }

    private void doCobwebMLG(BlockPos pos) {
        SearchInvResult web = InventoryUtility.findItemInHotBar(Items.COBWEB);
        if (!web.found()) return;

        mc.player.setPitch(90);
        InventoryUtility.saveSlot();
        InteractionUtility.placeBlock(pos.down(), InteractionUtility.Rotate.None, InteractionUtility.Interact.Vanilla, InteractionUtility.PlaceMode.Normal, web.slot(), false, true);
        mc.player.swingHand(Hand.MAIN_HAND);
        InventoryUtility.returnSlot();
    }

    private void doSnowMLG(BlockPos pos) {
        SearchInvResult snow = InventoryUtility.findItemInHotBar(Items.POWDER_SNOW_BUCKET);
        if (!snow.found()) return;

        mc.player.setPitch(90);
        InventoryUtility.saveSlot();
        InteractionUtility.placeBlock(pos.down(), InteractionUtility.Rotate.None, InteractionUtility.Interact.Vanilla, InteractionUtility.PlaceMode.Normal, snow.slot(), false, true);
        mc.player.swingHand(Hand.MAIN_HAND);
        InventoryUtility.returnSlot();
    }

    private void doVinesMLG(BlockPos pos) {
        SearchInvResult vines = InventoryUtility.findItemInHotBar(Items.TWISTING_VINES);
        if (!vines.found()) return;

        mc.player.setPitch(90);
        InventoryUtility.saveSlot();
        InteractionUtility.placeBlock(pos.down(), InteractionUtility.Rotate.None, InteractionUtility.Interact.Vanilla, InteractionUtility.PlaceMode.Normal, vines.slot(), false, true);
        mc.player.swingHand(Hand.MAIN_HAND);
        InventoryUtility.returnSlot();
    }
}