package better.tree.features.modules.misc;

import better.tree.veltragossa;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import better.tree.events.impl.EventDeath;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.utility.Timer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class KillMsg extends Module {

    private final Setting<Boolean> enableKillMsg = new Setting<>("EnableKillMsg", true);
    private final Setting<String> msgTemplate = new Setting<>("MsgTemplate", "L dc.gg/amamaki VELTRAGOSSA Najlepszy Darmowy Client LLL");

    private final Setting<Boolean> repeatMsg = new Setting<>("RepeatMsg", false);
    private final Setting<Integer> repeatTimes = new Setting<>("RepeatTimes", 1, 1, 10, v -> repeatMsg.getValue());
    private final Setting<Integer> repeatInterval = new Setting<>("RepeatInterval", 500, 100, 5000, v -> repeatMsg.getValue());

    private final Setting<Boolean> randomMsg = new Setting<>("RandomMsg", false);
    private final Setting<Integer> randomInterval = new Setting<>("RandomInterval", 5000, 1000, 30000, v -> randomMsg.getValue());

    private final Timer repeatTimer = new Timer();
    private final Timer randomTimer = new Timer();
    private int repeatIndex = 0;
    private String pendingCommand;

    private final Map<UUID, Boolean> deathMap = new HashMap<>();

    public KillMsg() {
        super("KillMsg", Category.MISC);
    }

    @EventHandler
    public void onPlayerDeath(EventDeath event) {
        if (!enableKillMsg.getValue()) return;

        PlayerEntity player = event.getPlayer();
        if (player instanceof ClientPlayerEntity) return;

        String playerName = player.getName().getString();
        String command = "/" + "msg " + playerName + " " + msgTemplate.getValue();

        sendChatCommand(command);
        mc.getNetworkHandler().sendChatCommand(command.replaceFirst("/", ""));

        if (repeatMsg.getValue()) {
            repeatIndex = 1;
            pendingCommand = command;
            repeatTimer.reset();
        }
    }

    @Override
    public void onUpdate() {
        if (!enableKillMsg.getValue()) return;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;

            boolean wasDead = deathMap.getOrDefault(player.getUuid(), false);
            boolean isDead = player.isDead();

            if (!wasDead && isDead) {
                veltragossa.EVENT_BUS.post(new EventDeath(player));
            }

            deathMap.put(player.getUuid(), isDead);
        }

        if (repeatMsg.getValue() && repeatIndex > 0 && repeatIndex < repeatTimes.getValue()) {
            if (repeatTimer.passedMs(repeatInterval.getValue())) {
                sendChatCommand(pendingCommand);
                repeatIndex++;
                repeatTimer.reset();
            }
        }

        if (randomMsg.getValue() && randomTimer.passedMs(randomInterval.getValue())) {
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player == mc.player || player.isDead() || !player.isAlive()) continue;

                String randomCommand = "msg " + player.getName().getString() + " " + msgTemplate.getValue();
                sendChatCommand(randomCommand);
                randomTimer.reset();
                break;
            }
        }
    }

    public void sendChatCommand(String command) {
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand(command);
        }
    }
}