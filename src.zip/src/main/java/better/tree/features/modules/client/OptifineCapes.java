package better.tree.features.modules.client;

import better.tree.features.modules.Module;

public final class OptifineCapes extends Module {
    public OptifineCapes() {
        super("OptifineCapes", Category.CLIENT);
    }
}