package better.tree.features.modules.client;

import meteordevelopment.orbit.EventHandler;
import org.jetbrains.annotations.NotNull;
import better.tree.core.Managers;
import better.tree.events.impl.EventAttack;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.core.manager.client.ModuleManager;

public final class SoundFX extends Module {
    public SoundFX() {
        super("SoundFX", Category.CLIENT);
    }

    public final Setting<Integer> volume = new Setting<>("Volume", 100, 0, 100);
    public final Setting<OnOffSound> enableMode = new Setting<>("EnableMode", OnOffSound.Enable4);
    public final Setting<OnOffSound> disableMode = new Setting<>("DisableMode", OnOffSound.Disable4);
    public final Setting<HitSound> hitSound = new Setting<>("HitSound", HitSound.OFF);
    public final Setting<Boolean> critSound = new Setting<>("CritSound", false);
    public final Setting<KillSound> killSound = new Setting<>("KillSound", KillSound.OFF);
    public final Setting<ScrollSound> scrollSound = new Setting<>("ScrollSound", ScrollSound.KeyBoard);

    @EventHandler
    @SuppressWarnings("unused")
    public void onAttack(@NotNull EventAttack event) {
        if (!event.isPre()) {
            boolean isCrit = critSound.getValue() && (mc.player.fallDistance > 0 || ModuleManager.criticals.isEnabled());

            if (isCrit) {
                Managers.SOUND.playCritSound();
            } else {
                Managers.SOUND.playHitSound(hitSound.getValue());
            }
        }
    }

        public enum OnOffSound {
        Custom, Inertia, Enable1, Enable2, Enable3,Enable4, Disable1, Disable2, Disable3,Disable4, OFF,
    }

    public enum HitSound {
        UWU, MOAN, SKEET, RIFK, KEYBOARD, CUTIE,OUH, CUSTOM, TF2, OFF
    }

    public enum KillSound {
        Custom, OFF,
    }

    public enum ScrollSound {
        Custom, OFF, KeyBoard
    }
}