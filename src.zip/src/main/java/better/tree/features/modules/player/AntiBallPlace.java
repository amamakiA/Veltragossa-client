package better.tree.features.modules.player;

import better.tree.features.modules.Module;
public class AntiBallPlace extends Module {
    public AntiBallPlace() {
        super("AntiBallPlace", Category.PLAYER);
    }
}