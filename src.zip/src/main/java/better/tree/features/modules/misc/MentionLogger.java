package better.tree.features.modules.misc;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import better.tree.core.Managers;
import better.tree.core.manager.client.ConfigManager;
import better.tree.gui.notification.Notification;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class MentionLogger extends Module {
    private final Setting<Boolean> useOwnName = new Setting<>("UseOwnName", true);
    private final Setting<String> customText = new Setting<>("CustomText", "Zelek5351");
    private final Setting<Boolean> sound = new Setting<>("Sound", true);
    private final Setting<Boolean> saveToFile = new Setting<>("SaveToFile", false);

    public MentionLogger() {
        super("MentionLogger", Category.MISC);
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        if (!(event.getPacket() instanceof ChatMessageS2CPacket packet)) return;

        Text messageContent = packet.unsignedContent();
        if (messageContent == null) {
            messageContent = Text.of(packet.body().content());
        }

        String message = messageContent.getString();
        String textToWatch = useOwnName.getValue() ? mc.player.getName().getString() : customText.getValue();

        if (message.contains(textToWatch)) {
            String log = "Mention detected: \"" + message + "\"";

            Managers.NOTIFICATION.publicity("MentionLogger", log, 5, Notification.Type.INFO);
            sendMessage(log);

            if (sound.getValue()) {
                mc.world.playSound(mc.player, mc.player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1f, 1f);
            }

            if (saveToFile.getValue()) {
                String serverIP = "unknown_server";
                if (mc.getNetworkHandler().getServerInfo() != null && mc.getNetworkHandler().getServerInfo().address != null) {
                    serverIP = mc.getNetworkHandler().getServerInfo().address.replace(':', '_');
                }

                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter(new File(ConfigManager.STASHLOGGER_FOLDER, serverIP + "_mentions.txt"), true));
                    writer.append("\n" + log);
                    writer.close();
                } catch (Exception ignored) {}
            }
        }
    }
}