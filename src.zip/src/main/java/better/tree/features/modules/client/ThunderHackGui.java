package better.tree.features.modules.client;

import better.tree.gui.thundergui.ThunderGui;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;

import java.awt.*;

public final class ThunderHackGui extends Module {
    public static final Setting<ColorSetting> onColor1 = new Setting<>("OnColor1", new ColorSetting(new Color(71, 0, 117, 255).getRGB()));
    public static final Setting<ColorSetting> onColor2 = new Setting<>("OnColor2", new ColorSetting(new Color(32, 1, 96, 255).getRGB()));
    public static final Setting<Float> scrollSpeed = new Setting<>("ScrollSpeed", 1f, 0.1F, 2.0F);

    public ThunderHackGui() {
        super("Second Gui", Category.CLIENT);
    }

    @Override
    public void onEnable() {
        mc.setScreen(ThunderGui.getThunderGui());
        disable();
    }

    public static Color getColorByTheme(int id) {
        return switch (id) {
            case 0 -> new Color(0, 0, 0, 150);
            case 1 -> new Color(0, 0, 0, 200);
            case 2 -> new Color(255, 255, 255);
            case 3, 8 -> new Color(180, 180, 180);
            case 4 -> new Color(0, 0, 0, 200);
            case 5 -> new Color(50, 50, 50, 220);
            case 6 -> new Color(100, 100, 100);
            case 7 -> new Color(0, 0, 0, 200);
            case 9 -> new Color(0, 0, 0, 200);
            default -> new Color(0, 0, 0, 150);
        };
    }
}