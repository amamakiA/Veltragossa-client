package better.tree.features.modules.client;

import org.lwjgl.glfw.GLFW;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.util.HashSet;
import java.util.Set;

public final class ClientSettings extends Module {
    public static Setting<Boolean> futureCompatibility = new Setting<>("FutureCompatibility", false);
    public static Setting<Boolean> customMainMenu = new Setting<>("CustomMainMenu", true);

    public static Setting<Boolean> customPanorama = new Setting<>("CustomPanorama", true);
    public static Setting<Boolean> customLoadingScreen = new Setting<>("CustomLoadingScreen", true);
    public static Setting<Boolean> scaleFactorFix = new Setting<>("ScaleFactorFix", false);
    public static Setting<Float> scaleFactorFixValue = new Setting<>("ScaleFactorFixValue", 2f, 0f, 4f);
    public static Setting<Boolean> renderRotations = new Setting<>("RenderRotations", true);
    public static Setting<Boolean> clientMessages = new Setting<>("ClientMessages", true);
    public static Setting<Boolean> debug = new Setting<>("Debug", false);
    public static Setting<Boolean> customBob = new Setting<>("CustomBob", true);
    public static Setting<Boolean> telemetry = new Setting<>("Telemetry", true);
    public static Setting<Language> language = new Setting<>("Language", Language.ENG);
    public static Setting<String> prefix = new Setting<>("Prefix", "@");
    public static Setting<ClipCommandMode> clipCommandMode = new Setting<>("ClipCommandMode", ClipCommandMode.Matrix);

    private boolean listeningForPrefix = false;

    private final Set<Character> ignoredChars = new HashSet<>();

    public ClientSettings() {
        super("ClientSettings", Category.CLIENT);

        ignoredChars.add('y');
        ignoredChars.add('Y');
    }

    public enum Language {
        RU,
        ENG
    }

    public enum ClipCommandMode {
        Default,
        Matrix
    }

    public static boolean isRu() {
        return language.is(Language.RU);
    }

    @Override
    public boolean isToggleable() {
        return false;
    }

    public void onKeyPress(int keyCode, boolean shift) {
        if (!listeningForPrefix) return;

        char c = getCharFromKeyCode(keyCode, shift);
        if (c != 0 && !ignoredChars.contains(c)) {
            prefix.setValue(String.valueOf(c));
            listeningForPrefix = false;
        }
    }

    private char getCharFromKeyCode(int keyCode, boolean shift) {
        switch (keyCode) {
            case GLFW.GLFW_KEY_GRAVE_ACCENT: return shift ? '~' : '`';
            case GLFW.GLFW_KEY_1: return shift ? '!' : '1';
            case GLFW.GLFW_KEY_2: return shift ? '@' : '2';
            case GLFW.GLFW_KEY_3: return shift ? '#' : '3';
            case GLFW.GLFW_KEY_4: return shift ? '$' : '4';
            case GLFW.GLFW_KEY_5: return shift ? '%' : '5';
            case GLFW.GLFW_KEY_6: return shift ? '^' : '6';
            case GLFW.GLFW_KEY_7: return shift ? '&' : '7';
            case GLFW.GLFW_KEY_8: return shift ? '*' : '8';
            case GLFW.GLFW_KEY_9: return shift ? '(' : '9';
            case GLFW.GLFW_KEY_0: return shift ? ')' : '0';
            case GLFW.GLFW_KEY_MINUS: return shift ? '_' : '-';
            case GLFW.GLFW_KEY_EQUAL: return shift ? '+' : '=';
            case GLFW.GLFW_KEY_LEFT_BRACKET: return shift ? '{' : '[';
            case GLFW.GLFW_KEY_RIGHT_BRACKET: return shift ? '}' : ']';
            case GLFW.GLFW_KEY_BACKSLASH: return shift ? '|' : '\\';
            case GLFW.GLFW_KEY_SEMICOLON: return shift ? ':' : ';';
            case GLFW.GLFW_KEY_APOSTROPHE: return shift ? '"' : '\'';
            case GLFW.GLFW_KEY_COMMA: return shift ? '<' : ',';
            case GLFW.GLFW_KEY_PERIOD: return shift ? '>' : '.';
            case GLFW.GLFW_KEY_SLASH: return shift ? '?' : '/';
            case GLFW.GLFW_KEY_SPACE: return ' ';
            default:
                if (keyCode >= GLFW.GLFW_KEY_A && keyCode <= GLFW.GLFW_KEY_Z) {
                    char c = (char) ('a' + (keyCode - GLFW.GLFW_KEY_A));
                    return shift ? Character.toUpperCase(c) : c;
                }
                return 0;
        }
    }

    public void startListeningForPrefix() {
        listeningForPrefix = true;
    }
}