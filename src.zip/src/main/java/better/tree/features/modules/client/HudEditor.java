package better.tree.features.modules.client;

import better.tree.gui.hud.HudEditorGui;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;

public final class HudEditor extends Module {
    public static final Setting<HudStyle> hudStyle = new Setting<>("HudStyle", HudStyle.Glowing);

    public static final Setting<Boolean> sticky = new Setting<>("Sticky", true);
    public static final Setting<ArrowsStyle> arrowsStyle = new Setting<>("ArrowsStyle", ArrowsStyle.New);
    public static final Setting<ClickGui.colorModeEn> colorMode = new Setting<>("ColorMode", ClickGui.colorModeEn.Static);
    public static final Setting<Integer> colorSpeed = new Setting<>("ColorSpeed", 18, 2, 54);
    public static final Setting<Boolean> glow = new Setting<>("Light", true);
    public static final Setting<ColorSetting> captureColor = new Setting<>("CaptureColor", new ColorSetting(new Color(0xFFFFFFFF, true).getRGB()));

    public static final Setting<ColorSetting> hcolor1 = new Setting<>("Color", new ColorSetting(-6974059));
    public static final Setting<ColorSetting> acolor = new Setting<>("Color2", new ColorSetting(-8365735));
    public static final Setting<ColorSetting> plateColor = new Setting<>("PlateColor", new ColorSetting(new Color(0xE7000000, true).getRGB()));
    public static final Setting<ColorSetting> textColor = new Setting<>("TextColor", new ColorSetting(new Color(0xFFFFFFFF, true).getRGB()));
    public static final Setting<ColorSetting> textColor2 = new Setting<>("TextColor2", new ColorSetting(new Color(0xFFFFFFFF, true).getRGB()));
    public static final Setting<ColorSetting> blurColor = new Setting<>("BlurColor", new ColorSetting(new Color(0xFF000E25, true).getRGB()));
    public static final Setting<Float> hudRound = new Setting<>("HudRound", 4f, 1f, 7f);
    public static final Setting<Float> alpha = new Setting<>("Alpha", 0.66f, 0f, 1f);
    public static final Setting<Float> blend = new Setting<>("Blend", 10f, 1f, 15f);
    public static final Setting<Float> outline = new Setting<>("Outline", 0.5f, 0f, 2.5f);
    public static final Setting<Float> glow1 = new Setting<>("Glow", 0.5f, 0f, 1f);
    public static final Setting<Float> blurOpacity = new Setting<>("BlurOpacity", 0.55f, 0f, 1f);
    public static final Setting<Float> blurStrength = new Setting<>("BlurStrength", 20f, 5f, 50f);

    public HudEditor() {
        super("HudEditor", Module.Category.CLIENT);
    }

    public static Color getColor(int count) {
        return switch (colorMode.getValue()) {
            case Sky -> Render2DEngine.skyRainbow(colorSpeed.getValue(), count);
            case LightRainbow -> Render2DEngine.rainbow(colorSpeed.getValue(), count, .6f, 1, 1);
            case Rainbow -> Render2DEngine.rainbow(colorSpeed.getValue(), count, 1f, 1, 1);
            case Fade -> Render2DEngine.fade(colorSpeed.getValue(), count, hcolor1.getValue().getColorObject(), 1);
            case DoubleColor ->
                    Render2DEngine.TwoColoreffect(hcolor1.getValue().getColorObject(), acolor.getValue().getColorObject(), colorSpeed.getValue(), count);
            case Analogous ->
                    Render2DEngine.interpolateColorsBackAndForth(colorSpeed.getValue(), count, hcolor1.getValue().getColorObject(), Render2DEngine.getAnalogousColor(acolor.getValue().getColorObject()), true);
            case Pulsing -> Render2DEngine.fade(colorSpeed.getValue(), count, hcolor1.getValue().getColorObject(), 1);
            case Wave -> Render2DEngine.interpolateColorsBackAndForth(colorSpeed.getValue(), count, hcolor1.getValue().getColorObject(), Render2DEngine.darker(hcolor1.getValue().getColorObject(), 0.6f), false);
            case Spectrum -> Render2DEngine.rainbow(colorSpeed.getValue(), count, 1f, 1, 1);
            case Pastel -> Render2DEngine.rainbow(colorSpeed.getValue(), count, 0.5f, 0.8f, 1);
            case Neon -> Render2DEngine.rainbow(colorSpeed.getValue(), count, 1f, 1f, 1);
            case Metallic -> Render2DEngine.TwoColoreffect(new Color(211, 211, 211), new Color(169, 169, 169), colorSpeed.getValue(), count);
            case Gradient -> Render2DEngine.interpolateColorsBackAndForth(colorSpeed.getValue(), count, hcolor1.getValue().getColorObject(), acolor.getValue().getColorObject(), false);
            case Chrome -> Render2DEngine.TwoColoreffect(new Color(255, 255, 255), new Color(200, 200, 200), colorSpeed.getValue(), count);
            case Ocean -> Render2DEngine.interpolateColorsBackAndForth(colorSpeed.getValue(), count, new Color(0, 102, 204), new Color(0, 153, 255), false);
            case Forest -> Render2DEngine.interpolateColorsBackAndForth(colorSpeed.getValue(), count, new Color(0, 102, 0), new Color(0, 153, 0), false);
            default -> hcolor1.getValue().getColorObject();
        };
    }

    public static HudStyle getHudStyle() {
        return HudStyle.Glowing;
    }

    @Override
    public void onEnable() {
        mc.setScreen(HudEditorGui.getHudGui());
        disable();
    }

    public enum ArrowsStyle {
        Default, New
    }

    public enum HudStyle {
        Blurry, Glowing
    }
    }