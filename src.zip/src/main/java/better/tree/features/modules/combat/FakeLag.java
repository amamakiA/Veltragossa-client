package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.PacketEvent;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.Timer;
import better.tree.utility.player.PlayerEntityCopy;
import better.tree.utility.render.Render3DEngine;

import java.awt.*;
import java.util.ArrayList;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class FakeLag extends Module {
    private final Setting<Integer> pulseLength = new Setting<>("PulseLength", 2, 1, 7);
    private final Setting<Integer> pulseDelay = new Setting<>("PulseDelay", 2, 1, 5);
    private final Setting<Boolean> render = new Setting<>("Render", true);
    private final Setting<RenderMode> renderMode = new Setting<>("Render Mode", RenderMode.Box, value -> render.getValue());
    private final Setting<ColorSetting> circleColor = new Setting<>("Color", new ColorSetting(0xFFda6464), value -> render.getValue() && (renderMode.getValue() == RenderMode.Circle || renderMode.getValue() == RenderMode.Box || renderMode.getValue() == RenderMode.all));
    private final Setting<Boolean> coloredBox = new Setting<>("ColoredBox", true, value -> false);

    private enum RenderMode { Circle, Model, Box, all }

    private final Timer pulseTimer = new Timer();
    private final Queue<Packet<?>> storedPackets = new ConcurrentLinkedQueue<>();
    private boolean isLagging = false;
    private PlayerEntityCopy blinkPlayer;
    private Vec3d lastPos = Vec3d.ZERO;
    private final AtomicBoolean sending = new AtomicBoolean(false);

    public FakeLag() {
        super("FakeLag", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        isLagging = false;
        storedPackets.clear();
        pulseTimer.reset();

        if(mc.player != null) {
            lastPos = mc.player.getPos();

            if (renderMode.getValue() == RenderMode.Model || renderMode.getValue() == RenderMode.all) {
                blinkPlayer = new PlayerEntityCopy();
                blinkPlayer.spawn();
            }
        }
    }

    @Override
    public void onDisable() {
        sendPackets();
        if (blinkPlayer != null) {
            blinkPlayer.deSpawn();
            blinkPlayer = null;
        }
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send event) {
        if (mc.player == null || mc.world == null || sending.get()) {
            return;
        }

        if (isLagging) {
            if (event.getPacket() instanceof PlayerMoveC2SPacket) {
                event.cancel();
                storedPackets.add(event.getPacket());
            } else if (event.getPacket() instanceof PlayerInteractEntityC2SPacket) {
                sendPackets();
            }
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket vel && vel.getId() == mc.player.getId()) {
            sendPackets();
            isLagging = false;
            pulseTimer.reset();
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) {
            disable();
            return;
        }

        if (pulseTimer.passedMs((pulseLength.getValue() + pulseDelay.getValue()) * 50L)) {
            pulseTimer.reset();
        }

        if (pulseTimer.passedMs(pulseDelay.getValue() * 50L)) {
            if (!isLagging) {
                isLagging = true;
                lastPos = mc.player.getPos();

                if (renderMode.getValue() == RenderMode.Model || renderMode.getValue() == RenderMode.all) {
                    if(blinkPlayer != null) blinkPlayer.deSpawn();
                    blinkPlayer = new PlayerEntityCopy();
                    blinkPlayer.spawn();
                }
            }
        } else {
            if (isLagging) {
                sendPackets();
                isLagging = false;
            }
        }
    }

    private void sendPackets() {
        if(sending.get()) return;
        sending.set(true);
        while (!storedPackets.isEmpty()) {
            sendPacket(storedPackets.poll());
        }
        sending.set(false);
    }

    @Override
    public void onRender3D(MatrixStack stack) {
        if (mc.player == null || mc.world == null) return;

        if (render.getValue() && lastPos != null && isLagging) {
            if (renderMode.getValue() == RenderMode.Circle || renderMode.getValue() == RenderMode.all) {
                Color color = circleColor.getValue().getColorObject();
                ArrayList<Vec3d> vecs = new ArrayList<>();
                double x = lastPos.x;
                double y = lastPos.y;
                double z = lastPos.z;

                for (int i = 0; i <= 360; ++i) {
                    Vec3d vec = new Vec3d(x + Math.sin((double) i * Math.PI / 180.0) * 0.5D, y + 0.01, z + Math.cos((double) i * Math.PI / 180.0) * 0.5D);
                    vecs.add(vec);
                }

                for (int j = 0; j < vecs.size() - 1; ++j) {
                    Render3DEngine.drawLine(vecs.get(j), vecs.get(j + 1), color);
                }
            }

            if ((renderMode.getValue() == RenderMode.Box || renderMode.getValue() == RenderMode.all) && coloredBox.getValue()) {
                Color fillColor = new Color(circleColor.getValue().getRed(), circleColor.getValue().getGreen(), circleColor.getValue().getBlue(), 100);
                Box box = new Box(lastPos.x - 0.3, lastPos.y, lastPos.z - 0.3, lastPos.x + 0.3, lastPos.y + 1.8, lastPos.z + 0.3);
                Render3DEngine.drawFilledBox(stack, box, fillColor);
                Render3DEngine.drawBoxOutline(
                        box,
                        circleColor.getValue().getColorObject(), 2f
                );
            }
        }
    }
}
