package better.tree.features.modules.misc;

import better.tree.features.modules.Module;

public class ExtraTab extends Module {
    public ExtraTab() {
        super("ExtraTab", Category.MISC);
    }
}