package better.tree.features.modules.client;

import com.mojang.authlib.minecraft.UserApiService;
import net.minecraft.client.network.SocialInteractionsManager;
import net.minecraft.client.session.ProfileKeys;
import net.minecraft.client.session.Session;
import net.minecraft.client.session.report.AbuseReportContext;
import net.minecraft.client.session.report.ReporterEnvironment;
import net.minecraft.util.Uuids;
import better.tree.features.modules.Module;
import better.tree.injection.accesors.IMinecraftClient;
import better.tree.setting.Setting;

import java.util.Optional;

import static better.tree.features.modules.client.ClientSettings.isRu;

public class CrackNick extends Module {

    public final Setting<String> nickname = new Setting<>("Nickname", "CrackedPlayer");

    private Session originalSession;

    public CrackNick() {
        super("CrackNick", Category.CLIENT);
    }

    @Override
    public void onEnable() {

        originalSession = mc.getSession();

        try {

            Session newSession = new Session(
                    nickname.getValue(),
                    Uuids.getOfflinePlayerUuid(nickname.getValue()),
                    "",
                    Optional.empty(),
                    Optional.empty(),
                    Session.AccountType.MOJANG
            );

            setGameSession(newSession);
            sendMessage((isRu() ? "Aktywowano moduł CrackedNick. Nick zmieniono na: " : "CrackedNick Moduł Włączony. Zmieniono nick na: ") + nickname.getValue());
        } catch (Exception e) {
            sendMessage((isRu() ? "Błąd podczas zmiany nicku! " : "Error while switching nickname! ") + e.getMessage());

            disable();
        }
    }

    @Override
    public void onDisable() {

        if (originalSession != null) {
            setGameSession(originalSession);
            sendMessage((isRu() ? "Wyłączono moduł CrackedNick. Przywrócono oryginalny nick: " : "CrackedNick Modół Wyjebany. Przywrocono oryginalny nick: ") + originalSession.getUsername());
        }
    }

    private void setGameSession(Session session) {
        IMinecraftClient mca = (IMinecraftClient) mc;
        mca.setSessionT(session);
        mc.getGameProfile().getProperties().clear();

        UserApiService apiService = UserApiService.OFFLINE;
        mca.setUserApiService(apiService);

        mca.setSocialInteractionsManagerT(new SocialInteractionsManager(mc, apiService));
        mca.setProfileKeys(ProfileKeys.create(apiService, session, mc.runDirectory.toPath()));

        mca.setAbuseReportContextT(AbuseReportContext.create(ReporterEnvironment.ofIntegratedServer(), apiService));
    }
}