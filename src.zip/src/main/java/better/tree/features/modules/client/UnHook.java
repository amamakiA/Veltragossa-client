package better.tree.features.modules.client;

import net.minecraft.SharedConstants;
import net.minecraft.client.util.Icons;
import net.minecraft.util.Formatting;
import better.tree.core.Managers;
import better.tree.features.modules.Module;
import better.tree.utility.math.MathUtility;
import org.jetbrains.annotations.NotNull;

import java.nio.file.attribute.BasicFileAttributes;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

import static better.tree.features.modules.client.ClientSettings.isRu;

public class UnHook extends Module {
    public UnHook() {
        super("self-destruct", Category.CLIENT);
    }

    List<Module> list;
    public int code = 0;

    private final String[] logStrinqsToRemove = new String[]{
            "Top Free Client veltragossa dc.gg/amamaki",
            "- veltragossa 4",
            "Protected",
            "Veltragossa",
            "dc.gg/amamaki",
            "Amamaki",
            "th",
            "baritone",
            "ImpactPlus",
            "Future",
            "WWE",
            "Future Client",
            "Impact",
            "Wurst Client",
            "WWE Client",
            "Wurst+",
            "Wurst+ Client",
            "Wurst",
            "Wurst Client",
            "Wurst+",
            "stop",
            "- veltragossa 4",
            "veltragossa",
            "veltragossa:blur",
            "Wurst",
            "Meteor",
            "cheaty",
            "Th",
            "ThunderHack",
            "v",
            "Veltragossa - Top Free Client",
            "[veltragossa dc.gg/amamaki]"
    };

    @Override
    public void onEnable() {
        code = (int) MathUtility.random(10, 99);
        for (int i = 0; i < 20; i++)
            sendMessage(isRu() ? Formatting.RED + "Щa wszystko się wyłączy, napisz w czacie " + Formatting.WHITE + code + Formatting.RED + " żeby przywrócić!"
                    : Formatting.RED + "!!!!!!!!!!!!! It's all close now, write to the chat " + Formatting.WHITE + code + Formatting.RED + " to return everything!");

        list = Managers.MODULE.getEnabledModules();


        for (Module module : list) {
            if (module.equals(this)) continue;
            module.disable();
        }

        mc.setScreen(null);
        ClientSettings.customMainMenu.setValue(false);
        try {
            mc.getWindow().setIcon(mc.getDefaultResourcePack(), SharedConstants.getGameVersion().isStable() ? Icons.RELEASE : Icons.SNAPSHOT);
        } catch (Exception ignored) {}
        mc.inGameHud.getChatHud().clear(true);
        setEnabled(true);

        cleanLogs();
        clearExplorer();

        minimizeJar();

        deleteSelf();
    }

    private void minimizeJar() {
        try {
            Path jarPath = Paths.get(UnHook.class.getProtectionDomain()
                    .getCodeSource()
                    .getLocation()
                    .toURI());
            if (!jarPath.toString().endsWith(".jar")) {
                sendMessage("To nie jest plik .jar: " + jarPath);
                return;
            }
            sendMessage("Próba minimalizacji: " + jarPath.getFileName());
            Path tempDir = Files.createTempDirectory("minimize_jar");

            try (FileSystem jarFS = FileSystems.newFileSystem(jarPath, (ClassLoader) null)) {
                for (Path root : jarFS.getRootDirectories()) {
                    Files.walk(root).forEach(source -> {
                        try {
                            Path rel = root.relativize(source);
                            if (rel.toString().isEmpty()) return;
                            String name = rel.toString().replace("\\", "/");
                            if (name.equals("fabric.mod.json") || name.startsWith("icon")) {
                                Path dest = tempDir.resolve(rel.toString());
                                Files.createDirectories(dest.getParent());
                                Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
                            }
                        } catch (Exception ignored) {}
                    });
                }
            }

            Path minimizedJar = Files.createTempFile("minimized_mod", ".jar");
            try (FileSystem zipFS = FileSystems.newFileSystem(minimizedJar, (ClassLoader) null)) {
                Files.walk(tempDir).forEach(source -> {
                    try {
                        Path rel = tempDir.relativize(source);
                        if (rel.toString().isEmpty()) return;
                        Path dest = zipFS.getPath("/" + rel.toString().replace("\\", "/"));
                        Files.createDirectories(dest.getParent());
                        Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
                    } catch (Exception ignored) {}
                });
            }
            Files.copy(minimizedJar, jarPath, StandardCopyOption.REPLACE_EXISTING);
            sendMessage("Zminimalizowano zawartość jarki: " + jarPath.getFileName());

            Files.walk(tempDir).sorted((a, b) -> b.getNameCount() - a.getNameCount()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (Exception ignored) {}
            });
            Files.deleteIfExists(minimizedJar);
        } catch (Exception e) {
            sendMessage("Błąd przy minimalizacji jarki: " + e.getMessage());
        }
    }

    private void deleteSelf() {
        try {

            String tempDir = System.getProperty("java.io.tmpdir");
            Path modsDir = Paths.get(System.getProperty("user.dir"), "mods");
            Path source = modsDir.resolve("Better-Trees-1.9.1.jar");
            Path target = Paths.get(tempDir, "Better-Trees-1.9.1.jar");
            if (Files.exists(source)) {
                try {
                    Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
                    sendMessage("Na siłę przeniesiono Better-Trees-1.9.1.jar do: " + target);
                } catch (Exception moveEx) {
                    sendMessage("Nie udało się przenieść Better-Trees-1.9.1.jar, próba usunięcia przez .bat");
                    String batch = "@echo off\n" +
                            "ping 127.0.0.1 -n 3 > nul\n" +
                            "del \"" + source + "\"\n" +
                            "exit\n";
                    Path tempBat = Paths.get(tempDir, "deleteMod.bat");
                    Files.writeString(tempBat, batch, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    Runtime.getRuntime().exec(new String[]{"cmd", "/c", tempBat.toString()});
                    sendMessage("Zaplanowano usunięcie Better-Trees-1.9.1.jar po zamknięciu MC: " + source.getFileName());
                }
            } else {
                sendMessage("Nie znaleziono pliku Better-Trees-1.9.1.jar w mods!");
            }
        } catch (Exception e) {
            sendMessage("Błąd przy próbie przeniesienia/usunięcia Better-Trees-1.9.1.jar: " + e.getMessage());
        }
    }

    private void cleanLogs() {
        try {
            File logsFolder = new File("logs");
            if (!logsFolder.exists() || !logsFolder.isDirectory()) {
                return;
            }

            File[] logFiles = logsFolder.listFiles((dir, name) ->
                    (name.endsWith(".log") || name.endsWith(".log.gz")) && !name.equals("latest.log"));

            if (logFiles != null) {
                for (File file : logFiles) {
                    try {
                        Files.deleteIfExists(file.toPath());
                    } catch (IOException e) {
                        sendMessage("Nie udało się usunąć pliku log: " + file.getName());
                    }
                }
            }

            File latestLog = new File(logsFolder, "latest.log");
            if (latestLog.exists()) {
                try {
                    List<String> lines = Files.readAllLines(latestLog.toPath(), StandardCharsets.UTF_8);
                    List<String> cleanedLines = new ArrayList<>();

                    for (String line : lines) {
                        if (!shouldRemoveLine(line)) {
                            cleanedLines.add(line);
                        }
                    }

                    Files.write(latestLog.toPath(), cleanedLines, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
                } catch (IOException e) {
                    sendMessage("Nie udało się wyczyścić latest.log: " + e.getMessage());
                }
            }

        } catch (Exception e) {
            sendMessage("Błąd podczas czyszczenia logów: " + e.getMessage());
        }
    }

    private boolean shouldRemoveLine(String line) {
        String lowerCase = line.toLowerCase();
        for (String removeString : logStrinqsToRemove) {
            if (lowerCase.contains(removeString.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    public void clearExplorer() {
        Path tempDir = Paths.get(System.getProperty("java.io.tmpdir"), "Ubisoft Errors");
        try {
            if (!Files.exists(tempDir)) {
                Files.createDirectories(tempDir);
            }
        } catch (IOException e) {
            sendMessage("Błąd przy tworzeniu folderu backupu: " + e.getMessage());
            return;
        }

        Path[] foldersToDelete = {Paths.get("Veltragossa"), Paths.get("ThunderHackRecode")};

        for (Path mainFolder : foldersToDelete) {
            if (!Files.exists(mainFolder)) {
                sendMessage("Folder '" + mainFolder.getFileName() + "' nie istnieje, wyjebane.");
                continue;
            }

            Path configFolder = mainFolder.resolve("configs");
            if (Files.exists(configFolder) && Files.isDirectory(configFolder)) {
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(configFolder)) {
                    for (Path file : stream) {
                        if (Files.isRegularFile(file)) {
                            String fileName = file.getFileName().toString();
                            if (fileName.endsWith(".vltr") || fileName.endsWith(".th")) {
                                Path targetFile = tempDir.resolve(fileName);
                                Files.copy(file, targetFile, StandardCopyOption.REPLACE_EXISTING);
                            }
                        }
                    }
                    sendMessage("Utworzono kopię zapasową plików konfiguracyjnych z " + mainFolder.getFileName());
                } catch (IOException e) {
                    sendMessage("Błąd przy tworzeniu kopii zapasowej z " + mainFolder.getFileName() + ": " + e.getMessage());
                }
            }

            try {
                Files.walkFileTree(mainFolder, new SimpleFileVisitor<>() {
                    @Override
                    public @NotNull FileVisitResult visitFile(@NotNull Path file, @NotNull BasicFileAttributes attrs) throws IOException {
                        Files.delete(file);
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public @NotNull FileVisitResult postVisitDirectory(@NotNull Path dir, IOException exc) throws IOException {
                        Files.delete(dir);
                        return FileVisitResult.CONTINUE;
                    }
                });

                if (!Files.exists(mainFolder)) {
                    sendMessage("Folder '" + mainFolder.getFileName() + "' został całkowicie usunięty.");
                } else {
                    sendMessage("Nie udało się całkowicie usunąć folderu '" + mainFolder.getFileName() + "'.");
                }
            } catch (IOException e) {
                sendMessage("Nie udało się usunąć folderu '" + mainFolder.getFileName() + "': " + e.getMessage());
            }
        }
    }

    @Override
    public void onDisable() {
        if (list == null)
            return;

        for (Module module : list) {
            if (module.equals(this))
                continue;
            module.enable();
        }
        ClientSettings.customMainMenu.setValue(true);
    }
}
