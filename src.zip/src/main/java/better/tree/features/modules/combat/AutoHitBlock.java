package better.tree.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import better.tree.events.impl.EventTick;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;

import java.util.List;

public class AutoHitBlock extends Module {

    public AutoHitBlock() {
        super("AutoHitBlock", Category.COMBAT);
    }

        private final Setting<Float> triggerRadius = new Setting<>("TriggerRadius", 3.2f, 0.1f, 5.0f);

        private boolean shieldActive = false;

        @EventHandler
        public void handleTick(EventTick event) {
            if (mc.player == null || mc.world == null) return;

            if (!hasShieldEquipped()) {
                deactivateShield();
                return;
            }

            List<PlayerEntity> threats = mc.world.getEntitiesByClass(PlayerEntity.class, createDetectionBox(triggerRadius.getValue()), this::isHostile);

            boolean dangerDetected = threats.stream().anyMatch(this::isFacingUs);

            if (dangerDetected) {
                activateShield();
            } else {
                deactivateShield();
            }
        }

        private boolean hasShieldEquipped() {
            return mc.player.getMainHandStack().getItem() == Items.SHIELD || mc.player.getOffHandStack().getItem() == Items.SHIELD;
        }

        private boolean isHostile(PlayerEntity entity) {
            return entity != mc.player && entity.isAlive() && !entity.isInvisible();
        }

        private boolean isFacingUs(PlayerEntity entity) {
            Vec3d eyePos = entity.getCameraPosVec(1.0f);
            Vec3d lookDir = entity.getRotationVec(1.0f).normalize();
            Vec3d ourCenter = mc.player.getPos().add(0, mc.player.getHeight() / 2.0, 0);
            Vec3d directionToUs = ourCenter.subtract(eyePos).normalize();

            return lookDir.dotProduct(directionToUs) > 0.906;
        }

        private Box createDetectionBox(float radius) {
            return new Box(
                    mc.player.getX() - radius, mc.player.getY() - 2, mc.player.getZ() - radius,
                    mc.player.getX() + radius, mc.player.getY() + 2, mc.player.getZ() + radius
            );
        }

        private void activateShield() {
            if (!shieldActive) {
                mc.options.useKey.setPressed(true);
                shieldActive = true;
            }
        }

        private void deactivateShield() {
            if (shieldActive) {
                mc.options.useKey.setPressed(false);
                shieldActive = false;
            }
        }

        @Override
        public void onDisable() {
            deactivateShield();
        }
    }