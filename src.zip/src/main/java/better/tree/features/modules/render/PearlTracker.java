package better.tree.features.modules.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.registry.tag.FluidTags;
import better.tree.features.modules.Module;
import better.tree.setting.Setting;
import better.tree.setting.impl.ColorSetting;
import better.tree.utility.render.Render3DEngine;
import better.tree.gui.font.FontRenderers;

import java.awt.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PearlTracker extends Module {
    private final Setting<Float> scale = new Setting<>("Scale", 1.0f, 0.5f, 2.0f);
    private final Setting<ColorSetting> color = new Setting<>("Color", new ColorSetting(new Color(0xFFFFFFFF, true)));

    private final Map<EnderPearlEntity, PearlInfo> pearls = new HashMap<>();

    public PearlTracker() {
        super("PearlTracker", Category.RENDER);
    }

    private static class PearlInfo {
        public final String name;
        public final long startTime;
        public Vec3d landingPos;
        public float estimatedFlight;
        public long landedAt = -1;

        public PearlInfo(String name, long startTime, Vec3d landingPos, float estimatedFlight) {
            this.name = name;
            this.startTime = startTime;
            this.landingPos = landingPos;
            this.estimatedFlight = estimatedFlight;
        }
    }

    @Override
    public void onRender2D(DrawContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();

        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof EnderPearlEntity pearl && !pearls.containsKey(pearl)) {
                if (pearl.getOwner() instanceof AbstractClientPlayerEntity player) {
                    SimulationResult sim = simulatePearl(pearl);
                    if (sim != null) {
                        pearls.put(pearl, new PearlInfo(player.getGameProfile().getName(),
                                System.currentTimeMillis(), sim.pos, sim.flightTime));
                    }
                }
            }
        }

        Iterator<Map.Entry<EnderPearlEntity, PearlInfo>> iterator = pearls.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<EnderPearlEntity, PearlInfo> entry = iterator.next();
            EnderPearlEntity pearl = entry.getKey();
            PearlInfo info = entry.getValue();

            if (!pearl.isAlive() && info.landedAt == -1) {
                info.landedAt = System.currentTimeMillis();
            }

            if (info.landedAt != -1 && System.currentTimeMillis() - info.landedAt > 5000) {
                iterator.remove();
                continue;
            }

            float elapsed = (System.currentTimeMillis() - info.startTime) / 1000f;
            float timeLeft = Math.max(0, info.estimatedFlight - elapsed);

            String text = info.name + " " + String.format("%.1fs", timeLeft);

            Vec3d screenPos = Render3DEngine.worldSpaceToScreenSpace(info.landingPos);
            if (screenPos == null || screenPos.z < 0 || screenPos.z >= 1) continue;

            FontRenderers.sf_bold_mini.drawString(
                    context.getMatrices(),
                    text,
                    (float) screenPos.x,
                    (float) screenPos.y - 10f,
                    color.getValue().getColorObject().getRGB()
            );
        }
    }

    private static class SimulationResult {
        Vec3d pos;
        float flightTime;

        SimulationResult(Vec3d pos, float flightTime) {
            this.pos = pos;
            this.flightTime = flightTime;
        }
    }

    private SimulationResult simulatePearl(EnderPearlEntity pearl) {
        Vec3d pos = pearl.getPos();
        Vec3d vel = pearl.getVelocity();
        float time = 0f;

        for (int i = 0; i < 200; i++) {
            pos = pos.add(vel);
            vel = vel.multiply(0.99).add(0, -0.03, 0);
            time += 0.05f;

            HitResult hit = pearl.getWorld().raycast(new net.minecraft.world.RaycastContext(
                    pos, pos.add(vel),
                    net.minecraft.world.RaycastContext.ShapeType.COLLIDER,
                    net.minecraft.world.RaycastContext.FluidHandling.ANY,
                    pearl
            ));

            if (hit.getType() != HitResult.Type.MISS) {
                return new SimulationResult(hit.getPos(), time);
            }

            BlockPos blockPos = new BlockPos((int) Math.floor(pos.x), (int) Math.floor(pos.y), (int) Math.floor(pos.z));
            if (pearl.getWorld().getFluidState(blockPos).isIn(FluidTags.WATER)) {
                return new SimulationResult(pos, time);
            }
        }

        return null;
    }
}