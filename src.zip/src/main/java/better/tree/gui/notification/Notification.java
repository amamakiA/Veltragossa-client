package better.tree.gui.notification;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Formatting;
import better.tree.features.modules.client.HudEditor;
import better.tree.gui.font.FontRenderers;
import better.tree.utility.Timer;
import better.tree.utility.math.MathUtility;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.animation.EaseOutBack;

import java.awt.*;

import static better.tree.features.modules.Module.mc;

public class Notification {
    private final String message, title;
    private final String icon;
    private final int lifeTime;
    public final EaseOutBack animation;
    private float y, width, animationX, height = 25;
    private boolean direction = false;
    private final Timer timer = new Timer();
    private final Type type;

    public Notification(String title, String message, Type type, int time) {
        lifeTime = time;
        this.title = title;
        this.message = message;
        this.type = type;

        switch (type) {
            case INFO -> icon = "J";
            case ENABLED -> icon = "K";
            case DISABLED, ERROR -> icon = "I";
            case WARNING -> icon = "L";
            case SUCCESS -> icon = "M";
            default -> icon = "H";
        }

        width = FontRenderers.sf_bold_micro.getStringWidth(title + " " + message) + 40f;
        height = 30;

        animation = new EaseOutBack(10);

        animationX = width;
        y = mc.getWindow().getScaledHeight() - height;
    }

    public void render(MatrixStack matrix, float getY) {
        int animatedAlpha = (int) MathUtility.clamp((1 - animation.getAnimationd()) * 255, 0, 255);
        Color textColor = new Color(255, 255, 255, animatedAlpha);
        Color iconColor = new Color(255, 255, 255, animatedAlpha);
        Color backgroundColor = type.getRgbColor();

        direction = isFinished();
        animationX = (float) (width * animation.getAnimationd());
        y = animate(y, getY);
        float x = mc.getWindow().getScaledWidth() - 6 - width + animationX;

        Render2DEngine.drawRound(matrix, x, y, width, height, 8f, Render2DEngine.injectAlpha(backgroundColor, animatedAlpha));
        FontRenderers.mid_icons.drawString(matrix, icon, x + 8, y + height / 2f - FontRenderers.mid_icons.getStringHeight(icon) / 2f + 1, iconColor.getRGB());
        FontRenderers.sf_bold_mini.drawString(matrix, title, x + 25, y + 5, textColor.getRGB());
        FontRenderers.sf_bold_mini.drawString(matrix, message, x + 25, y + 15, textColor.getRGB());
    }

    public void onUpdate() {
        animation.update(direction);
    }

    public void renderShaders(MatrixStack matrix, float getY) {
        direction = isFinished();
        animationX = (float) (width * animation.getAnimationd());
        y = animate(y, getY);
        Render2DEngine.drawHudBase2(matrix, mc.getWindow().getScaledWidth() - 6 - width + animationX,
                y, width, height, 8f, HudEditor.blurStrength.getValue(), HudEditor.blurOpacity.getValue(), (float) MathUtility.clamp((1 - animation.getAnimationd()), 0f, 1f));
    }

    private boolean isFinished() {
        return timer.passedMs(lifeTime);
    }

    public double getHeight() {
        return height;
    }

    public boolean shouldDelete() {
        return isFinished() && animationX >= width - 5;
    }

    public float animate(float value, float target) {
        return value + (target - value) / 8f;
    }

    public enum Type {
        SUCCESS("Success", Formatting.GREEN, new Color(30, 90, 30)),
        INFO("Information", Formatting.AQUA, new Color(30, 60, 90)),
        WARNING("Warning", Formatting.GOLD, new Color(90, 90, 30)),
        ERROR("Error", Formatting.RED, new Color(90, 30, 30)),
        ENABLED("Module enabled", Formatting.DARK_GREEN, new Color(30, 90, 30)),
        DISABLED("Module disabled", Formatting.DARK_RED, new Color(90, 30, 30));

        final String name;
        final Formatting color;
        final Color rgbColor;

        Type(String name, Formatting color, Color rgbColor) {
            this.name = name;
            this.color = color;
            this.rgbColor = rgbColor;
        }

        public String getName() {
            return name;
        }

        public Formatting getColor() {
            return color;
        }

        public Color getRgbColor() {
            return rgbColor;
        }
    }
}