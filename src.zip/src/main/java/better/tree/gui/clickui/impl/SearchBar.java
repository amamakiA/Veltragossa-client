package better.tree.gui.clickui.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.StringHelper;
import org.lwjgl.glfw.GLFW;
import better.tree.veltragossa;
import better.tree.gui.clickui.AbstractButton;
import better.tree.gui.clickui.ClickGUI;
import better.tree.gui.font.FontRenderers;
import better.tree.utility.render.Render2DEngine;

import java.awt.Color;

import static better.tree.features.modules.Module.mc;

public class SearchBar extends AbstractButton {
    public static String moduleName = "";
    public static boolean listening;

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);


        Render2DEngine.drawRound(context.getMatrices(), x + 4, y + 1f, width - 8, height - 2, 3, new Color(30, 30, 30, 200));


        if (!listening && moduleName.isEmpty()) {
            FontRenderers.sf_medium.drawString(context.getMatrices(), "Search...", x + 8f, y + height / 2f - 3, new Color(150, 150, 150).getRGB());
        } else {
            FontRenderers.sf_medium.drawString(context.getMatrices(), moduleName + (mc.player == null || ((mc.player.age / 10) % 2 == 0) ? "" : "_"), x + 8f, y + height / 2f - 3, new Color(220, 220, 220).getRGB());
        }


        if (!moduleName.isEmpty()) {
            drawClearButton(context, x + width - 16, y + height / 2f - 4, mouseX, mouseY);
        }

        if (Render2DEngine.isHovered(mouseX, mouseY, x, y, width, height)) {
            if (GLFW.glfwGetPlatform() != GLFW.GLFW_PLATFORM_WAYLAND) {
                GLFW.glfwSetCursor(mc.getWindow().getHandle(),
                        GLFW.glfwCreateStandardCursor(GLFW.GLFW_IBEAM_CURSOR));
            }
            ClickGUI.anyHovered = true;
        }
    }

    private void drawClearButton(DrawContext context, float x, float y, int mouseX, int mouseY) {
        boolean hovered = Render2DEngine.isHovered(mouseX, mouseY, x, y, 8, 8);
        Color color = hovered ? new Color(255, 0, 0, 255) : new Color(150, 150, 150, 255);
        Render2DEngine.drawLine(x, y, x + 8, y + 8, color.getRGB());
        Render2DEngine.drawLine(x + 8, y, x, y + 8, color.getRGB());
    }


    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        boolean isHovered = Render2DEngine.isHovered(mouseX, mouseY, x, y, width, height);


        if (!moduleName.isEmpty()) {
            boolean clearHovered = Render2DEngine.isHovered(mouseX, mouseY, x + width - 16, y + height / 2f - 4, 8, 8);
            if (clearHovered && button == 0) {
                moduleName = "";
                return;
            }
        }

        if (isHovered) listening = true;
        else {
            listening = false;
        }

        if (listening) veltragossa.currentKeyListener = veltragossa.KeyListening.Search;
    }

    @Override
    public void charTyped(char key, int keyCode) {
        if (StringHelper.isValidChar(key) && listening) {
            moduleName = moduleName + key;
        }
    }

    @Override
    public void keyTyped(int keyCode) {
        super.keyTyped(keyCode);

        if (keyCode == GLFW.GLFW_KEY_F && (InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_CONTROL) || InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_CONTROL))) {
            listening = !listening;
            veltragossa.currentKeyListener = veltragossa.KeyListening.Search;
            return;
        }

        if (veltragossa.currentKeyListener != veltragossa.KeyListening.Search)
            return;

        if (listening) {
            switch (keyCode) {
                case GLFW.GLFW_KEY_ESCAPE, GLFW.GLFW_KEY_ENTER -> {
                    listening = false;
                }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    if(moduleName.length() > 0)
                        moduleName = moduleName.substring(0, moduleName.length() - 1);
                }
                case GLFW.GLFW_KEY_SPACE -> moduleName = moduleName + " ";
            }
        }
    }
}
