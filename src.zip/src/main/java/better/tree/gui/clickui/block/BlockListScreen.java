package better.tree.gui.clickui.block;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import better.tree.gui.font.FontRenderers;
import better.tree.gui.Theme;
import better.tree.setting.Setting;
import better.tree.setting.impl.ItemSelectSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BlockListScreen extends Screen {
    private final Setting<ItemSelectSetting> setting;
    private final List<Block> allBlocks;
    private List<Block> filteredBlocks;
    private String searchQuery = "";
    private double scrollY;
    private boolean isDragging;
    private float animationProgress;

    private static final int ITEM_HEIGHT = 25;
    private static final int PADDING = 5;
    private static final int SCROLL_BAR_WIDTH = 4;

    public BlockListScreen(Setting<ItemSelectSetting> setting) {
        super(Text.literal("Block Selection"));
        this.setting = setting;
        this.allBlocks = Registries.BLOCK.stream()
                .filter(block -> block != Blocks.AIR && block != Blocks.CAVE_AIR && block != Blocks.VOID_AIR)
                .collect(Collectors.toList());
        this.filteredBlocks = new ArrayList<>(allBlocks);
    }

    @Override
    protected void init() {
        super.init();
        updateFilteredBlocks();
    }


    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        animationProgress = Math.min(1.0f, animationProgress + 0.1f);

        int screenWidth = width / 2;
        int screenHeight = height - 100;
        int x = width / 4;
        int y = 50;


        Render2DEngine.drawRound(matrices, x, y, screenWidth, screenHeight, 10, new Color(17, 17, 27, 255));


        Render2DEngine.drawRound(matrices, x + 10, y + 10, screenWidth - 20, 30, 5, Theme.BUTTON_COLOR);
        FontRenderers.sf_medium.drawString(matrices, searchQuery.isEmpty() ? "Search blocks..." : searchQuery,
                x + 15, y + 20, Theme.FONT_COLOR.getRGB());


        int listY = y + 50;
        int listHeight = screenHeight - 60;
        int maxScroll = Math.max(0, filteredBlocks.size() * ITEM_HEIGHT - listHeight);
        scrollY = MathHelper.clamp(scrollY, 0, maxScroll);


        Render2DEngine.addWindow(matrices, x + 10, listY, x + screenWidth - 10, listY + listHeight, 1.0);
        int currentY = listY - (int) scrollY;

        for (Block block : filteredBlocks) {
            if (currentY + ITEM_HEIGHT >= listY && currentY <= listY + listHeight) {
                boolean isSelected = setting.getValue().getBlocks().contains(block);
                Color buttonColor = isSelected ? Theme.ACCENT_COLOR : Theme.BUTTON_COLOR;

                Render2DEngine.drawRound(matrices, x + 15, currentY, screenWidth - 30, ITEM_HEIGHT - 2, 5, buttonColor);
                FontRenderers.sf_medium.drawString(matrices, getBlockName(block),
                    x + 20, currentY + ITEM_HEIGHT / 2f - FontRenderers.sf_medium.getStringHeight(getBlockName(block)) / 2f,
                    isSelected ? Color.WHITE.getRGB() : Theme.FONT_COLOR.getRGB());
            }
            currentY += ITEM_HEIGHT;
        }
        Render2DEngine.popWindow();


        if (maxScroll > 0) {
            float progress = (float) (scrollY / maxScroll);
            int scrollBarHeight = (int) (listHeight * (listHeight / (float) (filteredBlocks.size() * ITEM_HEIGHT)));
            int scrollBarY = listY + (int) ((listHeight - scrollBarHeight) * progress);

            Render2DEngine.drawRound(matrices, x + screenWidth - 15, scrollBarY, SCROLL_BAR_WIDTH, scrollBarHeight, 2,
                    isDragging ? Theme.ACCENT_COLOR : Theme.BUTTON_COLOR);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int screenWidth = width / 2;
        int x = width / 4;
        int y = 50;
        int listY = y + 50;
        int listHeight = height - 160;


        if (mouseX >= x + screenWidth - 15 && mouseX <= x + screenWidth - 15 + SCROLL_BAR_WIDTH
                && mouseY >= listY && mouseY <= listY + listHeight) {
            isDragging = true;
            return true;
        }


        if (mouseX >= x + 15 && mouseX <= x + screenWidth - 15
                && mouseY >= listY && mouseY <= listY + listHeight) {
            int index = (int) ((mouseY - listY + scrollY) / ITEM_HEIGHT);
            if (index >= 0 && index < filteredBlocks.size()) {
                Block block = filteredBlocks.get(index);
                List<Block> selectedBlocks = new ArrayList<>(setting.getValue().getBlocks());

                if (selectedBlocks.contains(block))
                    selectedBlocks.remove(block);
                else
                    selectedBlocks.add(block);

                setting.getValue().setBlocks(selectedBlocks);
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        isDragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (isDragging) {
            int screenHeight = height - 100;
            int listHeight = screenHeight - 60;
            int maxScroll = Math.max(0, filteredBlocks.size() * ITEM_HEIGHT - listHeight);
            double scrollScale = maxScroll / (double) (listHeight - 40);
            scrollY = MathHelper.clamp(scrollY + deltaY * scrollScale, 0, maxScroll);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }


    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        scrollY = Math.max(0, scrollY - amount * 20);
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (Character.isLetterOrDigit(chr) || chr == '_' || chr == '-' || chr == ' ') {
            searchQuery += chr;
            updateFilteredBlocks();
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 259 && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
            updateFilteredBlocks();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void updateFilteredBlocks() {
        if (searchQuery.isEmpty()) {
            filteredBlocks = new ArrayList<>(allBlocks);
        } else {
            String query = searchQuery.toLowerCase();
            filteredBlocks = allBlocks.stream()
                    .filter(block -> getBlockName(block).toLowerCase().contains(query))
                    .collect(Collectors.toList());
        }
        scrollY = 0;
    }

    private String getBlockName(Block block) {
        return block.getName().getString();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
