package better.tree.gui;

import java.awt.Color;

public class Theme {
    public static final Color BACKGROUND_COLOR = new Color(20, 20, 20);
    public static final Color ACCENT_COLOR = new Color(0, 150, 255);
    public static final Color FONT_COLOR = new Color(255, 255, 255);
    public static final Color SECONDARY_FONT_COLOR = new Color(150, 150, 150);
    public static final Color BUTTON_COLOR = new Color(40, 40, 40);
    public static final Color BUTTON_HOVER_COLOR = new Color(50, 50, 50);
}