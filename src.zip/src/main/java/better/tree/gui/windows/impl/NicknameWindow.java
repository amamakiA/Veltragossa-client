package better.tree.gui.windows.impl;

import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import better.tree.features.cmd.impl.LoginCommand;
import better.tree.gui.clickui.impl.SliderElement;
import better.tree.gui.font.FontRenderers;
import better.tree.gui.windows.WindowBase;
import better.tree.setting.Setting;
import better.tree.setting.impl.PositionSetting;
import better.tree.utility.render.Render2DEngine;
import better.tree.utility.render.TextureStorage;

import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class NicknameWindow extends WindowBase {
    private static NicknameWindow instance;

    private static class NickEntry {
        String name;
        boolean loaded;

        NickEntry(String name) {
            this.name = name;
            this.loaded = false;
        }
    }

    private final List<NickEntry> nicknameHistory = new ArrayList<>();
    private String currentInput = "Nickname";
    private int listeningId = -1;
    private String currentNick = "";
    private final Random random = new Random();
    private static final String NICK_HISTORY_FILE = "veltra_nick_history.cfg";


    private String tooltip = "";

    public NicknameWindow(float x, float y, float width, float height, Setting<PositionSetting> position) {
        super(x, y, width, height, "Nicknames", position, TextureStorage.playerIcon);
    }

    public static NicknameWindow get(float x, float y, Setting<PositionSetting> position) {
        if (instance == null)

            instance = new NicknameWindow(10 + 3 * 210, 50, 200, 180, position);
        return instance;
    }

    private String generateRandomNick() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder("Veltra");
        for (int i = 0; i < 5; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private void saveNickToFile(String nick) {
        try (FileWriter fw = new FileWriter(NICK_HISTORY_FILE, true)) {
            fw.write(nick + "\n");
        } catch (IOException ignored) {}
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY) {
        super.render(context, mouseX, mouseY);

        Color base = new Color(0xC5333333, true);
        Color outline = new Color(0xC55B5B5B, true);
        Color hovered = new Color(0xC5494949, true);
        int textColor = new Color(0xBDBDBD).getRGB();
        int activeColor = new Color(0xFFB300FF, true).getRGB();
        int buttonTextColor = new Color(0xFFFFFF).getRGB();

        String blink = (System.currentTimeMillis() / 240) % 2 == 0 ? "" : "l";


        float inputX = getX() + 11;
        float inputY = getY() + 19;
        float inputW = getWidth() - 70;
        float inputH = 16;
        boolean hoverInput = Render2DEngine.isHovered(mouseX, mouseY, inputX, inputY, inputW, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), inputX, inputY, inputW, inputH, hoverInput ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), currentInput + (listeningId == 1 ? blink : ""), inputX + 2, inputY + 4, textColor);


        float btnRandX = inputX + inputW + 4;
        boolean hoverRandom = Render2DEngine.isHovered(mouseX, mouseY, btnRandX, inputY, 16, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), btnRandX, inputY, 16, inputH, hoverRandom ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), "R", btnRandX + 5, inputY + 4, buttonTextColor);
        if (hoverRandom) tooltip = "Generate Random Nick";

        float btnAddX = btnRandX + 20;
        boolean hoverAdd = Render2DEngine.isHovered(mouseX, mouseY, btnAddX, inputY, 16, inputH);
        Render2DEngine.drawRectWithOutline(context.getMatrices(), btnAddX, inputY, 16, inputH, hoverAdd ? hovered : base, outline);
        FontRenderers.sf_medium.drawString(context.getMatrices(), "+", btnAddX + 5, inputY + 4, buttonTextColor);
        if (hoverAdd) tooltip = "Add Nick and Login";


        FontRenderers.sf_medium.drawString(context.getMatrices(), "History:", inputX, inputY + inputH + 10, textColor);
        float historyY = inputY + inputH + 26;

        int loggedColor = new Color(0x4CFF4C).getRGB();
        int notLoggedColor = new Color(0xFF4C4C).getRGB();
        for (int i = nicknameHistory.size() - 1; i >= 0 && i >= nicknameHistory.size() - 10; i--) {
            NickEntry entry = nicknameHistory.get(i);
            float entryX = inputX;
            float y = historyY;
            boolean isActive = entry.name.equals(currentNick);
            int color = entry.loaded ? loggedColor : notLoggedColor;

            FontRenderers.sf_medium.drawString(context.getMatrices(), entry.name, entryX, y, color);

            float btnLoadX = entryX + inputW + 4;
            boolean hoverLoad = Render2DEngine.isHovered(mouseX, mouseY, btnLoadX, y, 16, inputH);
            Render2DEngine.drawRectWithOutline(context.getMatrices(), btnLoadX, y, 16, inputH, hoverLoad ? hovered : base, outline);
            FontRenderers.sf_medium.drawString(context.getMatrices(), "L", btnLoadX + 5, y + 4, buttonTextColor);
            if (hoverLoad) tooltip = "Login with this nickname";

            float btnDelX = btnLoadX + 20;
            boolean hoverDel = Render2DEngine.isHovered(mouseX, mouseY, btnDelX, y, 16, inputH);
            Render2DEngine.drawRectWithOutline(context.getMatrices(), btnDelX, y, 16, inputH, hoverDel ? hovered : base, outline);
            FontRenderers.sf_medium.drawString(context.getMatrices(), "X", btnDelX + 5, y + 4, buttonTextColor);
            if (hoverDel) tooltip = "Remove from history";

            if (isActive) FontRenderers.sf_medium.drawString(context.getMatrices(), "✓", btnDelX + 22, y + 4, activeColor);
            historyY += inputH + 4;
        }

        if (!tooltip.isEmpty()) {
            FontRenderers.sf_medium.drawString(context.getMatrices(), tooltip, mouseX + 10, mouseY + 10, new Color(0xFFB300FF, true).getRGB());
            tooltip = "";
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        float inputX = getX() + 11;
        float inputY = getY() + 19;
        float inputW = getWidth() - 70;
        float btnRandX = inputX + inputW + 4;
        float btnAddX = btnRandX + 20;
        boolean hoverInput = Render2DEngine.isHovered(mouseX, mouseY, inputX, inputY, inputW, 16);
        boolean hoverRandom = Render2DEngine.isHovered(mouseX, mouseY, btnRandX, inputY, 16, 16);
        boolean hoverAdd = Render2DEngine.isHovered(mouseX, mouseY, btnAddX, inputY, 16, 16);
        if (hoverInput) {
            currentInput = "";
            listeningId = 1;
        }
        if (hoverRandom) {
            String nick = generateRandomNick();
            currentInput = nick;
        }
        if (hoverAdd && !currentInput.isEmpty()) {

            if (currentInput.equalsIgnoreCase("Zelek5351") || currentInput.equalsIgnoreCase("Nickname")) {
                tooltip = "No NO!";
                return;
            }
            nicknameHistory.add(new NickEntry(currentInput));
            saveNickToFile(currentInput);
            new LoginCommand().login(currentInput);
            currentNick = currentInput;
            for (NickEntry entry : nicknameHistory) entry.loaded = false;
            nicknameHistory.get(nicknameHistory.size() - 1).loaded = true;
            currentInput = "Nickname";
            listeningId = -1;
        }

        float historyY = inputY + 16 + 26;
        for (int i = nicknameHistory.size() - 1; i >= 0 && i >= nicknameHistory.size() - 10; i--) {
            NickEntry entry = nicknameHistory.get(i);
            float entryX = inputX;
            float y = historyY;
            float btnLoadX = entryX + inputW + 4;
            float btnDelX = btnLoadX + 20;
            boolean hoverLoad = Render2DEngine.isHovered(mouseX, mouseY, btnLoadX, y, 16, 16);
            boolean hoverDel = Render2DEngine.isHovered(mouseX, mouseY, btnDelX, y, 16, 16);
            if (hoverLoad) {
                new LoginCommand().login(entry.name);
                currentNick = entry.name;
                for (NickEntry e : nicknameHistory) e.loaded = false;
                entry.loaded = true;
            }
            if (hoverDel) {
                nicknameHistory.remove(i);
                break;
            }
            historyY += 20;
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningId == 1) {
            switch (keyCode) {
                case GLFW.GLFW_KEY_ENTER -> {
                    if (!currentInput.isEmpty()) {

                        if (currentInput.equalsIgnoreCase("Zelek5351") || currentInput.equalsIgnoreCase("Nickname")) {
                            tooltip = "Ten nick jest zablokowany!";
                            return;
                        }
                        nicknameHistory.add(new NickEntry(currentInput));
                        saveNickToFile(currentInput);
                        new LoginCommand().login(currentInput);
                        currentNick = currentInput;
                        currentInput = "Nickname";
                        listeningId = -1;
                    }
                }
                case GLFW.GLFW_KEY_ESCAPE -> {
                    currentInput = "Nickname";
                    listeningId = -1;
                }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    currentInput = SliderElement.removeLastChar(currentInput);
                    if (Objects.equals(currentInput, "")) {
                        currentInput = "Nickname";
                        listeningId = -1;
                    }
                }
                case GLFW.GLFW_KEY_SPACE -> currentInput += " ";
            }
        }
    }

    @Override
    public void charTyped(char key, int keyCode) {
        if (listeningId == 1 && net.minecraft.util.StringHelper.isValidChar(key)) {
            currentInput += key;
        }
    }
}
