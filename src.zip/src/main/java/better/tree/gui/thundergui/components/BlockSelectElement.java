package better.tree.gui.thundergui.components;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import better.tree.gui.Theme;
import better.tree.gui.clickui.block.BlockListScreen;
import better.tree.gui.font.FontRenderers;
import better.tree.setting.Setting;
import better.tree.setting.impl.ItemSelectSetting;
import better.tree.utility.render.Render2DEngine;

import java.awt.*;
import java.util.List;

public class BlockSelectElement extends SettingElement {
    private final Setting<ItemSelectSetting> setting;
    private float animation = 0f;

    public BlockSelectElement(Setting<ItemSelectSetting> setting) {
        super(setting);
        this.setting = setting;
        this.height = 20;
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        super.render(matrices, mouseX, mouseY, delta);

        animation = isHovered() ? Math.min(1f, animation + 0.1f) : Math.max(0f, animation - 0.1f);

        Color buttonColor = Render2DEngine.interpolateColorC(Theme.BUTTON_COLOR, Theme.BUTTON_HOVER_COLOR, animation);
        Render2DEngine.drawRound(matrices, x, y, width, height, 5, buttonColor);

        List<Block> selectedBlocks = setting.getValue().getBlocks();
        String text = "Selected Blocks: " + selectedBlocks.size();
        float textHeight = FontRenderers.sf_medium.getStringHeight(text);
        FontRenderers.sf_medium.drawString(matrices, text,
            x + 5,
            y + height / 2f - textHeight / 2f,
            Theme.FONT_COLOR.getRGB()
        );


        float previewX = x + FontRenderers.sf_medium.getStringWidth(text) + 10;
        float previewY = y + 2;
        float previewSize = height - 4;

        int maxPreviews = (int)((width - (previewX - x) - 5) / previewSize);
        int shown = Math.min(maxPreviews, selectedBlocks.size());

        for (int i = 0; i < shown; i++) {
            Block block = selectedBlocks.get(i);
            Render2DEngine.drawRound(matrices, previewX + i * (previewSize + 2), previewY, previewSize, previewSize, 3, new Color(45, 45, 45));

            String shortName = getShortBlockName(block);
            float miniTextHeight = FontRenderers.sf_medium_mini.getStringHeight(shortName);
            FontRenderers.sf_medium_mini.drawCenteredString(matrices, shortName,
                previewX + i * (previewSize + 2) + previewSize/2,
                previewY + previewSize/2 - miniTextHeight/2,
                Theme.FONT_COLOR.getRGB()
            );
        }

        if (selectedBlocks.size() > maxPreviews) {
            String more = "+" + (selectedBlocks.size() - maxPreviews);
            float miniTextHeight = FontRenderers.sf_medium_mini.getStringHeight(more);
            FontRenderers.sf_medium_mini.drawString(matrices, more,
                previewX + shown * (previewSize + 2),
                previewY + previewSize/2 - miniTextHeight/2,
                Theme.FONT_COLOR.getRGB()
            );
        }
    }

    private String getShortBlockName(Block block) {
        String name = block.getName().getString();
        if (name.length() > 4) {
            return name.substring(0, 3) + "..";
        }
        return name;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHovered() && button == 0) {
            MinecraftClient.getInstance().setScreen(new BlockListScreen(setting));
        }
    }
}
