package better.tree.events.impl;

import better.tree.events.Event;

public class EventPostTick extends Event {
}