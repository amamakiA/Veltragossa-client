package better.tree.events.impl;

public class EventSync {
    private float yaw;
    private float pitch;
    private double x, y, z;
    private boolean cancelled;
    private Runnable postAction;

    public EventSync(float yaw, float pitch, double x, double y, double z) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public EventSync(float yaw, float pitch) {
        this(yaw, pitch, 0, 0, 0);
    }

    public void addPostAction(Runnable action) {
        this.postAction = action;
    }

    public Runnable getPostAction() {
        return postAction;
    }

    public void cancel() {
        this.cancelled = true;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public float getYaw() {
        return yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return z;
    }

    public void setZ(double z) {
        this.z = z;
    }
}
